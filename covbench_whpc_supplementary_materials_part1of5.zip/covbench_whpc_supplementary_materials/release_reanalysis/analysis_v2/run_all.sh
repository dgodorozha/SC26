#!/usr/bin/env bash
# Regenerates every CovBench number in the paper from the released rows. Run from the folder that holds
# analysis_v2/, covbench_code.zip and the data directory (experiments.parquet inside it).
#   bash analysis_v2/run_all.sh <data_dir> <out_dir>
# Requirements: numpy, pandas, pyarrow, matplotlib, scikit-learn, torch (CPU is enough; only a07 uses it).
set -euo pipefail
DATA=${1:-data}; OUT=${2:-outputs}
python analysis_v2/a01_cross_tier.py "$DATA" "$OUT"
python analysis_v2/a02_normalisation.py "$DATA" "$OUT"
python analysis_v2/a03_pareto_budget.py "$DATA" "$OUT"
python analysis_v2/a04_uncertainty.py "$DATA" "$OUT"
python analysis_v2/a06_cpu_gpu_equivalence.py "$DATA" "$OUT"
python analysis_v2/a07_ht_grid.py "$DATA" "$OUT"        # about four minutes on two cores; needs the released code (found automatically from ../covbench_code.zip)
python analysis_v2/a05_figures_tables.py "$DATA" "$OUT"   # last: reads the json of a01 to a04 and a07, writes figures/, tables/ and paper_numbers.json
echo "done: copy $OUT/figures/*.pdf and $OUT/tables/*.tex into the paper folder"
