"""A05: Figures and LaTeX table fragments from the A01 to A04 outputs.

Figures (PDF + PNG, NeurIPS column width, large fonts):
  fig_gate.pdf            Phi as a function of the magnitude gate tau, min max and z score
  fig_flip_anatomy.pdf    time saved vs relative error regret on flipped groups
  fig_budget.pdf          budget constrained oracle: feasibility and agreement vs B
  fig_pareto_example.pdf  one pooled cell: Pareto set, supported set, budget sweep
  fig_migration.pdf       cross tier and device migration with bootstrap CIs

Table fragments (tables/*.tex), each a bare tabular body to \\input:
  tab_headline.tex, tab_cross_tier.tex, tab_gate.tex, tab_pareto.tex,
  tab_budget.tex, tab_regret.tex, tab_rocm.tex, tab_axes.tex
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COST_COL, ERROR_COL, PRETTY, load, scalarised_oracle

# validated reference palette (light surface)
C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100",
     "magenta": "#e87ba4", "green": "#008300", "violet": "#6250d6", "red": "#e34948",
     "ink": "#0b0b0b", "ink2": "#52514e", "muted": "#898781", "grid": "#e1e0d9", "axis": "#c3c2b7"}
plt.rcParams.update({
    "font.size": 10, "axes.titlesize": 10.5, "axes.labelsize": 10, "legend.fontsize": 9,
    "xtick.labelsize": 9, "ytick.labelsize": 9, "axes.edgecolor": C["axis"], "axes.linewidth": 0.8,
    "grid.color": C["grid"], "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "text.color": C["ink"], "axes.labelcolor": C["ink2"], "xtick.color": C["ink2"], "ytick.color": C["ink2"],
    "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.dpi": 200,
})
W = 5.5  # NeurIPS text width in inches
AX = {"ar1": "AR(1)", "banded": "Banded", "block_diagonal": "Block diagonal", "sparse_precision": "Sparse precision",
      "spiked": "Spiked", "gaussian": "Gaussian", "t_dist": "$t_3$", "eps_contaminated": r"$\varepsilon$ contaminated"}


def fmt(x, d=3):
    return f"{x:.{d}f}"


def pct(x, d=1):
    return f"{100*x:.{d}f}\\%"


def main(data_dir, out_dir):
    out = Path(out_dir); fig_dir = out / "figures"; tab_dir = out / "tables"
    fig_dir.mkdir(parents=True, exist_ok=True); tab_dir.mkdir(parents=True, exist_ok=True)
    A1 = json.load(open(out / "a01_cross_tier.json"))
    A2 = json.load(open(out / "a02_normalisation.json"))
    A3 = json.load(open(out / "a03_pareto_budget.json"))
    A4 = json.load(open(out / "a04_uncertainty.json"))
    G = pd.read_csv(out / "a02_gate_sweep.csv")
    S = pd.read_csv(out / "a02_group_spreads.csv")
    BB = pd.read_csv(out / "a03_budget_by_B_groups.csv")
    BP = pd.read_csv(out / "a03_budget_by_B_pooled.csv")

    # ------------------------------------------------------------------ fig_gate
    fig, ax = plt.subplots(figsize=(W, 2.7))
    for norm, col, lab in (("minmax", C["blue"], "within group min max"), ("zscore", C["orange"], "within group z score")):
        g = G[(G.norm == norm) & (~G.log_cost)].copy()
        x = g.tau_s.replace(0, 3e-4)
        ax.plot(x, g.phi, color=col, lw=2, marker="o", ms=5, label=lab)
    ax.set_xscale("log")
    ax.axhline(A1["phi_complete_groups"], color=C["muted"], lw=0.8, ls=":")
    ax.text(3.2e-4, A1["phi_complete_groups"] + 0.012, "ungated headline", color=C["muted"], fontsize=8.5)
    ax.set_xlabel(r"magnitude gate $\tau$ (seconds; leftmost point is $\tau=0$)")
    ax.set_ylabel(r"flip rate $\Phi(\tau)$")
    ax.set_ylim(0, 0.5); ax.grid(axis="y")
    ax.legend(frameon=False, loc="lower left")
    for name in ("fig_gate.pdf", "fig_gate.png"):
        fig.savefig(fig_dir / name)
    plt.close(fig)

    # ------------------------------------------------------------- fig_flip_anatomy
    F = S[S.flip == 1]
    fig, ax = plt.subplots(figsize=(W, 2.9))
    cpu, cuda = F[F.device == "cpu"], F[F.device == "cuda"]
    ax.scatter(cuda.time_saved_s, cuda.error_regret_rel, s=12, color=C["blue"], alpha=0.55, lw=0, label=f"GPU groups (n={len(cuda)})")
    ax.scatter(cpu.time_saved_s, cpu.error_regret_rel, s=12, color=C["orange"], alpha=0.55, lw=0, label=f"CPU groups (n={len(cpu)})")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("absolute runtime saved by the balanced oracle (s)")
    ax.set_ylabel("relative Frobenius error given up")
    ax.axvline(0.1, color=C["muted"], lw=0.8, ls=":"); ax.axhline(0.05, color=C["muted"], lw=0.8, ls=":")
    ax.text(0.105, 4.0, "0.1 s", color=C["muted"], fontsize=8); ax.text(4e-3, 0.058, "5%", color=C["muted"], fontsize=8)
    ax.grid(True, which="major"); ax.legend(frameon=False, loc="lower right")
    for name in ("fig_flip_anatomy.pdf", "fig_flip_anatomy.png"):
        fig.savefig(fig_dir / name)
    plt.close(fig)

    # ----------------------------------------------------------------- fig_budget
    fig, axes = plt.subplots(1, 2, figsize=(W, 2.9), sharey=True)
    for ax, D, title in ((axes[0], BB, "released groups (one device)"), (axes[1], BP, "pooled cells (both devices)")):
        ax.plot(D.B, D.eo_feasible, color=C["blue"], lw=2, label="error only oracle feasible")
        ax.plot(D.B, D.agree_bal, color=C["orange"], lw=2, label="budget oracle = balanced oracle")
        ax.plot(D.B, D.frac_unsupported, color=C["violet"], lw=2, label="budget oracle unsupported")
        ax.set_xscale("log"); ax.set_xlabel("compute budget $B$ (s)"); ax.set_title(title, fontsize=9.5)
        ax.set_ylim(0, 1.02); ax.grid(axis="y")
    axes[0].set_ylabel("fraction of groups")
    fig.legend(*axes[0].get_legend_handles_labels(), frameon=False, fontsize=8.5, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.16))
    for name in ("fig_budget.pdf", "fig_budget.png"):
        fig.savefig(fig_dir / name)
    plt.close(fig)

    # --------------------------------------------------------- fig_pareto_example
    df = load(data_dir)
    # choose a pooled cell with an unsupported efficient point and a flip, sparse precision, t3
    cand = None
    for cid, g in df.groupby("cell_id", sort=False):
        if len(g) != 13 or g.structure_family.iloc[0] != "sparse_precision" or g.distribution.iloc[0] != "t_dist":
            continue
        from a03_pareto_budget import pareto_mask, supported_mask
        T = g[COST_COL].to_numpy(); E = g[ERROR_COL].to_numpy()
        par = pareto_mask(T, E); sup = supported_mask(T, E, par)
        names_ = g.estimator_name.to_numpy()
        uns = np.where(par & ~sup)[0]
        pnames = list(names_[par])
        distinct = [i for i in uns if pnames.count(names_[i]) == 1]
        if len(distinct) >= 1 and scalarised_oracle(E, T, 1, 0) != scalarised_oracle(E, T, .5, .5):
            cand = (cid, g, par, sup); break
    if cand is not None:
        cid, g, par, sup = cand
        T = g[COST_COL].to_numpy(); E = g[ERROR_COL].to_numpy()
        names = g.estimator_name.to_numpy(); devs = g.device.to_numpy()
        fig, ax = plt.subplots(figsize=(W, 3.0))
        for i in range(len(T)):
            col = C["blue"] if devs[i] == "cuda" else C["orange"]
            mk = "o"
            ax.scatter(T[i], E[i], s=70 if par[i] else 30, color=col, edgecolor=C["ink"] if par[i] else "none",
                       lw=1.4 if sup[i] else 0.6, marker=mk, zorder=3, alpha=1 if par[i] else 0.5)
        order = {int(i): k for k, i in enumerate(np.where(par)[0][np.argsort(T[par])])}
        for i in np.where(par)[0]:
            tag = f"{PRETTY[names[i]]}/{'GPU' if devs[i]=='cuda' else 'CPU'}"
            if not sup[i]:
                tag += " (unsupported)"
            k = order[int(i)]
            dy = 8 if k % 2 == 0 else -13
            ax.annotate(tag, (T[i], E[i]), xytext=(6, dy), textcoords="offset points", fontsize=7.5)
        # frontier line through supported points
        si = np.where(sup)[0]; si = si[np.argsort(T[si])]
        ax.plot(T[si], E[si], color=C["ink2"], lw=1, ls="--", zorder=2, label="convex hull of the frontier")
        pi = np.where(par)[0]; pi = pi[np.argsort(T[pi])]
        ax.step(T[pi], E[pi], where="post", color=C["muted"], lw=0.8, zorder=1, label="budget rule path")
        i_eo = scalarised_oracle(E, T, 1, 0); i_bal = scalarised_oracle(E, T, .5, .5)
        # oracle labels placed in data coordinates in the empty band between the frontier and the dominated points, clear of the point labels
        rng = E.max() - E.min()
        ax.set_ylim(E.min() - 0.14 * rng, E.max() + 0.08 * rng)   # room below the lowest points for their labels
        ymid = E[par].min() + 0.18 * (E.max() - E[par].min())
        ax.annotate("error only oracle", (T[i_eo], E[i_eo]), xytext=(T[i_eo] * 1.6, ymid), textcoords="data", fontsize=8, color=C["ink2"], ha="left", va="center",
                    arrowprops=dict(arrowstyle="-", color=C["ink2"], lw=0.6))
        ax.annotate("balanced oracle", (T[i_bal], E[i_bal]), xytext=(T[i_bal] * 0.2, E[i_bal] - 0.1 * rng), textcoords="data", fontsize=8, color=C["ink2"], ha="center", va="center",
                    arrowprops=dict(arrowstyle="-", color=C["ink2"], lw=0.6))
        ax.set_xscale("log"); ax.set_xlabel("wall clock (s), 13 deployment configurations of one cell")
        ax.set_ylabel("Frobenius error"); ax.grid(True)
        ax.scatter([], [], color=C["blue"], label="GPU"); ax.scatter([], [], color=C["orange"], label="CPU")
        ax.legend(frameon=False, fontsize=8, loc="upper right")
        ax.set_title(f"sparse precision, $t_3$, $p/n = {g.p_over_n.iloc[0]:g}$; outlined: efficient, bold outline: supported", fontsize=9)
        for name in ("fig_pareto_example.pdf", "fig_pareto_example.png"):
            fig.savefig(fig_dir / name)
        plt.close(fig)
        example = {"cell_id": cid, "n_pareto": int(par.sum()), "n_supported": int(sup.sum()),
                   "pareto": [(PRETTY[names[i]], devs[i], float(T[i]), float(E[i]), bool(sup[i])) for i in np.where(par)[0]]}
    else:
        example = None

    # -------------------------------------------------------------- fig_migration
    cb = A4["cluster_bootstrap"]
    # point estimates from a01 (the same numbers as the tables), intervals from the a04 bootstrap
    cpu_bal = {r["weighting"]: r for r in A1["cross_tier_cpu"]}["balanced"]
    pool_bal = {r["weighting"]: r for r in A1["cross_tier_pooled"]}["balanced"]
    dev_bal = {r["weighting"]: r for r in A1["device_migration_pooled"]}["balanced"]
    items = [("CPU groups: Tier C to B", cpu_bal["Y_C_to_B"], cb["cpu_groups"]["c_to_b"]), ("CPU groups: Tier B to C", cpu_bal["Y_B_to_C"], cb["cpu_groups"]["b_to_c"]),
             ("Pooled: CPU to GPU", dev_bal["cpu_to_cuda"], cb["pooled_cells"]["cpu_to_cuda"]), ("Pooled: GPU to CPU", dev_bal["cuda_to_cpu"], cb["pooled_cells"]["cuda_to_cpu"]),
             ("Pooled: Tier C to B", pool_bal["Y_C_to_B"], cb["pooled_cells"]["c_to_b"]), ("Pooled: Tier B to C", pool_bal["Y_B_to_C"], cb["pooled_cells"]["b_to_c"])]
    fig, ax = plt.subplots(figsize=(W, 2.4))
    y = np.arange(len(items))[::-1]
    for yi, (lab, pt, v) in zip(y, items):
        col = C["blue"] if ("C to B" in lab or "CPU to GPU" in lab) else C["orange"]
        ax.plot([v["ci95_lo"], v["ci95_hi"]], [yi, yi], color=col, lw=2.5, solid_capstyle="butt")
        ax.plot(pt, yi, "o", color=col, ms=6, mec="white", mew=1)
        ax.text(v["ci95_hi"] + 0.008, yi, f"{100*pt:.1f}%  [{100*v['ci95_lo']:.1f}, {100*v['ci95_hi']:.1f}]", va="center", fontsize=8, color=C["ink2"])
    ax.set_yticks(y); ax.set_yticklabels([it[0] for it in items]); ax.set_xlim(0, 0.5)
    ax.set_xlabel("migration rate from error only to balanced oracle (design point cluster bootstrap, 95% CI)")
    ax.grid(axis="x")
    for name in ("fig_migration.pdf", "fig_migration.png"):
        fig.savefig(fig_dir / name)
    plt.close(fig)

    # ================================================================ TABLES
    def w(name, body):
        (tab_dir / name).write_text(body)

    # headline
    rl = A4["replicate_level"]; cba = cb["all_groups"]["flip"]
    w("tab_headline.tex", "\n".join([
        r"\begin{tabular}{@{}lrr@{}}", r"\toprule",
        r"Quantity & Value & Groups \\", r"\midrule",
        f"$\\Phi$, all released groups (finite grid count) & {fmt(A1['phi_all_groups'])} ({A4['phi_numerator'] if False else int(round(A1['phi_all_groups']*A1['n_groups']))}/{A1['n_groups']}) & {A1['n_groups']} \\\\",
        f"$\\Phi$, complete groups only (primary) & {fmt(A1['phi_complete_groups'])} ({A4['phi_numerator']}/{A4['n_groups']}) & {A4['n_groups']} \\\\",
        f"\\quad replicate level range over 10 replicates & {fmt(rl['phi_min'])} to {fmt(rl['phi_max'])} (sd {fmt(rl['phi_sd'])}) & \\\\",
        f"\\quad design point cluster bootstrap, 95\\% CI & [{fmt(cba['ci95_lo'])}, {fmt(cba['ci95_hi'])}] & 153 design points \\\\",
        f"$\\Phi$, CPU groups & {fmt(A4['phi_by_device']['cpu'])} [{fmt(cb['cpu_groups']['flip']['ci95_lo'])}, {fmt(cb['cpu_groups']['flip']['ci95_hi'])}] & 1530 \\\\",
        f"$\\Phi$, GPU groups & {fmt(A4['phi_by_device']['cuda'])} [{fmt(cb['cuda_groups']['flip']['ci95_lo'])}, {fmt(cb['cuda_groups']['flip']['ci95_hi'])}] & {A4['n_groups']-1530} \\\\",
        f"Configuration flip, pooled cells (13 configurations) & {fmt(A1['phi_pooled_configuration'])} [{fmt(cb['pooled_cells']['cfg_flip']['ci95_lo'])}, {fmt(cb['pooled_cells']['cfg_flip']['ci95_hi'])}] & 1423 \\\\",
        r"\bottomrule", r"\end{tabular}"]))

    # cross tier (corrected)
    rows = []
    cpuc = {r["weighting"]: r for r in A1["cross_tier_cpu"]}
    poolc = {r["weighting"]: r for r in A1["cross_tier_pooled"]}
    devm = {r["weighting"]: r for r in A1["device_migration_pooled"]}
    lab = {"balanced": r"Balanced ($\beta=0.5$)", "cost_heavy": r"Cost heavy ($\beta=0.7$)", "ab_0_1_0_9": r"Cost very heavy ($\beta=0.9$)", "cost_only": r"Cost only ($\beta=1$)"}
    for k in ("balanced", "cost_heavy", "ab_0_1_0_9", "cost_only"):
        rows.append(f"{lab[k]} & {pct(cpuc[k]['Y_C_to_B'])} & {pct(cpuc[k]['Y_B_to_C'])} & {pct(poolc[k]['Y_C_to_B'])} & {pct(poolc[k]['Y_B_to_C'])} & {pct(devm[k]['cpu_to_cuda'])} & {pct(devm[k]['cuda_to_cpu'])} \\\\")
    w("tab_cross_tier.tex", "\n".join([
        r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
        r" & \multicolumn{2}{c}{CPU groups (8 estimators)} & \multicolumn{4}{c}{Pooled cells (13 configurations)} \\",
        r"\cmidrule(lr){2-3} \cmidrule(lr){4-7}",
        r"Cost weighting & $Y_{C\to B}$ & $Y_{B\to C}$ & $Y_{C\to B}$ & $Y_{B\to C}$ & CPU$\to$GPU & GPU$\to$CPU \\", r"\midrule",
        *rows, r"\bottomrule", r"\end{tabular}"]))

    # gate table
    gm = G[(G.norm == "minmax") & (~G.log_cost)].set_index("tau_s").phi
    gz = G[(G.norm == "zscore") & (~G.log_cost)].set_index("tau_s").phi
    taus = [0.0, 0.01, 0.1, 0.3, 1.0, 3.0, 10.0]
    w("tab_gate.tex", "\n".join([
        r"\begin{tabular}{@{}l" + "c" * len(taus) + "@{}}", r"\toprule",
        r"$\tau$ (s) & " + " & ".join(("0 (released)" if t == 0 else f"{t:g}") for t in taus) + r" \\", r"\midrule",
        r"$\Phi(\tau)$, min max & " + " & ".join(fmt(gm[t]) for t in taus) + r" \\",
        r"$\Phi(\tau)$, z score & " + " & ".join(fmt(gz[t]) for t in taus) + r" \\",
        r"\bottomrule", r"\end{tabular}"]))

    # flip rate by absolute spread bin
    byb = A2["phi_by_dT_bin"]
    w("tab_spread_bins.tex", "\n".join([
        r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
        r"Runtime spread $\Delta T$ of the group & Groups & $\Phi$ within bin & Share of all flips \\", r"\midrule",
        *[f"{r['dT_bin']} & {int(r['n'])} & {fmt(r['phi'])} & {pct(r['share_of_all_flips'])} \\\\" for r in byb],
        r"\bottomrule", r"\end{tabular}"]))

    # pareto
    rg, rp = A3["released_groups"], A3["pooled_cells"]
    w("tab_pareto.tex", "\n".join([
        r"\begin{tabular}{@{}lcc@{}}", r"\toprule",
        r" & Released groups & Pooled cells \\",
        r" & (one device) & (13 configurations) \\", r"\midrule",
        f"Groups & {rg['n_groups']} & {rp['n_groups']} \\\\",
        f"Mean $|P(g)|$, efficient points & {fmt(rg['mean_pareto'],2)} & {fmt(rp['mean_pareto'],2)} \\\\",
        f"Mean $|S(g)|$, supported points & {fmt(rg['mean_supported'],2)} & {fmt(rp['mean_supported'],2)} \\\\",
        f"Unsupported efficient points & {rg['total_unsupported_points']}/{rg['total_pareto_points']} ({pct(rg['total_unsupported_points']/rg['total_pareto_points'])}) & {rp['total_unsupported_points']}/{rp['total_pareto_points']} ({pct(rp['total_unsupported_points']/rp['total_pareto_points'])}) \\\\",
        f"Groups with an unsupported efficient point & {pct(rg['frac_groups_with_unsupported'])} & {pct(rp['frac_groups_with_unsupported'])} \\\\",
        f"Share of $P(g)$ reached by the 11 point grid & {pct(rg['mean_frac_pareto_reached_by_11_grid'])} & {pct(rp['mean_frac_pareto_reached_by_11_grid'])} \\\\",
        f"Budget oracle unsupported at $\\ge 1$ of 26 sampled budgets & {pct(rg['frac_groups_budget_unsupported_some_B'])} & {pct(rp['frac_groups_budget_unsupported_some_B'])} \\\\",
        r"\bottomrule", r"\end{tabular}"]))

    # budget table at selected B
    sel = [0.01, 0.1, 1.0, 10.0]
    def near(D, b):
        return D.iloc[(D.B - b).abs().argmin()]
    rows = []
    for b in sel:
        r1, r2 = near(BB, b), near(BP, b)
        rows.append(f"{b:g} & {pct(r1.eo_feasible)} & {pct(r1.agree_bal)} & {pct(r1.frac_unsupported)} & {pct(r2.eo_feasible)} & {pct(r2.agree_bal)} & {pct(r2.frac_unsupported)} \\\\")
    w("tab_budget.tex", "\n".join([
        r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
        r" & \multicolumn{3}{c}{Released groups} & \multicolumn{3}{c}{Pooled cells} \\", r"\cmidrule(lr){2-4} \cmidrule(lr){5-7}",
        r"Budget $B$ (s) & EO feasible & $=$ balanced & unsupported & EO feasible & $=$ balanced & unsupported \\", r"\midrule",
        *rows, r"\bottomrule", r"\end{tabular}"]))

    # regret
    rw = A3["regret_weighted"]; fl = A2["flipped"]
    w("tab_regret.tex", "\n".join([
        r"\begin{tabular}{@{}lr@{}}", r"\toprule",
        r"On the " + str(fl["n"]) + r" flipped groups (error only $\to$ balanced oracle) & \\", r"\midrule",
        f"Median relative runtime saved & {pct(rw['median_time_saved_frac_given_flip'])} \\\\",
        f"Flips saving more than 90\\% of runtime & {pct(rw['frac_flips_time_saved_gt_90pct'])} \\\\",
        f"Median absolute runtime saved & {fl['time_saved_s']['q50']*1000:.0f} ms \\\\",
        f"Flips saving more than 100 ms (1 s) & {pct(fl['frac_time_saved_gt_100ms'])} ({pct(fl['frac_time_saved_gt_1s'])}) \\\\",
        f"Median relative Frobenius error given up & {pct(rw['median_err_regret_given_flip'])} \\\\",
        f"Mean relative Frobenius error given up & {pct(rw['mean_err_regret_given_flip'])} \\\\",
        f"Flips costing under 5\\% (10\\%) error & {pct(fl['frac_error_regret_lt_5pct'])} ({pct(fl['frac_error_regret_lt_10pct'])}) \\\\",
        f"Error regret weighted flip rate $\\Phi_R$ (mean over all groups) & {fmt(rw['phi_err_weighted'])} \\\\",
        f"Time saved weighted flip rate $\\Phi_T$ (mean over all groups) & {fmt(rw['phi_time_weighted'])} \\\\",
        r"\bottomrule", r"\end{tabular}"]))

    # top transitions
    tr = fl["transitions"]
    w("tab_transitions.tex", "\n".join([
        r"\begin{tabular}{@{}llr@{}}", r"\toprule",
        r"Error only oracle & Balanced oracle & Flipped groups \\", r"\midrule",
        *[f"{PRETTY[a]} & {PRETTY[b]} & {v} \\\\" for (a, b), v in [(k.split('->'), v) for k, v in list(tr.items())[:6]]],
        r"\bottomrule", r"\end{tabular}"]))

    # rocm
    ro = A4["rocm"]
    w("tab_rocm.tex", "\n".join([
        r"\begin{tabular}{@{}lccccc@{}}", r"\toprule",
        r"Hard thresholding GPU wall time scaled by & $0.25\times$ & $0.5\times$ & $1\times$ (released) & $2\times$ & $4\times$ \\", r"\midrule",
        r"$\Phi$ (all complete groups) & " + " & ".join(fmt(ro["scaled"][k]["phi"]) for k in ("0.25", "0.5")) + f" & {fmt(A1['phi_complete_groups'])} & " + " & ".join(fmt(ro["scaled"][k]["phi"]) for k in ("2.0", "4.0")) + r" \\",
        r"$\Phi$ (GPU groups) & " + " & ".join(fmt(ro["scaled"][k]["phi_cuda"]) for k in ("0.25", "0.5")) + f" & {fmt(A4['phi_by_device']['cuda'])} & " + " & ".join(fmt(ro["scaled"][k]["phi_cuda"]) for k in ("2.0", "4.0")) + r" \\",
        r"\bottomrule", r"\end{tabular}"]))

    # axes
    w("tab_axes.tex", "\n".join([
        r"\begin{tabular}{@{}lc@{}}", r"\toprule", r"Axis value & $\Phi$ \\", r"\midrule",
        *[f"{AX.get(k, k)} & {fmt(v)} \\\\" for k, v in A4["phi_by_structure"].items()],
        r"\midrule", *[f"{AX.get(k, k)} & {fmt(v)} \\\\" for k, v in A4["phi_by_distribution"].items()],
        r"\midrule", *[f"$p/n={k}$ & {fmt(v)} \\\\" for k, v in A4["phi_by_p_over_n"].items()],
        r"\bottomrule", r"\end{tabular}"]))

    # consolidated numbers for the paper text
    nums = {
        "phi_all": A1["phi_all_groups"], "phi_complete": A1["phi_complete_groups"],
        "n_complete": A4["n_groups"], "phi_num": A4["phi_numerator"],
        "ci_lo": cba["ci95_lo"], "ci_hi": cba["ci95_hi"], "rep_min": rl["phi_min"], "rep_max": rl["phi_max"], "rep_sd": rl["phi_sd"],
        "phi_cpu": A4["phi_by_device"]["cpu"], "phi_cuda": A4["phi_by_device"]["cuda"],
        "phi_pooled_cfg": A1["phi_pooled_configuration"],
        "ctb_bal_cpu": cpuc["balanced"]["Y_C_to_B"], "btc_bal_cpu": cpuc["balanced"]["Y_B_to_C"],
        "ctb_cpu_ci": [cb["cpu_groups"]["c_to_b"]["ci95_lo"], cb["cpu_groups"]["c_to_b"]["ci95_hi"]],
        "btc_cpu_ci": [cb["cpu_groups"]["b_to_c"]["ci95_lo"], cb["cpu_groups"]["b_to_c"]["ci95_hi"]],
        "ctb_range_cpu": [min(r["Y_C_to_B"] for r in A1["cross_tier_cpu"]), max(r["Y_C_to_B"] for r in A1["cross_tier_cpu"])],
        "btc_range_cpu": [min(r["Y_B_to_C"] for r in A1["cross_tier_cpu"]), max(r["Y_B_to_C"] for r in A1["cross_tier_cpu"])],
        "cpu2gpu_bal": devm["balanced"]["cpu_to_cuda"], "gpu2cpu_bal": devm["balanced"]["cuda_to_cpu"],
        "cpu2gpu_ci": [cb["pooled_cells"]["cpu_to_cuda"]["ci95_lo"], cb["pooled_cells"]["cpu_to_cuda"]["ci95_hi"]],
        "gpu2cpu_ci": [cb["pooled_cells"]["cuda_to_cpu"]["ci95_lo"], cb["pooled_cells"]["cuda_to_cpu"]["ci95_hi"]],
        "cpu2gpu_costonly": devm["cost_only"]["cpu_to_cuda"], "gpu2cpu_costonly": devm["cost_only"]["cuda_to_cpu"],
        "gate": {str(t): float(gm[t]) for t in taus}, "gate_z": {str(t): float(gz[t]) for t in taus},
        "tau_dagger_q": A2["bound_check"]["tau_dagger_quantiles"],
        "frac_groups_unsupported": rg["frac_groups_with_unsupported"], "frac_cells_unsupported": rp["frac_groups_with_unsupported"],
        "unsup_pts_groups": [rg["total_unsupported_points"], rg["total_pareto_points"]], "unsup_pts_cells": [rp["total_unsupported_points"], rp["total_pareto_points"]],
        "grid_reach_groups": rg["mean_frac_pareto_reached_by_11_grid"], "grid_reach_cells": rp["mean_frac_pareto_reached_by_11_grid"],
        "budget_unsup_some_B_groups": rg["frac_groups_budget_unsupported_some_B"], "budget_unsup_some_B_cells": rp["frac_groups_budget_unsupported_some_B"],
        "eo_feasible_100ms_groups": float(near(BB, 0.1).eo_feasible), "eo_feasible_100ms_cells": float(near(BP, 0.1).eo_feasible),
        "eo_feasible_1s_groups": float(near(BB, 1.0).eo_feasible), "agree_eo_10ms_groups": float(near(BB, 0.01).agree_eo), "agree_eo_1s_groups": float(near(BB, 1.0).agree_eo),
        "regret": rw, "flipped": {k: v for k, v in fl.items() if k != "transitions"}, "transitions": tr,
        "rocm": ro, "example": example,
        "phi_by_structure": A4["phi_by_structure"], "phi_by_distribution": A4["phi_by_distribution"], "phi_by_p_over_n": A4["phi_by_p_over_n"],
        "mean_pareto_groups": rg["mean_pareto"], "mean_pareto_cells": rp["mean_pareto"],
    }
    json.dump(nums, open(out / "paper_numbers.json", "w"), indent=2, default=float)
    print("wrote figures:", sorted(p.name for p in fig_dir.glob("*.pdf")))
    print("wrote tables:", sorted(p.name for p in tab_dir.glob("*.tex")))
    print("example cell:", example)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
