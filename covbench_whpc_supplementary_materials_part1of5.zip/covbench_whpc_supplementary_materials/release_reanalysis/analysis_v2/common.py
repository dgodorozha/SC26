"""Shared loading and oracle logic for the v2 analyses.

Everything here is computed from the released experiments.parquet alone.
Tier sets are read from the estimator_tier column of the data (which is
populated from config.yaml at run time), never hard coded.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ERROR_COL = "frobenius_loss"
COST_COL = "fit_wall_time_s"
EPS = 1e-8

WEIGHTINGS = [
    ("error_only", 1.0, 0.0),
    ("ab_0_9_0_1", 0.9, 0.1),
    ("ab_0_8_0_2", 0.8, 0.2),
    ("error_heavy", 0.7, 0.3),
    ("ab_0_6_0_4", 0.6, 0.4),
    ("balanced", 0.5, 0.5),
    ("ab_0_4_0_6", 0.4, 0.6),
    ("cost_heavy", 0.3, 0.7),
    ("ab_0_2_0_8", 0.2, 0.8),
    ("ab_0_1_0_9", 0.1, 0.9),
    ("cost_only", 0.0, 1.0),
]

PRETTY = {
    "sample_cov": "Sample",
    "ledoit_wolf_linear": "LW",
    "oas": "OAS",
    "nercome": "NERCOME",
    "hard_thresholding": "HardThr",
    "poet": "POET",
    "graphical_lasso": "GLasso",
    "tyler_m": "TylerM",
}


def load(data_dir: str | Path) -> pd.DataFrame:
    data_dir = Path(data_dir)
    df = pd.read_parquet(data_dir / "experiments.parquet")
    df = df[df.status == "success"].copy()
    # design point = everything that defines a cell except the replicate
    keys = ["structure_family", "structure_params_json", "spectrum_type",
            "spectrum_params_json", "distribution", "distribution_params_json", "n"]
    df["design"] = df[keys].astype(str).agg("|".join, axis=1)
    df["tier"] = df["estimator_tier"].astype(str)
    return df


def tiers_from_data(df: pd.DataFrame) -> dict[str, str]:
    return df.groupby("estimator_name")["tier"].first().to_dict()


def minmax(x: np.ndarray, floor: float = 0.0) -> np.ndarray:
    """Within group min max normalisation with an optional magnitude floor.

    floor = 0 reproduces the released normalisation exactly. For floor = tau
    the denominator becomes max(spread, tau), so when the absolute spread is
    below tau the normalised values are compressed proportionally.
    """
    lo, hi = np.min(x), np.max(x)
    den = max(hi - lo, floor) + EPS
    return (x - lo) / den


def zscore(x: np.ndarray, floor: float = 0.0) -> np.ndarray:
    sd = np.std(x)
    den = max(sd, floor) + EPS
    return (x - np.mean(x)) / den


def scalarised_oracle(E: np.ndarray, T: np.ndarray, alpha: float, beta: float,
                      tau: float = 0.0, norm: str = "minmax",
                      log_cost: bool = False) -> int:
    """Index of the argmin of alpha*E~ + beta*T~ within one decision group."""
    Tc = np.log(T) if log_cost else T
    if norm == "minmax":
        En, Tn = minmax(E), minmax(Tc, floor=tau)
    elif norm == "zscore":
        En, Tn = zscore(E), zscore(Tc, floor=tau)
    else:
        raise ValueError(norm)
    J = alpha * En + beta * Tn
    # deterministic tie break: lowest error, then lowest cost
    order = np.lexsort((T, E, J))
    return int(order[0])


def group_iter(df: pd.DataFrame, pooled: bool = False):
    """Yield (group_key, sub_df) for each decision group.

    pooled=False: groups are (cell_id, device), the released definition.
    pooled=True:  groups are cell_id with all (estimator, device) pairs, i.e.
                  the deployment configuration view of the general framework.
    """
    if pooled:
        for cid, g in df.groupby("cell_id", sort=False):
            yield cid, g
    else:
        for key, g in df.groupby(["cell_id", "device"], sort=False):
            yield key, g


def save_json(obj, path: str | Path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=float)
