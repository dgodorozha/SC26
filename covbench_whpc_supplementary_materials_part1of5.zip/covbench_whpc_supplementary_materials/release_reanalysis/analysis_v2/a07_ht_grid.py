"""A07: provenance check of the hard thresholding rows.

Rerunning the released code with the released configuration on the released cells
(notebook 1 smoke test) reproduced every closed form row to 1e-15 but not the hard
thresholding rows: the released rows record threshold quantiles (0.05, 0.85, 0.99, ...)
that are not in the released configuration's six value grid
{0.1, 0.25, 0.5, 0.75, 0.9, 0.95}. This script

  1. tabulates the quantiles recorded in the released hard thresholding rows;
  2. recomputes, on CPU, the hard thresholding fit for every cell under (a) the
     released six value grid and (b) the eleven value grid implied by the recorded
     quantiles, with the released seeds, and checks which one reproduces the released
     errors (CPU and GPU hard thresholding errors agree to 1e-15, so one CPU
     recomputation covers both devices);
  3. substitutes the six value grid errors into the released rows (times are kept,
     because times are hardware specific) and recomputes Phi, the cross tier
     migration within CPU groups and the device migration in pooled cells.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COST_COL, ERROR_COL, load, scalarised_oracle, save_json

def _find_code():
    """The released package: --code <dir> on the command line, else COVBENCH_CODE, else the bundled zip next to this
    folder (../covbench_code.zip, extracted on first use), else ../ext/code/covbench_code."""
    import zipfile
    here = Path(__file__).resolve().parent
    cands = []
    if "--code" in sys.argv:
        cands.append(Path(sys.argv[sys.argv.index("--code") + 1]))
    if "COVBENCH_CODE" in __import__("os").environ:
        cands.append(Path(__import__("os").environ["COVBENCH_CODE"]))
    z = here.parent / "covbench_code.zip"
    if z.exists():
        target = here.parent / "covbench_code_extracted"
        if not target.exists():
            with zipfile.ZipFile(z) as zf:
                zf.extractall(target)
        cands += [c.parent.parent for c in target.rglob("estimators.py") if c.parent.name == "covbench" and "__MACOSX" not in str(c)]
    cands.append(here.parents[1] / "ext" / "code" / "covbench_code")
    for c in cands:
        if (c / "covbench" / "estimators.py").exists():
            return c
    raise SystemExit("released code not found: pass --code <dir containing covbench/>, set COVBENCH_CODE, or place covbench_code.zip next to analysis_v2/")

CODE_DIR = _find_code()
sys.path.insert(0, str(CODE_DIR))
from covbench.config import load_config, expand_cells  # noqa: E402
from covbench.data import generate_cell  # noqa: E402
from covbench.seeds import derive_data_seed, derive_estimator_seed  # noqa: E402
from covbench.estimators import build_estimator  # noqa: E402
from covbench.hyperparams import select_hyperparameters  # noqa: E402
from covbench.metrics import frobenius_loss  # noqa: E402

GRID_CONFIG = [0.1, 0.25, 0.5, 0.75, 0.9, 0.95]
GRID_RECORDED = [0.05, 0.10, 0.15, 0.20, 0.25, 0.50, 0.75, 0.85, 0.90, 0.95, 0.99]


def ht_fit(X_np, grid, seed):
    X = torch.from_numpy(X_np).to(torch.float64)
    params = {"cv_folds": 3, "threshold_quantile_grid": grid}
    chosen, _ = select_hyperparameters("hard_thresholding", "cv_tuned", params, X, seed)
    Sh = build_estimator("hard_thresholding", chosen, seed=seed).fit(X).sigma_hat.numpy()
    return chosen["threshold_quantile"], Sh


def flags(df):
    rows = []
    for (cid, dev), g in df.groupby(["cell_id", "device"], sort=False):
        if len(g) != (8 if dev == "cpu" else 5):
            continue
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy(); tiers = g["tier"].to_numpy(); names = g["estimator_name"].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        rows.append({"cell_id": cid, "device": dev, "flip": int(i_eo != i_bal), "eo": names[i_eo], "bal": names[i_bal],
                     "c_to_b": int(tiers[i_eo] == "C" and tiers[i_bal] == "B"), "b_to_c": int(tiers[i_eo] == "B" and tiers[i_bal] == "C")})
    return pd.DataFrame(rows)


def pooled(df):
    rows = []
    for cid, g in df.groupby("cell_id", sort=False):
        if len(g) != 13:
            continue
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy(); devs = g["device"].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        rows.append({"cell_id": cid, "cfg_flip": int(i_eo != i_bal),
                     "cpu_to_cuda": int(devs[i_eo] == "cpu" and devs[i_bal] == "cuda"),
                     "cuda_to_cpu": int(devs[i_eo] == "cuda" and devs[i_bal] == "cpu")})
    return pd.DataFrame(rows)


def main(data_dir, out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    df = load(data_dir)
    ht = df[df.estimator_name == "hard_thresholding"].copy()
    ht["q"] = ht["hyperparams_chosen_json"].apply(lambda s: json.loads(s).get("threshold_quantile"))
    res = {"config_grid": GRID_CONFIG, "recorded_quantile_counts": {str(k): int(v) for k, v in ht["q"].value_counts().sort_index().items()},
           "recorded_grid": sorted(ht["q"].unique().tolist()),
           "frac_rows_with_quantile_outside_config_grid": float((~ht["q"].isin(GRID_CONFIG)).mean()),
           "frac_rows_at_0_99": float((ht["q"] == 0.99).mean())}
    print("recorded quantiles:", res["recorded_quantile_counts"])
    print(f"rows outside the config grid: {res['frac_rows_with_quantile_outside_config_grid']:.3f}; at 0.99: {res['frac_rows_at_0_99']:.3f}")

    # ---- recompute on CPU under both grids ----
    cfg = load_config(CODE_DIR / "config.yaml")
    cells = {c.cell_id: c for c in expand_cells(cfg)}
    ht_cpu = ht[ht.device == "cpu"].drop_duplicates("cell_id").set_index("cell_id")
    recs = []; t0 = time.time()
    for i, (cid, row) in enumerate(ht_cpu.iterrows()):
        cell = cells.get(cid)
        if cell is None:
            continue
        X, Sigma, _ = generate_cell(cell, cfg.salt)
        seed = int(derive_estimator_seed(derive_data_seed(cell.cell_key, cfg.salt), "hard_thresholding", "cv_tuned"))
        q6, Sh6 = ht_fit(X, GRID_CONFIG, seed); q11, Sh11 = ht_fit(X, GRID_RECORDED, seed)
        recs.append({"cell_id": cid, "q_released": row["q"], "E_released": row[ERROR_COL],
                     "q_grid6": q6, "E_grid6": frobenius_loss(Sh6, Sigma), "q_grid11": q11, "E_grid11": frobenius_loss(Sh11, Sigma)})
        if i % 200 == 0:
            print(f"  {i}/{len(ht_cpu)} cells, {time.time()-t0:.0f}s")
    R = pd.DataFrame(recs); R.to_csv(out_dir / "a07_ht_recompute.csv", index=False)
    R["rel11"] = (R.E_grid11 - R.E_released).abs() / R.E_released; R["rel6"] = (R.E_grid6 - R.E_released).abs() / R.E_released
    res["recompute"] = {"n_cells": int(len(R)),
                        "grid11_reproduces_released_error_frac_1e-8": float((R.rel11 < 1e-8).mean()),
                        "grid11_same_quantile_frac": float((R.q_grid11 == R.q_released).mean()),
                        "grid11_max_rel_discrepancy": float(R.rel11.max()),
                        "grid6_rel_discrepancy_median": float(R.rel6.median()), "grid6_rel_discrepancy_max": float(R.rel6.max()),
                        "grid6_error_higher_frac": float((R.E_grid6 > R.E_released * (1 + 1e-8)).mean()),
                        "grid6_quantile_counts": {str(k): int(v) for k, v in R.q_grid6.value_counts().sort_index().items()}}
    print(json.dumps(res["recompute"], indent=2))

    # ---- substitute six value grid errors and recompute the headline quantities ----
    E6 = R.set_index("cell_id")["E_grid6"]
    df6 = df.copy()
    m = df6.estimator_name == "hard_thresholding"
    df6.loc[m, ERROR_COL] = df6.loc[m, "cell_id"].map(E6).fillna(df6.loc[m, ERROR_COL])
    F0, F6 = flags(df), flags(df6); P0, P6 = pooled(df), pooled(df6)
    J = F0.merge(F6, on=["cell_id", "device"], suffixes=("", "_6"))
    res["headline"] = {
        "phi_released": float(F0.flip.mean()), "phi_grid6": float(F6.flip.mean()),
        "phi_cpu_released": float(F0[F0.device == "cpu"].flip.mean()), "phi_cpu_grid6": float(F6[F6.device == "cpu"].flip.mean()),
        "phi_cuda_released": float(F0[F0.device == "cuda"].flip.mean()), "phi_cuda_grid6": float(F6[F6.device == "cuda"].flip.mean()),
        "c_to_b_cpu_released": float(F0[F0.device == "cpu"].c_to_b.mean()), "c_to_b_cpu_grid6": float(F6[F6.device == "cpu"].c_to_b.mean()),
        "b_to_c_cpu_released": float(F0[F0.device == "cpu"].b_to_c.mean()), "b_to_c_cpu_grid6": float(F6[F6.device == "cpu"].b_to_c.mean()),
        "cpu_to_cuda_pooled_released": float(P0.cpu_to_cuda.mean()), "cpu_to_cuda_pooled_grid6": float(P6.cpu_to_cuda.mean()),
        "cuda_to_cpu_pooled_released": float(P0.cuda_to_cpu.mean()), "cuda_to_cpu_pooled_grid6": float(P6.cuda_to_cpu.mean()),
        "frac_groups_eo_oracle_changes": float((J.eo != J.eo_6).mean()), "frac_groups_bal_oracle_changes": float((J.bal != J.bal_6).mean()),
        "frac_groups_flip_changes": float((J.flip != J.flip_6).mean()),
        "ht_is_eo_oracle_released": float((F0.eo == "hard_thresholding").mean()), "ht_is_eo_oracle_grid6": float((F6.eo == "hard_thresholding").mean()),
        "ht_is_bal_oracle_released": float((F0.bal == "hard_thresholding").mean()), "ht_is_bal_oracle_grid6": float((F6.bal == "hard_thresholding").mean()),
    }
    print(json.dumps(res["headline"], indent=2))
    save_json(res, out_dir / "a07_ht_grid.json")
    write_table(res, out_dir)


def write_table(res, out_dir):
    """tab_ht_grid.tex: released rows versus the released six value grid."""
    h = res["headline"]; tab = Path(out_dir) / "tables"; tab.mkdir(exist_ok=True)
    def pc(x): return f"{100*x:.1f}\\%"
    rows = [r"\begin{tabular}{@{}lcc@{}}", r"\toprule", r"Quantity & released rows & six value grid \\", r"\midrule",
            f"$\\Phi$, all complete groups & {h['phi_released']:.3f} & {h['phi_grid6']:.3f} \\\\",
            f"$\\Phi$, CPU groups & {h['phi_cpu_released']:.3f} & {h['phi_cpu_grid6']:.3f} \\\\",
            f"$\\Phi$, GPU groups & {h['phi_cuda_released']:.3f} & {h['phi_cuda_grid6']:.3f} \\\\",
            f"Tier C$\\to$B, CPU groups & {pc(h['c_to_b_cpu_released'])} & {pc(h['c_to_b_cpu_grid6'])} \\\\",
            f"Tier B$\\to$C, CPU groups & {pc(h['b_to_c_cpu_released'])} & {pc(h['b_to_c_cpu_grid6'])} \\\\",
            f"CPU$\\to$GPU, pooled cells & {pc(h['cpu_to_cuda_pooled_released'])} & {pc(h['cpu_to_cuda_pooled_grid6'])} \\\\",
            f"GPU$\\to$CPU, pooled cells & {pc(h['cuda_to_cpu_pooled_released'])} & {pc(h['cuda_to_cpu_pooled_grid6'])} \\\\",
            f"Hard thresholding is the balanced oracle & {pc(h['ht_is_bal_oracle_released'])} & {pc(h['ht_is_bal_oracle_grid6'])} \\\\",
            f"Groups whose flip status changes & \\multicolumn{{2}}{{c}}{{{pc(h['frac_groups_flip_changes'])}}} \\\\",
            r"\bottomrule", r"\end{tabular}"]
    (tab / "tab_ht_grid.tex").write_text("\n".join(rows) + "\n")
    print("wrote", tab / "tab_ht_grid.tex")


if __name__ == "__main__":
    if "--table-only" in sys.argv:
        write_table(json.load(open(Path(sys.argv[2]) / "a07_ht_grid.json")), sys.argv[2])
    else:
        main(sys.argv[1], sys.argv[2])
