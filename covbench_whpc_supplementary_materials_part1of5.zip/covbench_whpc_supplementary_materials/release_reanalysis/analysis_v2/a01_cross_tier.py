"""A01: Cross tier migration, recomputed with tier sets from the data.

Two views are reported.

(a) Within CPU decision groups. Only CPU groups contain both Tier B and
    Tier C estimators, so this is the only place a cross tier flip is well
    posed under the released (cell, device) group definition.

(b) Cell level pooled view. All 13 (estimator, device) configurations of a
    cell are normalised together, so the oracle is a deployment
    configuration (e, h). Migration is then reported both across tiers and
    across devices. This is the general framework's selectable object
    applied to the existing data.

Also reports the headline on complete groups only (groups where every
scheduled estimator succeeded) to answer the incomplete CUDA panel point.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (COST_COL, ERROR_COL, WEIGHTINGS, load, scalarised_oracle,
                    save_json, tiers_from_data)


def oracles_by_weighting(df, pooled):
    """Return a DataFrame: one row per group, one column per weighting with
    the oracle estimator name (and device if pooled)."""
    rows = []
    keys = ["cell_id"] if pooled else ["cell_id", "device"]
    for key, g in df.groupby(keys, sort=False):
        E = g[ERROR_COL].to_numpy()
        T = g[COST_COL].to_numpy()
        names = g["estimator_name"].to_numpy()
        devs = g["device"].to_numpy()
        tiers = g["tier"].to_numpy()
        row = {"cell_id": key if pooled else key[0],
               "device": "pooled" if pooled else key[1],
               "n_in_group": len(g)}
        for wname, a, b in WEIGHTINGS:
            i = scalarised_oracle(E, T, a, b)
            row[f"est_{wname}"] = names[i]
            row[f"dev_{wname}"] = devs[i]
            row[f"tier_{wname}"] = tiers[i]
        rows.append(row)
    return pd.DataFrame(rows)


def migration_table(orc, targets=("balanced", "cost_heavy", "ab_0_1_0_9", "cost_only")):
    out = []
    for w in targets:
        e_t, c_t = orc["tier_error_only"], orc[f"tier_{w}"]
        n = len(orc)
        out.append({
            "weighting": w,
            "Y_B_to_C": float(((e_t == "B") & (c_t == "C")).mean()),
            "Y_C_to_B": float(((e_t == "C") & (c_t == "B")).mean()),
            "stay_B": float(((e_t == "B") & (c_t == "B")).mean()),
            "stay_C": float(((e_t == "C") & (c_t == "C")).mean()),
            "n": n,
        })
    return pd.DataFrame(out)


def main(data_dir, out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = load(data_dir)
    tiers = tiers_from_data(df)
    print("Tier sets from data:", tiers)

    # ---- headline on released groups and on complete groups ----
    orc = oracles_by_weighting(df, pooled=False)
    phi_all = float((orc["est_error_only"] != orc["est_balanced"]).mean())
    expected = orc["device"].map({"cpu": 8, "cuda": 5})
    complete = orc[orc["n_in_group"] == expected]
    phi_complete = float((complete["est_error_only"] != complete["est_balanced"]).mean())
    print(f"Phi all groups      = {phi_all:.4f}  (n={len(orc)})")
    print(f"Phi complete groups = {phi_complete:.4f}  (n={len(complete)})")
    incomplete = orc[orc["n_in_group"] != expected]
    print(f"incomplete groups: {len(incomplete)}; n_in_group counts:",
          incomplete["n_in_group"].value_counts().to_dict())

    # ---- (a) within CPU groups ----
    cpu = orc[orc["device"] == "cpu"]
    tab_cpu = migration_table(cpu)
    tab_cpu_complete = migration_table(complete[complete["device"] == "cpu"])
    print("\n(a) Cross tier migration within CPU groups:")
    print(tab_cpu.to_string(index=False))

    # tier frequencies under each weighting, CPU groups
    freq = {}
    for wname, _, _ in WEIGHTINGS:
        vc = cpu[f"tier_{wname}"].value_counts(normalize=True)
        freq[wname] = {"B": float(vc.get("B", 0.0)), "C": float(vc.get("C", 0.0))}
    est_freq = {}
    for wname, _, _ in WEIGHTINGS:
        est_freq[wname] = cpu[f"est_{wname}"].value_counts(normalize=True).round(4).to_dict()

    # ---- (b) pooled cell level view ----
    orcp_all = oracles_by_weighting(df, pooled=True)
    # complete cells only (all 13 configurations present), the same denominator
    # as the design point bootstrap of a04, so that point estimates and CIs match
    orcp = orcp_all[orcp_all["n_in_group"] == 13].reset_index(drop=True)
    print(f"\npooled cells: {len(orcp_all)} total, {len(orcp)} complete (13 configurations)")
    tab_pool = migration_table(orcp)
    print("\n(b) Cross tier migration, cell level pooled across devices:")
    print(tab_pool.to_string(index=False))
    dev_mig = []
    for w in ("balanced", "cost_heavy", "ab_0_1_0_9", "cost_only"):
        e_d, c_d = orcp["dev_error_only"], orcp[f"dev_{w}"]
        dev_mig.append({
            "weighting": w,
            "cpu_to_cuda": float(((e_d == "cpu") & (c_d == "cuda")).mean()),
            "cuda_to_cpu": float(((e_d == "cuda") & (c_d == "cpu")).mean()),
            "stay_cpu": float(((e_d == "cpu") & (c_d == "cpu")).mean()),
            "stay_cuda": float(((e_d == "cuda") & (c_d == "cuda")).mean()),
        })
    dev_mig = pd.DataFrame(dev_mig)
    print("\n(b) Device migration, pooled view:")
    print(dev_mig.to_string(index=False))
    phi_pooled_cfg = float(((orcp["est_error_only"] != orcp["est_balanced"]) |
                            (orcp["dev_error_only"] != orcp["dev_balanced"])).mean())
    phi_pooled_est = float((orcp["est_error_only"] != orcp["est_balanced"]).mean())
    print(f"\nPooled view: configuration flip rate = {phi_pooled_cfg:.4f}; "
          f"estimator only flip rate = {phi_pooled_est:.4f}")
    # what fraction of pooled error only oracles are on cuda already
    print("pooled error_only oracle device:", orcp["dev_error_only"].value_counts(normalize=True).round(3).to_dict())
    print("pooled balanced oracle device:  ", orcp["dev_balanced"].value_counts(normalize=True).round(3).to_dict())

    # ---- save ----
    orc.to_csv(out_dir / "a01_oracles_by_group.csv", index=False)
    orcp_all.to_csv(out_dir / "a01_oracles_by_cell_pooled.csv", index=False)
    tab_cpu.to_csv(out_dir / "a01_cross_tier_cpu.csv", index=False)
    tab_pool.to_csv(out_dir / "a01_cross_tier_pooled.csv", index=False)
    dev_mig.to_csv(out_dir / "a01_device_migration_pooled.csv", index=False)
    save_json({
        "tiers": tiers,
        "phi_all_groups": phi_all, "n_groups": int(len(orc)),
        "phi_complete_groups": phi_complete, "n_complete_groups": int(len(complete)),
        "n_pooled_cells_all": int(len(orcp_all)), "n_pooled_cells_complete": int(len(orcp)),
        "n_incomplete_groups": int(len(incomplete)),
        "incomplete_sizes": {int(k): int(v) for k, v in incomplete["n_in_group"].value_counts().items()},
        "cross_tier_cpu": tab_cpu.to_dict(orient="records"),
        "cross_tier_cpu_complete": tab_cpu_complete.to_dict(orient="records"),
        "cross_tier_pooled": tab_pool.to_dict(orient="records"),
        "device_migration_pooled": dev_mig.to_dict(orient="records"),
        "tier_freq_cpu": freq,
        "estimator_freq_cpu": est_freq,
        "phi_pooled_configuration": phi_pooled_cfg,
        "phi_pooled_estimator_only": phi_pooled_est,
        "pooled_error_only_device": orcp["dev_error_only"].value_counts(normalize=True).to_dict(),
        "pooled_balanced_device": orcp["dev_balanced"].value_counts(normalize=True).to_dict(),
    }, out_dir / "a01_cross_tier.json")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
