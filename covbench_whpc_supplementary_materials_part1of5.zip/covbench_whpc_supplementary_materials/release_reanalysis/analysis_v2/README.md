# analysis_v2

Recomputation of every CovBench number in the paper from the released rows, plus the new analyses.
Layout expected by `run_all.sh`:

    <folder>/analysis_v2/           these scripts
    <folder>/covbench_code.zip      the released code (included in this bundle; a07 extracts it on first use)
    <folder>/data/experiments.parquet   the released rows (included in this bundle, sha256 d03a920e5cae41e5...)

    bash analysis_v2/run_all.sh data outputs

Scripts, in the order `run_all.sh` runs them:

| script | what it computes | output |
|---|---|---|
| `a01_cross_tier.py` | headline on all and on complete groups, cross tier migration within CPU groups, device migration in complete pooled cells, tiers read from the data | `a01_cross_tier.json`, csv |
| `a02_normalisation.py` | spreads, exchange rates, flip anatomy, gate sweep, exact flip criterion check | `a02_normalisation.json`, csv |
| `a03_pareto_budget.py` | Pareto sets, supported points, budget rule over 26 sampled budgets (efficient set under the 1e-8 tolerance), regret weighting | `a03_pareto_budget.json`, csv |
| `a04_uncertainty.py` | replicate level spread, design point cluster bootstrap (2,000 resamples, seed 20261102), ROCm sensitivity | `a04_uncertainty.json`, csv |
| `a06_cpu_gpu_equivalence.py` | CPU versus GPU discrepancy of the five dual device estimators over the recorded metrics (Frobenius loss, then the two direct and the four inverse based metrics, the latter on non singular cells); the release stores no fitted matrices, so the matrix distance itself is measured by block 1 of the notebooks | `a06_cpu_gpu_equivalence.json`, `tables/tab_equivalence.tex` |
| `a07_ht_grid.py` | hard thresholding tuning grid provenance check (reruns the released code; `--code <dir>` or `COVBENCH_CODE` override the code location) | `a07_ht_grid.json`, csv, `tables/tab_ht_grid.tex` |
| `a05_figures_tables.py` | every figure and table fragment of the paper and `paper_numbers.json`, the single source for every number quoted | `figures/`, `tables/`, `paper_numbers.json` |

`common.py` holds the shared loader, the scalarised oracle with the lexicographic tie break, the normalisations and the
eleven weightings. Requirements: numpy, pandas, pyarrow, matplotlib, scikit-learn; a07 also needs torch (CPU is enough).
The `outputs/` folder in this bundle is the result of running the sequence on the released rows.
