"""A03: Pareto sets, supported efficient points, and budget constrained selection.

For each decision group with points (T_e, E_e):
  * Pareto set P(g): configurations not dominated in (T, E) (both minimised).
  * Supported set S(g) subset of P(g): efficient points on the lower left
    convex hull of the attainable set. A weighted sum with positive weights
    (any normalisation that is affine within the group) can only select
    supported points (Geoffrion 1968). Unsupported efficient points can be
    selected only by a constrained rule such as the budget rule.
  * Budget rule: a_B = argmin E subject to T <= B. Sweeping B traces the
    group's accuracy cost frontier; every point selected is efficient and
    every efficient point is selected for some B.

We report, over all complete groups: sizes of P and S, the fraction of
groups with at least one unsupported efficient point, how often the budget
oracle is unsupported (as a function of B), agreement between budget oracle
and scalarised oracles, and the regret weighted flip rate.

Also computed in the pooled (cell level, 13 configurations) view, which is
the deployment configuration view of the general framework.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COST_COL, ERROR_COL, WEIGHTINGS, load, scalarised_oracle, save_json

BUDGETS = np.logspace(-3, 2, 26)  # 1 ms to 100 s


REL_TOL = 1e-8  # matches the CPU/GPU equivalence audit tolerance


def pareto_mask(T, E):
    """Non dominated points in (T, E), both minimised. Errors within relative
    REL_TOL are treated as equal so that the CPU and GPU paths of one
    estimator (verified equivalent to 1e-8) do not create spurious efficient
    points through floating point noise."""
    n = len(T); keep = np.ones(n, dtype=bool)
    for i in range(n):
        Eeq = np.abs(E - E[i]) <= REL_TOL * max(abs(E[i]), 1e-300)
        Ele = (E < E[i]) | Eeq
        Elt = (E < E[i]) & ~Eeq
        dom = (T <= T[i]) & Ele & ((T < T[i]) | Elt)
        dom[i] = False
        if dom.any():
            keep[i] = False
    return keep


def supported_mask(T, E, par):
    """Efficient points on the lower left convex hull (in raw (T, E) space).
    Convexity is affine invariant, so the same set results under any within
    group affine normalisation (min max, z score), which is why a weighted
    sum of normalised objectives can never reach an unsupported point."""
    idx = np.where(par)[0]
    if len(idx) <= 2:
        return par.copy()
    pts = sorted(idx, key=lambda i: (T[i], E[i]))
    # lower convex hull by monotone chain on points sorted by T (E decreasing along the front)
    hull = []
    for i in pts:
        while len(hull) >= 2:
            a, b = hull[-2], hull[-1]
            cross = (T[b] - T[a]) * (E[i] - E[a]) - (E[b] - E[a]) * (T[i] - T[a])
            if cross <= 0:  # b is above or on the segment a-i: not on lower hull
                hull.pop()
            else:
                break
        hull.append(i)
    sup = np.zeros_like(par)
    sup[hull] = True
    return sup


def analyse(groups, tag, out_dir):
    rows = []; budget_rows = []
    for key, g in groups:
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
        names = g["estimator_name"].to_numpy(); devs = g["device"].to_numpy()
        par = pareto_mask(T, E); sup = supported_mask(T, E, par)
        n_par, n_sup = int(par.sum()), int(sup.sum())
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        # which scalarised oracles over the 11 point grid are reached
        reached = set(scalarised_oracle(E, T, a, b) for _, a, b in WEIGHTINGS)
        rows.append({
            "key": str(key), "n": len(E), "n_pareto": n_par, "n_supported": n_sup,
            "n_unsupported": n_par - n_sup, "has_unsupported": int(n_par > n_sup),
            "n_reached_by_grid": len(reached),
            "frac_pareto_reached": len(reached & set(np.where(par)[0])) / n_par,
            "eo_is_pareto": int(par[i_eo]), "bal_is_pareto": int(par[i_bal]),
            "T_min": T.min(), "T_max": T.max(),
        })
        # budget sweep
        for B in BUDGETS:
            feas = T <= B
            if not feas.any():
                budget_rows.append({"key": str(key), "B": B, "feasible": 0}); continue
            # argmin E over feasible configurations, restricted to the efficient set under the same
            # tolerance as pareto_mask: without this, the CPU and GPU rows of one estimator (equal
            # errors to 1e-15) let the rule pick the slower twin on floating point noise, which is
            # dominated under the tolerance and so was miscounted as unsupported
            cand = np.where(feas & par)[0]
            j = cand[np.lexsort((T[cand], E[cand]))[0]]
            # regret of the error only oracle under this budget: if infeasible, regret = inf
            budget_rows.append({
                "key": str(key), "B": B, "feasible": 1, "budget_oracle": names[j],
                "budget_device": devs[j], "is_supported": int(sup[j]), "is_pareto": int(par[j]),
                "equals_eo": int(j == i_eo), "equals_bal": int(j == i_bal),
                "eo_feasible": int(feas[i_eo]), "bal_feasible": int(feas[i_bal]),
                "regret_eo_rel": (E[i_eo] - E[j]) / E[j] if feas[i_eo] else np.nan,
                "regret_bal_rel": (E[i_bal] - E[j]) / E[j] if feas[i_bal] else np.nan,
            })
    R = pd.DataFrame(rows); Bd = pd.DataFrame(budget_rows)
    R.to_csv(out_dir / f"a03_pareto_{tag}.csv", index=False)
    Bd.to_csv(out_dir / f"a03_budget_{tag}.csv", index=False)

    summ = {
        "n_groups": int(len(R)),
        "pareto_size_dist": R["n_pareto"].value_counts().sort_index().to_dict(),
        "supported_size_dist": R["n_supported"].value_counts().sort_index().to_dict(),
        "mean_pareto": float(R["n_pareto"].mean()), "mean_supported": float(R["n_supported"].mean()),
        "frac_groups_with_unsupported": float(R["has_unsupported"].mean()),
        "total_unsupported_points": int(R["n_unsupported"].sum()),
        "total_pareto_points": int(R["n_pareto"].sum()),
        "mean_frac_pareto_reached_by_11_grid": float(R["frac_pareto_reached"].mean()),
        "eo_is_pareto": float(R["eo_is_pareto"].mean()), "bal_is_pareto": float(R["bal_is_pareto"].mean()),
    }
    fb = Bd[Bd.feasible == 1]
    byB = fb.groupby("B").agg(
        n_feasible=("feasible", "size"), frac_unsupported=("is_supported", lambda s: 1 - s.mean()),
        agree_eo=("equals_eo", "mean"), agree_bal=("equals_bal", "mean"),
        eo_feasible=("eo_feasible", "mean"), bal_feasible=("bal_feasible", "mean"),
        regret_eo_median=("regret_eo_rel", "median"), regret_bal_median=("regret_bal_rel", "median"),
    ).reset_index()
    byB["frac_groups_feasible"] = byB["n_feasible"] / len(R)
    byB.to_csv(out_dir / f"a03_budget_by_B_{tag}.csv", index=False)
    summ["budget_by_B"] = byB.to_dict(orient="records")
    # fraction of groups where the budget oracle is unsupported for at least one B
    summ["frac_groups_budget_unsupported_some_B"] = float(
        fb.groupby("key")["is_supported"].apply(lambda s: (s == 0).any()).mean())
    print(f"\n[{tag}] groups={len(R)} mean |P|={summ['mean_pareto']:.2f} mean |S|={summ['mean_supported']:.2f} "
          f"groups with unsupported efficient pt={summ['frac_groups_with_unsupported']:.3f} "
          f"unsupported/pareto pts={summ['total_unsupported_points']}/{summ['total_pareto_points']}")
    print(f"[{tag}] 11 point grid reaches on average {summ['mean_frac_pareto_reached_by_11_grid']:.3f} of each group's Pareto set")
    print(f"[{tag}] budget oracle unsupported for some B in {summ['frac_groups_budget_unsupported_some_B']:.3f} of groups")
    print(byB[["B", "frac_groups_feasible", "frac_unsupported", "agree_eo", "agree_bal", "eo_feasible"]].to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    return summ


def main(data_dir, out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = load(data_dir)
    groups = []
    for (cid, dev), g in df.groupby(["cell_id", "device"], sort=False):
        if len(g) == (8 if dev == "cpu" else 5):
            groups.append(((cid, dev), g))
    pooled = [(cid, g) for cid, g in df.groupby("cell_id", sort=False) if len(g) == 13]
    out = {"released_groups": analyse(groups, "groups", out_dir),
           "pooled_cells": analyse(pooled, "pooled", out_dir)}

    # ---- regret weighted flip rate on released groups ----
    reg = []
    for key, g in groups:
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        if i_eo == i_bal:
            reg.append({"flip": 0, "w_err": 0.0, "w_time": 0.0}); continue
        reg.append({"flip": 1,
                    "w_err": (E[i_bal] - E[i_eo]) / E[i_eo],       # relative accuracy given up
                    "w_time": (T[i_eo] - T[i_bal]) / T[i_eo]})     # relative time saved
    reg = pd.DataFrame(reg)
    out["regret_weighted"] = {
        "phi": float(reg.flip.mean()),
        "phi_err_weighted": float(reg.w_err.mean()),     # mean relative error regret per group (0 when no flip)
        "phi_time_weighted": float(reg.w_time.mean()),   # mean relative time saved per group
        "mean_err_regret_given_flip": float(reg[reg.flip == 1].w_err.mean()),
        "median_err_regret_given_flip": float(reg[reg.flip == 1].w_err.median()),
        "mean_time_saved_frac_given_flip": float(reg[reg.flip == 1].w_time.mean()),
        "median_time_saved_frac_given_flip": float(reg[reg.flip == 1].w_time.median()),
        "frac_flips_err_regret_lt_5pct": float((reg[reg.flip == 1].w_err < 0.05).mean()),
        "frac_flips_time_saved_gt_90pct": float((reg[reg.flip == 1].w_time > 0.9).mean()),
    }
    print("\nRegret weighted:", out["regret_weighted"])
    save_json(out, out_dir / "a03_pareto_budget.json")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
