"""A06: CPU versus GPU audit of the five dual device estimators on the production grid, over recorded metrics.

The release stores six scalar metrics of each fit and not the fitted matrix, so this audit compares recorded
metrics, not matrices. For every cell where an estimator has a successful CPU row and a successful GPU row it
computes the relative discrepancy |m_cpu - m_gpu| / |m_cpu| of the Frobenius loss (the loss the oracle uses),
then the largest discrepancy over the two direct metrics (Frobenius and operator loss) and over the four
inverse based metrics (Stein, KL, precision Frobenius and operator), the latter only on cells where both paths
record a condition number below COND_MAX, since they are undefined for a singular estimate. Equal matrices give
equal metrics, so a metric that differs proves the matrices differ; metrics that agree are evidence, not proof,
that the matrices agree, and the relative distance between the matrices themselves is measured by block 1 of
the released notebooks on each accelerator it runs on. The earlier release asserted 1e-8 matrix agreement for
all five estimators. Writes a06_cpu_gpu_equivalence.json and tables/tab_equivalence.tex.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ERROR_COL, PRETTY, load, save_json

DUAL = ["sample_cov", "ledoit_wolf_linear", "nercome", "hard_thresholding", "poet"]
# every scalar metric the release records for a fit; the fitted matrices themselves are not in the release, so the
# audit is of recorded metrics (the notebooks compare the matrices directly on each accelerator they run on)
DIRECT = ["frobenius_loss", "operator_loss"]                                            # functions of the estimate itself
INVERSE = ["stein_loss", "kl_divergence", "precision_frobenius", "precision_operator"]    # functions of its inverse: undefined when the estimate is singular
METRICS = DIRECT + INVERSE
COND_MAX = 1e10   # inverse based metrics are compared only where both paths record a condition number below this


def main(data_dir, out_dir):
    out_dir = Path(out_dir); (out_dir / "tables").mkdir(parents=True, exist_ok=True)
    df = load(data_dir)
    res = {}
    for name in DUAL:
        d = df[df.estimator_name == name]
        cols = [m for m in METRICS if m in d]
        cpu = d[d.device == "cpu"].set_index("cell_id")[cols + ["p_over_n", "condition_number_estimate"]]
        gpu = d[d.device == "cuda"].set_index("cell_id")[cols + ["condition_number_estimate"]]
        j = cpu.join(gpu, rsuffix="_gpu", how="inner")
        disc = (j[ERROR_COL] - j[ERROR_COL + "_gpu"]).abs() / j[ERROR_COL].abs()
        nonsing = (j["condition_number_estimate"] < COND_MAX) & (j["condition_number_estimate_gpu"] < COND_MAX)
        per_metric = {}
        for m in cols:
            a, b = j[m], j[m + "_gpu"]; ok = np.isfinite(a) & np.isfinite(b) & (a.abs() > 0)
            if m in INVERSE: ok &= nonsing
            per_metric[m] = ((a[ok] - b[ok]).abs() / a[ok].abs())
        direct = pd.concat([per_metric[m] for m in DIRECT if m in per_metric], axis=1).max(axis=1)
        inverse = pd.concat([per_metric[m] for m in INVERSE if m in per_metric], axis=1).max(axis=1)
        res[name] = {"n": int(len(j)), "median": float(disc.median()), "p99": float(disc.quantile(0.99)), "max": float(disc.max()),
                     "frac_gt_1e-8": float((disc > 1e-8).mean()), "frac_gt_1e-2": float((disc > 1e-2).mean()),
                     "by_p_over_n_max": {str(k): float(v) for k, v in disc.groupby(j["p_over_n"]).max().items()},
                     "direct_metrics_max": float(direct.max()), "inverse_metrics_max_nonsingular": float(inverse.max()) if len(inverse) else None,
                     "n_nonsingular_pairs": int(nonsing.sum()), "per_metric_max": {m: float(v.max()) if len(v) else None for m, v in per_metric.items()},
                     "note": f"inverse based metrics compared on the {int(nonsing.sum())} cells where both paths record a condition number below {COND_MAX:g}"}
        print(f"{name:20s} n={len(j)} Frobenius: median={res[name]['median']:.2e} max={res[name]['max']:.2e} >1e-8: {res[name]['frac_gt_1e-8']:.3f} | direct metrics max {res[name]['direct_metrics_max']:.1e} | inverse based (non singular, n={int(nonsing.sum())}) max {res[name]['inverse_metrics_max_nonsingular']:.1e}")
    save_json(res, out_dir / "a06_cpu_gpu_equivalence.json")
    # main table: the Frobenius loss discrepancy and the maxima over the recorded metrics; the appendix table carries the regime detail
    rows = [r"\begin{tabular}{@{}lrcccccc@{}}", r"\toprule",
            r" & & \multicolumn{3}{c}{Frobenius loss discrepancy} & \multicolumn{2}{c}{max over recorded metrics} & \\",
            r"\cmidrule(lr){3-5} \cmidrule(lr){6-7}", r"Estimator & paired cells & median & max & above $10^{-8}$ & direct & inverse based & non singular \\", r"\midrule"]
    for name in DUAL:
        r = res[name]
        rows.append(f"{PRETTY[name]} & {r['n']} & {r['median']:.1e} & {r['max']:.1e} & {100*r['frac_gt_1e-8']:.1f}\\% & {r['direct_metrics_max']:.1e} & {r['inverse_metrics_max_nonsingular']:.1e} & {r['n_nonsingular_pairs']} \\\\")
    rows += [r"\bottomrule", r"\end{tabular}"]
    (out_dir / "tables" / "tab_equivalence.tex").write_text("\n".join(rows))
    rows = [r"\begin{tabular}{@{}lcccc@{}}", r"\toprule",
            r" & & \multicolumn{3}{c}{max by $p/n$} \\", r"\cmidrule(lr){3-5}", r"Estimator & 99th percentile & 0.5 & 1 & 2 \\", r"\midrule"]
    for name in DUAL:
        r = res[name]; b = r["by_p_over_n_max"]
        rows.append(f"{PRETTY[name]} & {r['p99']:.1e} & {b['0.5']:.1e} & {b['1.0']:.1e} & {b['2.0']:.1e} \\\\")
    rows += [r"\bottomrule", r"\end{tabular}"]
    (out_dir / "tables" / "tab_equivalence_regime.tex").write_text("\n".join(rows))
    print("wrote", out_dir / "a06_cpu_gpu_equivalence.json", "and tables/tab_equivalence.tex, tab_equivalence_regime.tex")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
