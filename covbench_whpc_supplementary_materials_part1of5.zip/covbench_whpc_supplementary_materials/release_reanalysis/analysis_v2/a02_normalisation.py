"""A02: Normalisation validity.

Answers the objection that min max normalisation stretches an arbitrarily
small runtime spread onto [0, 1] so that a "balanced" weighting can be
decided by negligible absolute differences.

1. Exchange rate. Under within group min max with alpha = beta, one unit of
   normalised error is worth one unit of normalised cost, i.e. the implied
   rate is dE/dT Frobenius per second, where dE and dT are the group spreads.
   We report the distribution of dT (absolute runtime spread) and of the
   implied rate.

2. Flipped groups. For every group that flips between error only and
   balanced, we report the absolute runtime saved and the relative error
   given up. If flips were being manufactured from negligible spreads, the
   runtime savings would be tiny.

3. Magnitude gate. T~_tau = (T - Tmin) / max(dT, tau). For dT >= tau this is
   the released normalisation; for dT < tau the cost term is compressed by
   dT / tau. We sweep tau and report Phi(tau). The same gate is applied to
   z score and log cost variants.

4. Sensitivity bound (verified numerically). With alpha = beta = 1/2 a group
   flips iff some e != e* satisfies (E(e) - E*) dT < (T* - T(e)) dE. In
   particular no flip is possible when dT < tau* := dE * min_{e != e*}
   (E(e) - E*) / max_e (T* - T(e)) ... we report the empirical fraction of
   flips as a function of dT to show where flips live.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COST_COL, ERROR_COL, load, scalarised_oracle, save_json

TAUS = [0.0, 1e-3, 3e-3, 1e-2, 3e-2, 1e-1, 3e-1, 1.0, 3.0, 10.0]


def main(data_dir, out_dir, complete_only=True):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = load(data_dir)

    groups = []
    for (cid, dev), g in df.groupby(["cell_id", "device"], sort=False):
        expected = 8 if dev == "cpu" else 5
        if complete_only and len(g) != expected:
            continue
        groups.append((cid, dev, g))
    n = len(groups)
    print(f"groups used: {n}")

    # ---- per group spreads, exchange rate, flip ----
    rows = []
    for cid, dev, g in groups:
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
        names = g["estimator_name"].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0)
        i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        dE, dT = E.max() - E.min(), T.max() - T.min()
        rows.append({
            "cell_id": cid, "device": dev,
            "dE": dE, "dT": dT, "T_min": T.min(), "T_max": T.max(),
            "E_min": E.min(), "rate_frob_per_s": dE / dT if dT > 0 else np.inf,
            "flip": int(i_eo != i_bal),
            "est_eo": names[i_eo], "est_bal": names[i_bal],
            "time_saved_s": T[i_eo] - T[i_bal],
            "time_saved_frac": (T[i_eo] - T[i_bal]) / T[i_eo],
            "error_regret_abs": E[i_bal] - E[i_eo],
            "error_regret_rel": (E[i_bal] - E[i_eo]) / E[i_eo],
            "structure": g["structure_family"].iloc[0],
            "distribution": g["distribution"].iloc[0],
            "p_over_n": g["p_over_n"].iloc[0],
        })
    R = pd.DataFrame(rows)
    R.to_csv(out_dir / "a02_group_spreads.csv", index=False)

    q = lambda s, qs=(0.05, 0.25, 0.5, 0.75, 0.95): {f"q{int(x*100):02d}": float(s.quantile(x)) for x in qs}
    summary = {
        "n_groups": n,
        "phi": float(R["flip"].mean()),
        "dT_all": q(R["dT"]), "dT_cpu": q(R[R.device == "cpu"]["dT"]), "dT_cuda": q(R[R.device == "cuda"]["dT"]),
        "rate_all": q(R["rate_frob_per_s"]),
        "dE_all": q(R["dE"]),
    }
    F = R[R["flip"] == 1]
    summary["flipped"] = {
        "n": int(len(F)),
        "time_saved_s": q(F["time_saved_s"]),
        "time_saved_frac": q(F["time_saved_frac"]),
        "error_regret_rel": q(F["error_regret_rel"]),
        "dT": q(F["dT"]),
        "frac_time_saved_gt_10ms": float((F["time_saved_s"] > 1e-2).mean()),
        "frac_time_saved_gt_100ms": float((F["time_saved_s"] > 1e-1).mean()),
        "frac_time_saved_gt_1s": float((F["time_saved_s"] > 1.0).mean()),
        "frac_error_regret_lt_1pct": float((F["error_regret_rel"] < 0.01).mean()),
        "frac_error_regret_lt_5pct": float((F["error_regret_rel"] < 0.05).mean()),
        "frac_error_regret_lt_10pct": float((F["error_regret_rel"] < 0.10).mean()),
        "by_device": F["device"].value_counts().to_dict(),
        "transitions": {f"{a}->{b}": int(v) for (a, b), v in F.groupby(["est_eo", "est_bal"]).size().sort_values(ascending=False).head(12).items()},
    }
    # flips binned by absolute spread
    bins = [0, 1e-3, 1e-2, 1e-1, 1.0, 10.0, 1e9]
    labels = ["under 1 ms", "1 - 10 ms", "10 - 100 ms", "0.1 - 1 s", "1 - 10 s", "over 10 s"]
    R["dT_bin"] = pd.cut(R["dT"], bins=bins, labels=labels, right=False)
    byb = R.groupby("dT_bin", observed=True).agg(n=("flip", "size"), phi=("flip", "mean")).reset_index()
    byb["share_of_all_flips"] = R.groupby("dT_bin", observed=True)["flip"].sum().to_numpy() / R["flip"].sum()
    print("\nFlip rate by absolute runtime spread of the group:")
    print(byb.to_string(index=False))
    summary["phi_by_dT_bin"] = byb.astype({"dT_bin": str}).to_dict(orient="records")

    print("\nFlipped groups: time saved (s) quantiles:", summary["flipped"]["time_saved_s"])
    print("Flipped groups: relative error regret quantiles:", summary["flipped"]["error_regret_rel"])
    print("Flipped groups: share with >100ms saved:", summary["flipped"]["frac_time_saved_gt_100ms"],
          " >1s saved:", summary["flipped"]["frac_time_saved_gt_1s"])
    print("Top transitions:", list(summary["flipped"]["transitions"].items())[:8])

    # ---- magnitude gate sweep ----
    gate_rows = []
    for norm in ("minmax", "zscore"):
        for log_cost in (False, True):
            for tau in TAUS:
                # for log cost the gate is a ratio tolerance: ignore spreads below a factor (1 + tau)
                tau_eff = np.log(1.0 + tau) if log_cost else tau
                flips = 0
                for cid, dev, g in groups:
                    E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
                    i_eo = scalarised_oracle(E, T, 1.0, 0.0, norm=norm, log_cost=log_cost)
                    i_bal = scalarised_oracle(E, T, 0.5, 0.5, tau=tau_eff, norm=norm, log_cost=log_cost)
                    flips += int(i_eo != i_bal)
                gate_rows.append({"norm": norm, "log_cost": log_cost, "tau_s": tau, "phi": flips / n})
                print(f"gate norm={norm:7s} log={str(log_cost):5s} tau={tau:7.3f}s  Phi={flips/n:.4f}")
    G = pd.DataFrame(gate_rows)
    G.to_csv(out_dir / "a02_gate_sweep.csv", index=False)
    summary["gate_sweep"] = G.to_dict(orient="records")

    # ---- sensitivity bound (exact for alpha = beta): flip iff dT < tau_dagger(g) ----
    # tau_dagger(g) = dE * max_{e: T(e) < T*} (T* - T(e)) / (E(e) - E*)
    viol = 0; n_bound = 0; taud = []
    for cid, dev, g in groups:
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0)
        dE, dT = E.max() - E.min(), T.max() - T.min()
        others = np.arange(len(E)) != i_eo
        gain = T[i_eo] - T[others]; dEe = E[others] - E[i_eo]
        ok = (gain > 0) & (dEe > 0)
        if not ok.any():
            tau_d = 0.0
        else:
            tau_d = dE * np.max(gain[ok] / dEe[ok])
        taud.append(tau_d)
        n_bound += 1
        i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        predicted_flip = dT < tau_d
        if predicted_flip != (i_bal != i_eo):
            viol += 1
    summary["bound_check"] = {"groups": n_bound, "mismatches": viol,
                              "tau_dagger_quantiles": q(pd.Series(taud))}
    print(f"\nExact flip criterion check: {viol} mismatches in {n_bound} groups (0 expected)")
    print("tau_dagger quantiles (s):", summary["bound_check"]["tau_dagger_quantiles"])

    save_json(summary, out_dir / "a02_normalisation.json")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
