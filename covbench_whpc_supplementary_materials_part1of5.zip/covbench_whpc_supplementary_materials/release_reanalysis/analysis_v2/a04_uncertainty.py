"""A04: Uncertainty at the level it is defensible, and timing homogeneity.

1. Replicate level. Each of the 153 design points has 10 replicates (paired
   seeds). Phi computed on each replicate index separately gives 10 values;
   their spread is the measurement variability of the headline.

2. Design point cluster bootstrap. Resampling the 153 design points with
   replacement treats the factorial grid as a sample from a superpopulation
   of deployment conditions. This is the only resampling scheme under which
   a confidence interval for Phi has an inferential target; we report it
   for Phi, for the cross tier migration rates and for the device migration
   rates, and we state the target explicitly.

3. Finite grid statistic. Over the fixed grid, Phi is a descriptive count
   with no sampling variability; we report it as such with its numerator
   and denominator.

4. ROCm sensitivity. hard_thresholding CUDA rows were produced under a
   different ROCm build from the other Tier B CUDA rows. We cannot rerun
   here, so we bound the effect: rescale hard_thresholding CUDA wall times
   by factors in {0.25, 0.5, 2, 4} and recompute Phi and the migration
   rates; and we report how often hard_thresholding is the balanced oracle
   on CUDA groups at all.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COST_COL, ERROR_COL, load, scalarised_oracle, save_json

RNG = np.random.default_rng(20261102)
N_BOOT = 2000


def per_group_stats(df, ht_scale=1.0):
    """One row per complete group with flip indicator and tier/device migration flags."""
    rows = []
    for (cid, dev), g in df.groupby(["cell_id", "device"], sort=False):
        if len(g) != (8 if dev == "cpu" else 5):
            continue
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy().copy()
        names = g["estimator_name"].to_numpy(); tiers = g["tier"].to_numpy()
        if ht_scale != 1.0 and dev == "cuda":
            T[names == "hard_thresholding"] *= ht_scale
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        rows.append({"cell_id": cid, "device": dev, "design": g["design"].iloc[0],
                     "replicate_id": int(g["replicate_id"].iloc[0]),
                     "flip": int(i_eo != i_bal),
                     "c_to_b": int(tiers[i_eo] == "C" and tiers[i_bal] == "B"),
                     "b_to_c": int(tiers[i_eo] == "B" and tiers[i_bal] == "C"),
                     "bal_is_ht": int(names[i_bal] == "hard_thresholding"),
                     "eo_is_ht": int(names[i_eo] == "hard_thresholding")})
    return pd.DataFrame(rows)


def pooled_stats(df):
    rows = []
    for cid, g in df.groupby("cell_id", sort=False):
        if len(g) != 13:
            continue
        E = g[ERROR_COL].to_numpy(); T = g[COST_COL].to_numpy()
        devs = g["device"].to_numpy(); tiers = g["tier"].to_numpy()
        i_eo = scalarised_oracle(E, T, 1.0, 0.0); i_bal = scalarised_oracle(E, T, 0.5, 0.5)
        rows.append({"cell_id": cid, "design": g["design"].iloc[0],
                     "cfg_flip": int(i_eo != i_bal),
                     "cpu_to_cuda": int(devs[i_eo] == "cpu" and devs[i_bal] == "cuda"),
                     "cuda_to_cpu": int(devs[i_eo] == "cuda" and devs[i_bal] == "cpu"),
                     "c_to_b": int(tiers[i_eo] == "C" and tiers[i_bal] == "B"),
                     "b_to_c": int(tiers[i_eo] == "B" and tiers[i_bal] == "C")})
    return pd.DataFrame(rows)


def cluster_boot(S, cols, cluster="design", n_boot=N_BOOT):
    clusters = S[cluster].unique(); K = len(clusters)
    byc = {c: S[S[cluster] == c][cols].to_numpy() for c in clusters}
    out = {c: [] for c in cols}
    for _ in range(n_boot):
        pick = RNG.choice(clusters, size=K, replace=True)
        M = np.vstack([byc[c] for c in pick])
        m = M.mean(axis=0)
        for j, c in enumerate(cols):
            out[c].append(m[j])
    return {c: {"mean": float(np.mean(v)), "ci95_lo": float(np.percentile(v, 2.5)),
                "ci95_hi": float(np.percentile(v, 97.5)), "sd": float(np.std(v))} for c, v in out.items()}


def main(data_dir, out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = load(data_dir)
    S = per_group_stats(df)
    res = {"n_groups": int(len(S)), "n_designs": int(S["design"].nunique()),
           "phi_point": float(S.flip.mean()), "phi_numerator": int(S.flip.sum())}

    # 1. replicate level
    byrep = S.groupby("replicate_id").agg(phi=("flip", "mean"), c_to_b=("c_to_b", "mean"), n=("flip", "size"))
    res["replicate_level"] = {"phi_values": byrep.phi.round(4).tolist(),
                              "phi_mean": float(byrep.phi.mean()), "phi_sd": float(byrep.phi.std(ddof=1)),
                              "phi_min": float(byrep.phi.min()), "phi_max": float(byrep.phi.max())}
    print("Replicate level Phi (10 values):", byrep.phi.round(4).tolist())

    # 2. design point cluster bootstrap, released groups (all, cpu, cuda)
    res["cluster_bootstrap"] = {
        "all_groups": cluster_boot(S, ["flip"]),
        "cpu_groups": cluster_boot(S[S.device == "cpu"], ["flip", "c_to_b", "b_to_c"]),
        "cuda_groups": cluster_boot(S[S.device == "cuda"], ["flip"]),
    }
    P = pooled_stats(df)
    res["cluster_bootstrap"]["pooled_cells"] = cluster_boot(P, ["cfg_flip", "cpu_to_cuda", "cuda_to_cpu", "c_to_b", "b_to_c"])
    for k, v in res["cluster_bootstrap"].items():
        print(f"\n{k}:")
        for kk, vv in v.items():
            print(f"  {kk:12s} mean={vv['mean']:.4f}  95% CI [{vv['ci95_lo']:.4f}, {vv['ci95_hi']:.4f}]")

    # per device point estimates
    res["phi_by_device"] = S.groupby("device").flip.mean().to_dict()
    # per axis point estimates (descriptive)
    df_axes = df.drop_duplicates("cell_id").set_index("cell_id")[["structure_family", "distribution", "p_over_n"]]
    S2 = S.join(df_axes, on="cell_id")
    res["phi_by_structure"] = S2.groupby("structure_family").flip.mean().round(4).to_dict()
    res["phi_by_distribution"] = S2.groupby("distribution").flip.mean().round(4).to_dict()
    res["phi_by_p_over_n"] = {str(k): float(v) for k, v in S2.groupby("p_over_n").flip.mean().round(4).items()}
    print("\nPhi by device:", res["phi_by_device"])
    print("Phi by structure:", res["phi_by_structure"])
    print("Phi by distribution:", res["phi_by_distribution"])
    print("Phi by p/n:", res["phi_by_p_over_n"])

    # 4. ROCm sensitivity
    cuda = S[S.device == "cuda"]
    res["rocm"] = {"ht_balanced_oracle_share_cuda": float(cuda.bal_is_ht.mean()),
                   "ht_error_only_oracle_share_cuda": float(cuda.eo_is_ht.mean()), "scaled": {}}
    for f in (0.25, 0.5, 2.0, 4.0):
        Sf = per_group_stats(df, ht_scale=f)
        res["rocm"]["scaled"][str(f)] = {"phi": float(Sf.flip.mean()),
                                         "phi_cuda": float(Sf[Sf.device == "cuda"].flip.mean())}
    print("\nROCm sensitivity (hard_thresholding CUDA time scaled):", res["rocm"])
    # versions present
    s = df[df.device == "cuda"]
    res["rocm"]["versions_by_estimator"] = {k: sorted(set(v)) for k, v in s.groupby("estimator_name").rocm_version.unique().items()}

    S.to_csv(out_dir / "a04_group_flags.csv", index=False)
    save_json(res, out_dir / "a04_uncertainty.json")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
