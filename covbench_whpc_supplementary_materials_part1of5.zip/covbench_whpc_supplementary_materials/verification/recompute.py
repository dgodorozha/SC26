"""Independent recomputation of the headline quantities from the raw result files, without the notebook's code.
Usage: python -I recompute.py <covbench_v2 folder> <hardware_matrix_summary.json>"""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(sys.argv[1]); S = json.load(open(sys.argv[2]))
EPS = 1e-8
HW = ["tesla_t4", "nvidia_l4", "nvidia_a100_sxm4_40gb", "nvidia_rtx_pro_6000_blackwell_server_edition", "cpu_intel_r_xeon_r_cpu_2_20ghz"]
STATS = ["feat_kurtosis_mean", "feat_kurtosis_max", "feat_kurtosis_p95", "feat_skewness_mean", "feat_outlier_fraction", "feat_sample_cond",
         "feat_sample_effective_rank", "feat_sample_stable_rank", "feat_spectral_entropy", "feat_top_eig_gap_ratio", "feat_max_eigval_to_trace",
         "feat_off_diag_mag_p50", "feat_off_diag_mag_p95", "feat_off_diag_mag_tail_decay", "feat_sparsity_score_soft", "feat_band_score", "feat_block_score"]
ok = True
def check(label, got, want, tol=1e-9):
    global ok
    good = (got is None and want is None) or (got is not None and want is not None and abs(got - want) <= tol)
    if not good: ok = False
    print(f"  {'OK ' if good else 'XX '} {label}: recomputed {got} vs summary {want}")

def mm(x, floor=0.0):
    lo, hi = x.min(), x.max(); return (x - lo) / (max(hi - lo, floor) + EPS)
def pick(E, T, a, b, tau=0.0):
    J = a * mm(E) + b * mm(T, tau); return int(np.lexsort((T, E, J))[0])

def run_folder(block, h):
    pid = S["quality"][h]["protocol_id"] if block == "block1_covariance_nvidia" else S[{"block2_dimension_sweep": "block2", "block3_regression_family": "block3", "block4_downstream_validity": "block4"}[block]][h]["quality"]["protocol_id"]
    return ROOT / block / h / "full" / pid

def device_groups(df, menu):
    """One row per complete (cell, device) group: the error only and balanced picks."""
    out = []
    for (cell, dev), g in df.groupby(["cell_id", "device"], sort=False):
        if set(g.estimator_name) != set(menu[dev]) or len(g) != len(menu[dev]) or len(g) < 2: continue
        E, T = g.frobenius_loss.to_numpy(float), g.fit_wall_time_s.to_numpy(float)
        i, j, j1 = pick(E, T, 1, 0), pick(E, T, .5, .5), pick(E, T, .5, .5, tau=1.0)
        tiers = g.estimator_tier.to_numpy()
        out.append(dict(cell=cell, device=dev, flip=int(i != j), flip_1s=int(i != j1), c_to_b=int(tiers[i] == "C" and tiers[j] == "B"), b_to_c=int(tiers[i] == "B" and tiers[j] == "C")))
    return pd.DataFrame(out)

def pooled_cells(df, menu):
    """One row per complete pooled cell (every configuration of both devices present)."""
    want = {f"{e}/{d}" for d, names in menu.items() for e in names}
    out = {}
    for cell, g in df.groupby("cell_id", sort=False):
        cfg = g.estimator_name + "/" + g.device
        if set(cfg) != want or len(g) != len(want): continue
        E, T = g.frobenius_loss.to_numpy(float), g.fit_wall_time_s.to_numpy(float)
        i, j = pick(E, T, 1, 0), pick(E, T, .5, .5)
        out[cell] = dict(eo=cfg.iloc[i], bal=cfg.iloc[j], dev_eo=g.device.iloc[i], dev_bal=g.device.iloc[j])
    return out

print("== block 1, per runtime ==")
pooled, hashes, stats, rel_agree = {}, {}, {}, {}
for h in HW:
    df = pd.read_parquet(run_folder("block1_covariance_nvidia", h) / "results.parquet")
    df = df[(df.status == "success") & (df.implementation == "covbench_torch")]   # the scikit-learn reference rows are the implementation audit, not menu entries
    menu = {d: sorted(set(df[df.device == d].estimator_name)) for d in df.device.unique()}
    G = device_groups(df, menu); hw = S["hardware"][h]
    print(h, "menu sizes", {d: len(v) for d, v in menu.items()}, "groups", len(G))
    check("n_groups", len(G), hw["groups"]["n_groups"])
    check("phi", G.flip.mean(), hw["groups"]["phi"])
    check("phi_1s", G.flip_1s.mean(), hw["groups"]["phi_gate_1s"])
    check("phi CPU groups", G[G.device == "cpu"].flip.mean(), hw["cpu_groups"]["phi"])
    if "cuda" in menu: check("phi GPU groups", G[G.device == "cuda"].flip.mean(), hw["gpu_groups"]["phi"])
    check("C to B", G[G.device == "cpu"].c_to_b.mean(), hw["cpu_groups"]["c_to_b"])
    check("B to C", G[G.device == "cpu"].b_to_c.mean(), hw["cpu_groups"]["b_to_c"])
    P = pooled_cells(df, menu); pooled[h] = P
    check("pooled n", len(P), hw["pooled"]["n_groups"])
    check("pooled phi", np.mean([v["eo"] != v["bal"] for v in P.values()]), hw["pooled"]["phi"])
    check("CPU to GPU", np.mean([v["dev_eo"] == "cpu" and v["dev_bal"] == "cuda" for v in P.values()]), hw["pooled"]["cpu_to_gpu"])
    check("GPU to CPU", np.mean([v["dev_eo"] == "cuda" and v["dev_bal"] == "cpu" for v in P.values()]), hw["pooled"]["gpu_to_cpu"])
    if "cuda" in menu:
        lw = df[df.estimator_name == "ledoit_wolf_linear"].pivot_table(index="cell_id", columns="device", values="fit_wall_time_s")
        check("LW median paired speedup", float((lw["cpu"] / lw["cuda"]).median()), hw["gpu_speedup"]["ledoit_wolf_linear"]["median_paired_speedup"], 1e-6)
        ma = pd.read_parquet(run_folder("block1_covariance_nvidia", h) / "matrix_audit.parquet"); ma = ma[ma.status == "success"]
        ne = ma[ma.estimator_name == "nercome"].matrix_rel_discrepancy
        check("NERCOME matrix audit max", float(ne.max()), hw["matrix_audit"]["by_estimator"]["nercome"]["max"], 1e-12)
        check("NERCOME share above 1e-8", float((ne > 1e-8).mean()), hw["matrix_audit"]["by_estimator"]["nercome"]["frac_gt_1e-8"])
    # per cell identity material: hashes, statistics (plus the sample covariance loss), release agreement
    one = df.sort_values("estimator_name").groupby("cell_id").first()
    hashes[h] = {c: (r.data_sha256, r.sigma_sha256) for c, r in one.iterrows()}
    sc = df[(df.estimator_name == "sample_cov") & (df.device == "cpu")].set_index("cell_id").frobenius_loss
    stats[h] = {c: np.array([one.loc[c, s] for s in STATS] + [sc.get(c, np.nan)], float) for c in one.index}
    rel_agree[h] = set(df.groupby("cell_id").release_stats_agree.all().pipe(lambda s: s[s].index))

print("== MI300A release (experiments.parquet) ==")
r = pd.read_parquet(ROOT / "experiments.parquet"); r = r[r.status == "success"]
menu_r = {d: sorted(set(r[r.device == d].estimator_name)) for d in r.device.unique()}
Gr = device_groups(r, menu_r); hw = S["hardware"]["amd_mi300a_release"]
check("n_groups", len(Gr), hw["groups"]["n_groups"]); check("phi", Gr.flip.mean(), hw["groups"]["phi"])
Pr = pooled_cells(r, menu_r); check("pooled n", len(Pr), hw["pooled"]["n_groups"]); check("pooled phi", np.mean([v["eo"] != v["bal"] for v in Pr.values()]), hw["pooled"]["phi"])
check("CPU to GPU", np.mean([v["dev_eo"] == "cpu" and v["dev_bal"] == "cuda" for v in Pr.values()]), hw["pooled"]["cpu_to_gpu"])
check("GPU to CPU", np.mean([v["dev_eo"] == "cuda" and v["dev_bal"] == "cpu" for v in Pr.values()]), hw["pooled"]["gpu_to_cpu"])

print("== across the five full menu runtimes ==")
full = [h for h in HW if h != "cpu_intel_r_xeon_r_cpu_2_20ghz"]
common = set.intersection(*[set(pooled[h]) for h in full], set(Pr))
def stat_ok(a, b):
    pairs = [(u, v) for u, v in zip(a, b) if np.isfinite(u) or np.isfinite(v)]
    return len(pairs) >= 16 and all(np.isfinite(u) and np.isfinite(v) and abs(u - v) <= 1e-9 * max(1.0, abs(v)) for u, v in pairs)
ref = full[0]
by_hash = {c for c in common if all(hashes[h][c] == hashes[ref][c] for h in full)}
by_stat = {c for c in common - by_hash if all(stat_ok(stats[ref][c], stats[h][c]) for h in full[1:])}
cons = {c for c in by_hash | by_stat if all(c in rel_agree[h] for h in full)}
check("common cells", len(common), S["across_all"]["n_common_cells"]); check("consistent cells", len(cons), S["data_identity"]["across_all"]["n_identical_cells"])
check("by hash among the Colab runs", len(by_hash & cons), S["data_identity"]["across_all"]["n_identical_by_hash"])
recs = [[pooled[h][c]["bal"] for h in full] + [Pr[c]["bal"]] for c in cons]
check("balanced differs", np.mean([len(set(x)) > 1 for x in recs]), S["across_all"]["balanced_recommendation_differs"])
check("balanced device differs", np.mean([len({y.split("/")[1] for y in x}) > 1 for x in recs]), S["across_all"]["balanced_device_differs"])
recs = [[pooled[h][c]["eo"] for h in full] + [Pr[c]["eo"]] for c in cons]
check("error only differs", np.mean([len(set(x)) > 1 for x in recs]), S["across_all"]["error_only_recommendation_differs"])

print("== block 3, configuration flip rate ==")
for h in HW:
    df = pd.read_parquet(run_folder("block3_regression_family", h) / "results.parquet"); df = df[df.status == "success"]
    flips, n = 0, 0
    for cell, g in df.groupby("cell_id", sort=False):
        E, T = g.test_mse.to_numpy(float), g.fit_wall_time_s.to_numpy(float)
        n += 1; flips += int(pick(E, T, 1, 0) != pick(E, T, .5, .5))
    check(f"{h}: configurations per cell", len(df) // n, 21 if h.startswith("cpu") else 39); check(f"{h}: phi_config", flips / n, S["block3"][h]["phi_configuration"])

print("== block 2, phi over device groups per p ==")
for h in HW:
    df = pd.read_parquet(run_folder("block2_dimension_sweep", h) / "results.parquet"); df = df[df.status == "success"]
    for p, dp in df.groupby("p"):
        menu = {d: sorted(set(dp[dp.device == d].estimator_name)) for d in dp.device.unique()}
        G = device_groups(dp, menu)
        check(f"{h} p={p}: phi groups", G.flip.mean(), S["block2"][h][str(p)]["phi_groups"])
print("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED")
