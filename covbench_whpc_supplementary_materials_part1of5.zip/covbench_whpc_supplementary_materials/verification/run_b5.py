import sys, os, time, nbformat
from nbclient import NotebookClient
nb_path, root = sys.argv[1], sys.argv[2]
nb = nbformat.read(nb_path, as_version=4)
os.environ["COVBENCH_ROOT"] = os.path.abspath(root)
t0 = time.time()
client = NotebookClient(nb, timeout=3600, kernel_name="python3", resources={"metadata": {"path": os.path.dirname(os.path.abspath(__file__))}})
try:
    client.execute(); status = "OK"
except Exception as e:
    status = "FAIL: " + str(e)[:3000]
nbformat.write(nb, os.path.join(os.path.dirname(os.path.abspath(__file__)), "executed_hardware_matrix.ipynb"))
print(f"status: {status} in {time.time()-t0:.0f}s")
for c in nb.cells:
    if c.cell_type == "code":
        for o in c.get("outputs", []):
            if o.get("output_type") == "error":
                print("ERROR in cell:", c.source[:80].replace("\n", " | ")); print("\n".join(o.get("traceback", []))[-3000:])
