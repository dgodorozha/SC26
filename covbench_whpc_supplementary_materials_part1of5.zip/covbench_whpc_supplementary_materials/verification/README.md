# Verification of the summary against the raw result files

Two checks, run on 6 November 2026 on a two core CPU machine outside Colab, against the raw files in
`results/covbench_v2` as downloaded from Drive.

## 1. Block 5 rerun, and the summary of record

`run_b5.py` executes `notebooks/covbench_v2_hardware_matrix.ipynb` with `COVBENCH_ROOT` pointing at a copy of
`results/covbench_v2` (the notebook reads the environment variable when it is not on Colab). It applies the quality
gate to every run folder and reassembles the matrix. `executed_hardware_matrix.ipynb` is the executed notebook with its
outputs.

`hardware_matrix_summary_colab_20261105.json` is the summary block 5 wrote on Colab on 5 November, the file the first
version of the tables was generated from. `hardware_matrix_summary_regenerated.json` is the rerun with one correction
to `identical_cells` in `build_notebook.py`: for a pair of one notebook run and the release the hash set now starts
empty, since the release rows carry no hashes, so `n_identical_by_hash` is 0 and `n_identical_by_statistics_only`
holds every consistent cell (the Colab file recorded those cells under `n_identical_by_hash`). The across all entry
gains `n_identical_by_statistics_only` and a `method` field. Every other number in the two files is identical; the
only other differences are the machine description (`environment_this_session`) and the reason recorded for one
superseded block 3 folder on the RTX PRO 6000 runtime (`a8e203d383`, an interrupted run that is excluded either way:
it holds no `summary.json` in the Drive download, so the gate now says "no summary yet" rather than "incomplete
planned set, unverified code"). The folder block 5 selects for every block and runtime is the same.

The regenerated file is the summary of record: it is the copy in `supplement/`, and the 19 table fragments are
generated from it (they are byte for byte the fragments generated from the Colab file, since the table generator
already printed the release pairs by their recorded method). The notebooks in `notebooks/` are rebuilt from the
corrected source, so a block 5 run in Colab now writes the corrected fields to Drive.

    python run_b5.py ../notebooks/covbench_v2_hardware_matrix.ipynb <copy of results/covbench_v2>

## 2. Independent recomputation

`recompute.py` uses none of the notebook code. From `results.parquet`, `matrix_audit.parquet` and
`experiments.parquet` it recomputes, with its own implementation of the two rules (min max normalisation within the
group, equal weights, the same lexicographic tie break), the group completeness rule and the data consistency check:

- block 1, per Colab runtime: number of complete (cell, device) groups, the flip rate, its 1 s floor variant, the CPU
  and GPU group rates, the C to B and B to C tier rates, the complete pooled cells, the pooled flip rate, the CPU to
  GPU and GPU to CPU migration rates, the median paired Ledoit Wolf speedup, and NERCOME's maximum matrix
  discrepancy and share of cells above 1e-8;
- the MI300A release: complete groups and flip rate (2,953 and 0.436), complete pooled cells, pooled flip rate and the
  two migration rates;
- across the five runtimes with the full candidate set: the 429 common cells, the 429 consistent cells, the 135 with equal hashes among
  the four Colab runs, and the shares on which the balanced recommendation, its device and the error only
  recommendation differ (40.1%, 36.1%, 23.1%);
- block 3: configurations per cell (39 and 21) and the configuration flip rate per runtime;
- block 2: the flip rate over device groups per runtime and dimension.

`recompute_log.txt` is its output against the summary of record: 108 quantities, every one equal to floating point.

    python -I recompute.py ../results/covbench_v2 ../supplement/hardware_matrix_summary.json

The scikit-learn reference rows of block 1 (`implementation == sklearn_reference`) are the implementation audit and
are excluded from the menus, as in the notebooks. Block 4 is not recomputed independently here; its numbers come
from the block 4 `summary.json` of each run, which the block 5 rerun above re-reads under the gate. The canonical
covariance checks are in `canonical_true_covariances/`.
