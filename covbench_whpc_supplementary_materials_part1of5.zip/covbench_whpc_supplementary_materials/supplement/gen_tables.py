"""Generate the supplementary tables from the live hardware matrix summary."""
import json, sys, os
from pathlib import Path

SUMMARY = Path(sys.argv[1])
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
S = json.load(open(SUMMARY))

HW = ["tesla_t4", "nvidia_l4", "nvidia_a100_sxm4_40gb", "nvidia_rtx_pro_6000_blackwell_server_edition", "amd_mi300a_release", "cpu_intel_r_xeon_r_cpu_2_20ghz"]
NAME = {"tesla_t4": "NVIDIA T4", "nvidia_l4": "NVIDIA L4", "nvidia_a100_sxm4_40gb": "NVIDIA A100", "nvidia_rtx_pro_6000_blackwell_server_edition": "RTX PRO 6000", "amd_mi300a_release": "AMD MI300A", "cpu_intel_r_xeon_r_cpu_2_20ghz": "CPU only"}
SHORT = {"tesla_t4": "T4", "nvidia_l4": "L4", "nvidia_a100_sxm4_40gb": "A100", "nvidia_rtx_pro_6000_blackwell_server_edition": "RTX PRO 6000", "amd_mi300a_release": "MI300A", "cpu_intel_r_xeon_r_cpu_2_20ghz": "CPU only"}
EST = ["sample_cov", "ledoit_wolf_linear", "oas", "nercome", "hard_thresholding", "poet", "graphical_lasso", "tyler_m"]
ESTN = {"sample_cov": "Sample covariance", "ledoit_wolf_linear": "Ledoit Wolf", "oas": "OAS", "nercome": "NERCOME", "hard_thresholding": "Hard thresholding", "poet": "POET", "graphical_lasso": "Graphical lasso", "tyler_m": "Tyler M"}
DUAL = ["sample_cov", "ledoit_wolf_linear", "nercome", "hard_thresholding", "poet"]

def f(x, d=3):
    return "n/a" if x is None else f"{x:.{d}f}"
def pct(x, d=1):
    return "n/a" if x is None else f"{100*x:.{d}f}"
def ci(c, d=3):
    return "n/a" if not c else f"[{c['ci95_lo']:.{d}f}, {c['ci95_hi']:.{d}f}]"
def cip(c, d=1):
    return "n/a" if not c else f"[{100*c['ci95_lo']:.{d}f}, {100*c['ci95_hi']:.{d}f}]"
def sci(x):
    if x is None: return "n/a"
    if x == 0: return "0"
    return f"{x:.1e}".replace("e-", "e-").replace("e+", "e")
def esc(s):
    return s.replace("_", "\\_").replace("%", "\\%").replace("&", "\\&")

def write(name, head, rows, colspec, caption=None):
    lines = ["\\begin{tabular}{" + colspec + "}", "\\toprule", " & ".join(head) + " \\\\", "\\midrule"]
    for r in rows:
        if r == "MIDRULE": lines.append("\\midrule"); continue
        lines.append(" & ".join(r) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    (OUT / name).write_text("\n".join(lines) + "\n")

# ---------------- environment ----------------
rows = []
for h in HW:
    m = S["hardware"][h]["meta"]
    gpu = ", ".join(x for x in m["gpu_model"] if x) or "none"
    torch = "/".join(m["torch_version"]); cuda = "/".join(x for x in m.get("cuda_version", []) if x) or "n/a"
    drv = "/".join(x for x in m.get("driver_version", []) if x) or "n/a"
    numpy = "/".join(m["numpy_version"]); skl = "/".join(m.get("sklearn_version", ["n/a"])); py = "/".join(m["python_version"])
    cpu = m["cpu_model"][0]
    THREADS = {"tesla_t4": "2", "nvidia_l4": "12", "nvidia_a100_sxm4_40gb": "12", "nvidia_rtx_pro_6000_blackwell_server_edition": "48", "amd_mi300a_release": "8", "cpu_intel_r_xeon_r_cpu_2_20ghz": "2"}
    FP64 = {"tesla_t4": "1/32", "nvidia_l4": "1/64", "nvidia_a100_sxm4_40gb": "1/2", "nvidia_rtx_pro_6000_blackwell_server_edition": "1/64", "amd_mi300a_release": "1/2", "cpu_intel_r_xeon_r_cpu_2_20ghz": "n/a"}
    if h == "amd_mi300a_release": cpu = "MI300A node"; drv = "ROCm 7.2/7.12"; cuda = "n/a"
    rows.append([NAME[h], esc(gpu.replace("NVIDIA ", "").replace(" Server Edition", "")), FP64[h], esc(cpu.replace("Intel(R) Xeon(R) CPU @ ", "Xeon ")), THREADS[h], esc(torch), esc(cuda), esc(drv), esc(numpy), esc(skl), esc(py)])
write("tab_env.tex", ["Runtime", "Accelerator", "FP64:FP32", "Host CPU", "Threads", "torch", "CUDA", "Driver", "numpy", "scikit-learn", "Python"], rows, "@{}lllllllllll@{}")

# ---------------- identity ----------------
rows = []
for k, v in S["pairwise"].items():
    a, b = k.split(" | "); d = v["data_identity"]
    # A pair with the release is checked by statistic agreement only (its rows carry no hashes): the summary records 0 by hash and
    # every consistent cell by statistics; the table prints n/a in the hash column for such a pair, since no hash comparison exists.
    release = "amd_mi300a_release" in (a, b)
    assert not release or d["n_identical_by_hash"] == 0, "a release pair cannot match by hash; regenerate the summary with the corrected identical_cells"
    by_hash = "n/a" if release else str(d["n_identical_by_hash"])
    by_stats = str(d["n_identical_by_statistics_only"])
    rows.append([SHORT[a] + " vs " + SHORT[b], str(d["n_common_cells"]), str(d["n_identical_cells"]), by_hash, by_stats, str(d["n_excluded_non_identical"]), "statistics" if release else "hash, else statistics"])
write("tab_identity.tex", ["Pair", "Common cells", "Consistent", "By hash", "By statistics", "Excluded", "Check"], rows, "@{}lrrrrrl@{}")

# ---------------- block 1 main ----------------
rows = []
for h in HW:
    v = S["hardware"][h]; g = v["groups"]; p = v["pooled"]; c = v["cpu_groups"]; gg = v["gpu_groups"]
    rows.append([NAME[h], str(v["n_cells"]), str(g["n_groups"]), f(g["phi"]) + " " + ci(g["phi_ci95"]), f(g["phi_gate_1s"]), f(c["phi"]), f(gg.get("phi")) if gg.get("phi") is not None else "n/a",
                 f(p["phi"]) + " " + ci(p["phi_ci95"]), pct(p["cpu_to_gpu"]) + " " + cip(p["cpu_to_gpu_ci95"]), pct(p["gpu_to_cpu"]) + " " + cip(p["gpu_to_cpu_ci95"])])
write("tab_b1_main.tex", ["Runtime", "Cells", "Groups", "$\\Phi$ [95\\% CI]", "$\\Phi_{1\\mathrm{s}}$", "$\\Phi$ CPU", "$\\Phi$ GPU", "$\\Phi$ pooled [95\\% CI]", "CPU to GPU \\% [CI]", "GPU to CPU \\% [CI]"], rows, "@{}lrrlrrrlll@{}")

# ---------------- block 1 extra ----------------
rows = []
for h in HW:
    v = S["hardware"][h]; g = v["groups"]; p = v["pooled"]; c = v["cpu_groups"]
    tt = g["top_transitions"]; top = max(tt.items(), key=lambda kv: kv[1]) if tt else ("n/a", 0)
    rows.append([NAME[h], pct(c["c_to_b"]), pct(c["b_to_c"]), f(g["mean_pareto"], 2), pct(g["frac_groups_unsupported"]), pct(g["eo_feasible_100ms"]), f(g["median_time_saved_s_given_flip"], 3), f(g["median_err_regret_given_flip"], 3),
                 esc(ESTN.get(top[0].split("->")[0], top[0].split("->")[0]) + " to " + ESTN.get(top[0].split("->")[1], top[0].split("->")[1])) + f" ({top[1]})"])
write("tab_b1_extra.tex", ["Runtime", "C to B \\%", "B to C \\%", "Pareto size", "Unsupported \\%", "EO within 100 ms \\%", "Time saved (s)", "Regret", "Most frequent flip (groups)"], rows, "@{}lrrrrrrrl@{}")

# ---------------- agreement ----------------
rows = []
for k, v in S["pairwise"].items():
    a, b = k.split(" | ")
    c = v["cpu_groups"]; g = v.get("cuda_groups"); p = v.get("pooled_cells")
    rows.append([SHORT[a] + " vs " + SHORT[b], str(c["n"]), f(c["error_only_agreement"]), f(c["balanced_agreement"]) + " " + ci(c["balanced_agreement_ci95"]),
                 f(g["error_only_agreement"]) if g else "n/a", (f(g["balanced_agreement"]) + " " + ci(g["balanced_agreement_ci95"])) if g else "n/a",
                 f(p["error_only_agreement"]) if p else "n/a", (f(p["balanced_agreement"]) + " " + ci(p["balanced_agreement_ci95"])) if p else "n/a", f(p["balanced_device_agreement"]) if p else "n/a"])
write("tab_agreement.tex", ["Pair", "$n$", "EO, CPU", "Balanced, CPU [CI]", "EO, GPU", "Balanced, GPU [CI]", "EO, pooled", "Balanced, pooled [CI]", "Device"], rows, "@{}lrrlrlrlr@{}")

# ---------------- wall clock ----------------
GPU_HW = [h for h in HW if h != "cpu_intel_r_xeon_r_cpu_2_20ghz"]
rows = []
for e in EST:
    r = [ESTN[e]]
    for h in HW:
        cpu = S["hardware"][h]["median_wall_clock"].get("cpu", {}).get(e)
        r.append(f(cpu, 3) if cpu is not None else "n/a")
    rows.append(r)
write("tab_wallclock_cpu.tex", ["Estimator"] + [f"{SHORT[h]} host" if h != "cpu_intel_r_xeon_r_cpu_2_20ghz" else SHORT[h] for h in HW], rows, "@{}l" + "r" * len(HW) + "@{}")
rows = []
for e in DUAL:
    r = [ESTN[e]]
    for h in GPU_HW:
        gpu = S["hardware"][h]["median_wall_clock"].get("cuda", {}).get(e)
        r.append(f(gpu, 3) if gpu is not None else "n/a")
    rows.append(r)
write("tab_wallclock_gpu.tex", ["Estimator"] + [SHORT[h] for h in GPU_HW], rows, "@{}l" + "r" * len(GPU_HW) + "@{}")

# ---------------- speedups ----------------
rows = []
for e in DUAL:
    r = [ESTN[e]]
    for h in HW:
        sp = S["hardware"][h]["gpu_speedup"].get(e)
        r.append(f"{sp['median_paired_speedup']:.1f} ({sp['q10']:.1f}, {sp['q90']:.1f})" if sp else "n/a")
    rows.append(r)
write("tab_speedup.tex", ["Estimator"] + [SHORT[h] for h in HW if h != "cpu_intel_r_xeon_r_cpu_2_20ghz"], [r[:-1] for r in rows], "@{}l" + "l" * 5 + "@{}")

# ---------------- matrix audit ----------------
rows = []
for h in HW:
    ma = S["hardware"][h].get("matrix_audit")
    if not ma or not ma.get("by_estimator"): continue
    for e in DUAL:
        b = ma["by_estimator"][e]
        rows.append([NAME[h], ESTN[e], str(b["n"]), sci(b["median"]), sci(b["p99"]), sci(b["max"]), pct(b["frac_gt_1e-8"]), sci(b["max_by_p_over_n"]["0.5"]), sci(b["max_by_p_over_n"]["1.0"]), sci(b["max_by_p_over_n"]["2.0"])])
    rows.append("MIDRULE")
rows = rows[:-1]
write("tab_matrix_audit.tex", ["Runtime", "Estimator", "$n$", "Median", "p99", "Max", "$>10^{-8}$ \\%", "Max $p/n{=}0.5$", "Max $p/n{=}1$", "Max $p/n{=}2$"], rows, "@{}llrrrrrrrr@{}")

# ---------------- implementation audit ----------------
rows = []
for h in HW:
    a = S["audit"].get(h)
    if not a: continue
    for r in a["rows"]:
        rows.append([NAME[h], ESTN[r["estimator"]], f"{r['runtime_ratio_port_over_ref_median']:.2f} ({r['runtime_ratio_q10']:.2f}, {r['runtime_ratio_q90']:.2f})",
                     pct(r["matrix_rel_discrepancy_median"], 2), pct(r["matrix_rel_discrepancy_max"], 2), sci(r["matrix_rel_discrepancy_max_same_normalisation"]) if r["matrix_rel_discrepancy_max_same_normalisation"] is not None else "n/a",
                     f(r["shrinkage_abs_difference_median"], 4) if r["shrinkage_abs_difference_median"] is not None else "n/a", f(r["shrinkage_abs_difference_max"], 4) if r["shrinkage_abs_difference_max"] is not None else "n/a", f(r["loss_rel_discrepancy_max"], 3)])
    rows.append("MIDRULE")
rows = rows[:-1]
write("tab_impl_audit.tex", ["Runtime", "Estimator", "Time ratio (q10, q90)", "Matrix med.\\ \\%", "Matrix max \\%", "Same norm.\\ max", "Intensity med.", "Intensity max", "Loss max"], rows, "@{}llrrrrrrr@{}")

# ---------------- block 2 ----------------
rows = []
for h in HW:
    b = S["block2"].get(h)
    if not b: continue
    for p in ["100", "200", "500", "1000"]:
        x = b[p]
        rows.append([NAME[h] if p == "100" else "", p, str(x["n_groups"]), f(x["phi_groups"]), f(x["phi_pooled"]), pct(x["cpu_to_gpu"]), pct(x["gpu_to_cpu"])])
    rows.append("MIDRULE")
rows = rows[:-1]
write("tab_b2.tex", ["Runtime", "$p$", "Groups", "$\\Phi$ groups", "$\\Phi$ pooled", "CPU to GPU \\%", "GPU to CPU \\%"], rows, "@{}lrrrrrr@{}")

# ---------------- block 3 ----------------
rows_a, rows_b = [], []
for h in HW:
    b = S["block3"].get(h)
    if not b: continue
    n_conf = "21" if h == "cpu_intel_r_xeon_r_cpu_2_20ghz" else "39"
    rows_a.append([NAME[h], str(b["n_cells"]), n_conf, f"{b['planned']['n_planned']:,}", f(b["phi_configuration"]) + " " + ci(b["phi_ci95"]),
                   pct(b["frac_cells_unsupported"]), pct(b["median_selection_share_of_wall_clock"])])
    rows_b.append([NAME[h], pct(b["share_of_flips_changing_estimator"]), pct(b["share_of_flips_changing_implementation"]), pct(b["share_of_flips_changing_device"]), pct(b["share_of_flips_changing_fidelity"]),
                   pct(b["share_of_flips_changing_estimator_only"]), pct(b["share_of_flips_changing_implementation_only"]), pct(b["share_of_flips_changing_device_only"]), pct(b["share_of_flips_changing_fidelity_only"]), pct(b["share_of_flips_changing_several_axes"])])
write("tab_b3.tex", ["Runtime", "Cells", "Configurations per cell", "Planned fits", "$\\Phi$ config [95\\% CI]", "Unsupported \\%", "Tuning \\%"], rows_a, "@{}lrrrlrr@{}")
write("tab_b3_axes.tex", ["Runtime", "Estimator", "Implementation", "Device", "Fidelity", "Estimator only", "Implementation only", "Device only", "Fidelity only", "Several axes"], rows_b, "@{}lrrrrrrrrr@{}")

# ---------------- block 4 covariance ----------------
RULES = ["error_only", "balanced", "budget_10ms", "budget_100ms", "budget_1s"]
RN = {"error_only": "Error only", "balanced": "Balanced", "budget_10ms": "Budget 10 ms", "budget_100ms": "Budget 100 ms", "budget_1s": "Budget 1 s"}
for dev, fname in (("cpu", "tab_b4_cov_cpu.tex"), ("cuda", "tab_b4_cov_gpu.tex")):
    rows = []
    for h in HW:
        b = S["block4"].get(h)
        if not b: continue
        first = True
        for r in RULES:
            v = b["rules"].get(f"{dev}/{r}")
            if v is None: continue
            label = NAME[h] if first else ""; first = False
            if v.get("n_eval_windows", 0) == 0:
                rows.append([label, RN[r], "infeasible", "", "", "", "", ""]); continue
            freq = ", ".join(f"{ESTN[k]} {int(round(100*x))}\\%" for k, x in sorted(v["estimator_frequency"].items(), key=lambda kv: -kv[1]))
            rows.append([label, RN[r], f(v["mean_oos_variance_annualised"], 4), f(v["median_oos_variance_annualised"], 4), f(v["mean_fit_wall_time_s"], 3),
                         pct(v["deployed_within_budget"], 0) if v["deployed_within_budget"] is not None else "n/a", f(v["median_max_abs_weight"], 3), freq])
        if not first: rows.append("MIDRULE")
    rows = rows[:-1]
    write(fname, ["Runtime", "Rule", "Mean var.", "Median var.", "Fit time (s)", "Within budget \\%", "Max $|w|$", "Estimator chosen (share of periods)"], rows, "@{}llrrrrrl@{}")

# oracle and estimator level
b = S["block4"]["nvidia_a100_sxm4_40gb"]
rows = []
for e in EST:
    cpu = b["estimator_oos_variance_annualised_by_device"].get(e + "/cpu"); gpu = b["estimator_oos_variance_annualised_by_device"].get(e + "/cuda")
    rows.append([ESTN[e], f(cpu, 4) if cpu is not None else "n/a", f(gpu, 4) if gpu is not None else "n/a", f(b["estimator_median_max_abs_weight"].get(e), 3)])
rows.append("MIDRULE")
rows.append(["Per period oracle", f(b["oracle_oos_variance_annualised_by_device"]["cpu"], 4), f(b["oracle_oos_variance_annualised_by_device"]["cuda"], 4), ""])
write("tab_b4_est.tex", ["Estimator", "CPU", "GPU", "Median max $|w|$"], rows, "@{}lrrr@{}")

rows = []
for dev in ["cpu", "cuda"]:
    for r in RULES:
        v = b["rules_frobenius_proxy"].get(f"{dev}/{r}")
        if v is None: continue
        if v.get("n_eval_windows", 0) == 0: rows.append(["CPU" if dev == "cpu" else "GPU", RN[r], "infeasible", "", ""]); continue
        rows.append(["CPU" if dev == "cpu" else "GPU", RN[r], f(v["mean_oos_variance_annualised"], 4), f(v["median_oos_variance_annualised"], 4), ESTN[v["estimator"]]])
write("tab_b4_proxy.tex", ["Device", "Rule", "Mean var.", "Median var.", "Estimator"], rows, "@{}llrrl@{}")

# ---------------- block 4 regression ----------------
rows = []
for h in HW:
    b = S["block4"].get(h)
    if not b: continue
    rg = b["regression"]["rules"]
    r = [NAME[h]]
    for k in RULES:
        v = rg[k]
        if v["mean_holdout_mse"] is None: r.append("infeasible")
        else:
            wb = v.get("deployed_within_budget"); r.append(f"{v['mean_holdout_mse']:.3f} ({v['mean_fit_wall_time_s']:.2f} s" + (f", {int(round(100*wb))}\\%)" if wb is not None else ")"))
    rows.append(r)
rows.append("MIDRULE")
rows.append(["Retrospective oracle", f(b["regression"]["oracle_mean_holdout_mse"], 3), "", "", "", ""])
write("tab_b4_reg.tex", ["Runtime"] + [RN[k] for k in RULES], rows, "@{}llllll@{}")

# ---------------- across all ----------------
aa = S["across_all"]
(OUT / "across_all.tex").write_text(
    f"{aa['n_common_cells']} common cells; balanced recommendation differs on {100*aa['balanced_recommendation_differs']:.1f}\\% {cip(aa['balanced_recommendation_differs_ci95'])}, its device on {100*aa['balanced_device_differs']:.1f}\\%, error only on {100*aa['error_only_recommendation_differs']:.1f}\\% {cip(aa['error_only_recommendation_differs_ci95'])}\n")
print("tables written to", OUT)
