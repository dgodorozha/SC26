# Supplementary materials: appendix, code, notebooks and results

Supplementary materials for "Hardware Aware Evaluation Beyond Covariance: A General Selection Framework and
Benchmark for Statistical Estimators" (Godorozha, Ahmed, Shethwala and Liu, LSE; WHPC at SC26). The repository holds
the supplementary appendix with its source, the notebooks and code that produced every measurement, the raw result
files as the notebooks wrote them, the canonical true covariances of the eigensolver dependent cells, and the checks
that tie the reported numbers to the raw files. Every number in Table I of the extended abstract and in every table of
the appendix is generated from one file, `supplement/hardware_matrix_summary.json`, which is recomputed here from the
raw rows in two independent ways.

## Layout

| Folder | Contents |
|---|---|
| `supplement/` | the supplementary appendix (`whpc_supplementary.pdf`, 11 pages) and its LaTeX source (`main.tex`, IEEEtran V1.8b included); `tables/` holds the 19 generated table fragments; `gen_tables.py` regenerates every one of them from `hardware_matrix_summary.json`, the output of block 5 of the notebooks (the hardware matrix) and the single source of every number in the appendix and in Table I of the abstract; this is the summary of record, block 5 rerun on the raw files with the corrected identity fields (see `verification/README.md`) |
| `notebooks/` | one Colab notebook per runtime type (T4, L4, A100, RTX PRO 6000 Blackwell as `G4`, CPU only) and the block 5 notebook that reassembles the matrix without rerunning anything, all built from `build_notebook.py`; `covbench_code.zip`, the CovBench package every notebook runs (sha256 `9d7e0010...`, package content hash `2515241170db06b1`, which every row records); `experiments.parquet`, the MI300A rows (sha256 `d03a920e...`); `make_downstream_data.py` (the return panel and housing data preparation) and `fill_tables.py` (the ingestion script, which applies the quality gate); `README.md` describes the protocol, the data identity checks, the quality gate and how to run; `SHA256SUMS.txt` lists the file checksums |
| `results/` | `covbench_v2/`, the Drive folder the notebooks wrote, as downloaded on 7 November 2026 (43 MB): per block and runtime the run folder with `results.parquet` (every timed fit), `matrix_audit.parquet` (CPU against GPU fitted matrices, GPU runtimes) and `summary.json`; the per block reports under `notebook_results/`; the frozen return panel under `downstream/full/`; the markers under `true_covariances/`; its own copies of the code zip and the MI300A rows. `results/README.md` gives the layout |
| `verification/` | the block 5 rerun outside Colab on the raw files (`run_b5.py`, the executed notebook, the regenerated summary and the Colab original it reproduces number for number) and `recompute.py`, an independent script that uses none of the notebook code and recomputes 108 quantities of Table I, the identity counts, the cross runtime disagreement and the block 2 and 3 flip rates from the raw rows, all matching (`recompute_log.txt`); see its README |
| `canonical_true_covariances/` | the stored true covariances of the 108 eigensolver dependent cells (`files/<cell_id>.npz`, 35 MB, with checksums), which the Colab runs could not retrieve, and two checks: data regenerated from them reproduce the recorded statistics of the MI300A rows on all 108 cells and agree with the four GPU runs on all 78 complete cells and with the CPU run on none; a third host generates a third matrix with the same spectrum on every cell. See its README |
| `release_reanalysis/` | `analysis_v2/`, the scripts that recompute every number of the MI300A benchmark from `data/experiments.parquet` (the 0.436 complete group flip rate, the tier and device migration, the Pareto and budget analyses, the design point bootstrap, the ROCm sensitivity, the CPU/GPU equivalence over the recorded metrics and the hard thresholding grid check that gives 0.449); `outputs/` is the result of running them (`bash analysis_v2/run_all.sh data outputs`) |
| `SHA256SUMS.txt` | checksums of every file in the repository (`sha256sum -c SHA256SUMS.txt`) |

## Requirements

Python 3.10 or later. The checks need `numpy`, `pandas` and `pyarrow`; the block 5 rerun also needs `nbformat`,
`nbclient` and `ipykernel`; the release reanalysis also needs `matplotlib`, `scikit-learn` and (for `a07` only)
`torch` on CPU; the canonical covariance checks need `scipy` and the CovBench package unpacked from
`notebooks/covbench_code.zip` with its dependencies. The appendix compiles with `pdflatex`. The notebooks run on
Google Colab with a Drive mount; `verification/run_b5.py` runs the block 5 notebook anywhere.

## Regenerating the appendix tables

    cd supplement
    python gen_tables.py hardware_matrix_summary.json tables
    pdflatex main.tex && pdflatex main.tex

The 19 fragments in `tables/` are byte for byte what this command writes. Table I of the abstract is typed from the
same JSON (`hardware[<runtime>].groups.phi`, `.phi_ci95`, `.phi_gate_1s`, `hardware[<runtime>].pooled.cpu_to_gpu`,
`.gpu_to_cpu`, `hardware[<runtime>].gpu_speedup.ledoit_wolf_linear.median_paired_speedup`).

## Recomputing the summary from the raw files

By the notebook code, and independently of it:

    cd verification
    python run_b5.py ../notebooks/covbench_v2_hardware_matrix.ipynb <writable copy of ../results/covbench_v2>
    python -I recompute.py ../results/covbench_v2 ../supplement/hardware_matrix_summary.json

The first rewrites `notebook_results/hardware_matrix_summary.json` in the copy (about two minutes); the second prints
108 quantities against the summary of record, every one equal to floating point (`recompute_log.txt` is its output).
Every number of the MI300A benchmark is recomputed from its rows with

    cd release_reanalysis
    bash analysis_v2/run_all.sh data outputs

## Reproducing the measurements

`notebooks/README.md` is the full description. In short: put `covbench_code.zip` and `experiments.parquet` in
`MyDrive/covbench_v2/`, open the notebook for a runtime type in Colab with that runtime selected, run all. Each
block checkpoints to Drive and resumes; block 5 runs last and writes `notebook_results/hardware_matrix_summary.json`,
which is the file in `supplement/`. Approximate wall clock per runtime: block 1 about 200 min on the A100 and L4
runtimes and 308 min on the CPU only runtime, block 3 184 to 264 min, block 2 86 to 140 min, block 4 23 to 28 min.
A run is used only if its planned set is complete, on one software stack, with the audited code hash; block 5 lists
every other run folder as superseded with the reason.

## Data identity and provenance

Between Colab runs a cell is consistent when its data and covariance hashes are equal or, failing that, when its 17
recorded statistics and sample covariance loss agree to a relative 1e-9; against the MI300A rows, which carry no
hashes, by the statistics alone. The 108 cells of the 36 eigensolver dependent design points were generated locally
on every runtime because the stored matrices could not be retrieved during the runs; the GPU runs reproduce the
MI300A rows on all 78 of them that are complete there, the CPU run on none, and the canonical matrices in
`canonical_true_covariances/` confirm both. Comparisons between runtimes use only cells that pass this check: all
429 cells complete on the MI300A against the four NVIDIA runtimes, 351 against the CPU only runtime.

The MI300A rows are `experiments.parquet` (sha256 `d03a920e...`), computed with the same CovBench package on a
dedicated MI300A node under ROCm; their hard thresholding rows were tuned over a different grid from the configured
one and their GPU fits ran under a different ROCm build from the other estimators, which the abstract reports as a
sensitivity (0.449 with the configured grid; 0.43 to 0.50 with those GPU times rescaled by 0.25 to 4). The return
panel of block 4 is `results/covbench_v2/downstream/full/returns_panel.parquet` (yfinance, the first 200 names with a
complete 2014 to 2024 history from a fixed list of 350 recorded in the notebook, 2,766 trading days; sha256
`182735ee...`, recorded in every block 4 summary). The California housing data are scikit-learn's
`fetch_california_housing` (the StatLib file `cal_housing.tgz`, 20,640 rows, which scikit-learn verifies against
sha256 `aaa5c9a6afe2225cc2aed2723682ae403280c4a3695a2ddda4ffb5d8215ea681`); every run records the same 20,640 rows
and 164 cubic features and the same retrospective oracle (0.43687, equal across runtimes to 1e-13); the folds are
`KFold(5, shuffle=True, random_state=0)` over the rows in scikit-learn's order, with feature scaling and target
standardisation fitted inside each split. `notebooks/make_downstream_data.py` writes the same table to
`california_housing.csv`, which the notebooks accept from `MyDrive/covbench_v2/downstream/` and record by checksum.

## Still to be added

- The frozen housing CSV in `results/covbench_v2/downstream/` (`notebooks/make_downstream_data.py` writes it; the
  verification machine had no route to the download).
- The copies in Drive of `notebook_results/hardware_matrix_summary.json` and `true_covariances/` still hold the Colab
  summary and the `.missing` markers; a block 5 run of the rebuilt hardware matrix notebook rewrites the first, and
  copying `canonical_true_covariances/files/*.npz` into `true_covariances/` (deleting the markers) supplies the
  second.
- The public repository URL in `supplement/main.tex` (Section S8), and a licence file.
