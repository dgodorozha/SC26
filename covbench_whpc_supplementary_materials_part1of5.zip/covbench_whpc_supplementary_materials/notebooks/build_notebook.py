"""Builds the CovBench v2 Colab notebooks with nbformat: one per runtime type (T4, L4, A100, G4, CPU),
identical apart from a runtime check in the first cell, plus a matrix only notebook.

Each notebook has five blocks: 1 covariance portfolio on this CPU and accelerator, 2 dimension sweep,
3 regression family, 4 downstream validity, 5 hardware matrix across every runtime found in Drive.
Every result is keyed by the accelerator it ran on; resuming is refused across a change of software
stack or host CPU unless the user allows it; failed rows are retried up to three times; planned and
successful configuration counts are reported; rows carry full provenance.

Set COVBENCH_SMOKE=1 in the environment (or tick SMOKE_TEST in the first cell) for a few minute CPU
smoke test that exercises every cell on tiny problems. COVBENCH_SKIP_ACCELERATOR_CHECK=1 bypasses the
runtime check (used only to test the GPU copies on a machine without that GPU).
"""
import re
import textwrap
import nbformat as nbf
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED_PKG_HASH = "2515241170db06b1b19726fc212654c4087a424531edc98023221e4455d33bfb"
EXPECTED_PARQUET_SHA256 = "d03a920e5cae41e55d94456627af0a033d751fd997057322e2b03a665d050baf"

# ---------------------------------------------------------------------------
# 1. Setup
# ---------------------------------------------------------------------------
SETUP = r'''
# @title 1. Setup: runtime check, Drive, released CovBench code, environment record
BLOCKS = "__BLOCKS__"           # @param {type:"string"}   # blocks to run on this runtime, in this order. 4 = downstream validity (about 1 h), 1 = covariance on this CPU and GPU (about 5 h at 3 replicates), 3 = regression family (about 3 h), 2 = dimension sweep (about 3 h). Block 5, the hardware matrix across every runtime you have run, always runs last. The numbering is the paper's.
SMOKE_TEST = False              # @param {type:"boolean"}  # tick for a few minute check of every block on tiny problems
ALLOW_STACK_CHANGE = False      # @param {type:"boolean"}  # a resumed block stops if this session's host CPU, driver or library versions differ from the ones in its checkpoint; tick to continue anyway (every row records its own stack, and block 5 reports mixed runs)
ALLOW_UNVERIFIED_RELEASE = False # @param {type:"boolean"}  # the notebook stops if the released code or rows do not match the checksums recorded in the paper; tick to run on an unverified release (the hashes are still recorded in every row)
RETRY_EXHAUSTED = False         # @param {type:"boolean"}  # rows that failed three times are left alone on resume; tick to give each of them one more attempt in this session
ALLOW_MISSING_BASELINE = False  # @param {type:"boolean"}  # a full run stops if the released MI300A rows (experiments.parquet) are not in Drive, since the matrix and the cross hardware comparison need them; tick to run without them
ALLOW_SYNTHETIC_DATA = False    # @param {type:"boolean"}  # block 4 stops a full run if real data is unavailable (no return panel from yfinance or stooq and no user_prices.csv in MyDrive/covbench_v2/downstream/, or no California housing) rather than freezing the synthetic fallback for every later accelerator; tick to run block 4 on the labelled synthetic fallback
import os, sys, json, time, shutil, zipfile, platform, subprocess, math, warnings, traceback, re, hashlib, importlib.util, inspect
from pathlib import Path
from collections import Counter
SMOKE = SMOKE_TEST or os.environ.get("COVBENCH_SMOKE") == "1"
MODE = "smoke" if SMOKE else "full"
BLOCK_ORDER = [int(b) for b in BLOCKS.replace(" ", "").split(",") if b]
assert set(BLOCK_ORDER) <= {1, 2, 3, 4}, "BLOCKS must list numbers from 1 to 4 (block 5 runs on its own at the end)"

# ---- runtime check first, before anything is mounted, downloaded or written ----
import torch
HAS_CUDA = torch.cuda.is_available()
GPU_NAME = torch.cuda.get_device_name(0) if HAS_CUDA else ""
EXPECTED_ACCELERATOR, _match = "__VARIANT__", "__MATCH__"
if os.environ.get("COVBENCH_SKIP_ACCELERATOR_CHECK") != "1" and EXPECTED_ACCELERATOR != "ANY":
    if EXPECTED_ACCELERATOR == "CPU":
        if HAS_CUDA:
            raise SystemExit(f"this notebook is for the CPU runtime but this session has {GPU_NAME}. Runtime -> Change runtime type -> CPU, or open the notebook for that accelerator.")
    elif not HAS_CUDA or _match.lower() not in GPU_NAME.lower():
        raise SystemExit(f"this notebook is for the {EXPECTED_ACCELERATOR} runtime but this session has {GPU_NAME or 'no GPU'}. Runtime -> Change runtime type -> {EXPECTED_ACCELERATOR} GPU, or open the notebook for that accelerator.")
print("runtime check passed for", EXPECTED_ACCELERATOR, "|", GPU_NAME or "no GPU")

# ---- output location: Drive on Colab (fail closed if it cannot be mounted), a local folder elsewhere ----
IN_COLAB = importlib.util.find_spec("google.colab") is not None
if IN_COLAB:
    from google.colab import drive  # type: ignore
    try:
        drive.mount("/content/drive", force_remount=False)
    except Exception as e:
        raise SystemExit(f"Google Drive could not be mounted ({e}); results would be lost when the session ends, so the notebook stops here. Authorise Drive and run again.")
    ROOT = Path("/content/drive/MyDrive/covbench_v2")
    ROOT.mkdir(parents=True, exist_ok=True)
    probe = ROOT / ".write_probe"
    try:
        probe.write_text("ok"); probe.unlink()
    except Exception as e:
        raise SystemExit(f"{ROOT} is not writable ({e}); the notebook stops rather than write to the ephemeral disk.")
else:
    ROOT = Path(os.environ.get("COVBENCH_ROOT", "./covbench_v2")); ROOT.mkdir(parents=True, exist_ok=True)
RESULTS = ROOT / ("notebook_results_smoke" if SMOKE else "notebook_results"); RESULTS.mkdir(exist_ok=True)
print("blocks to run on this runtime, in order:", BLOCK_ORDER, "then block 5", "(SMOKE TEST)" if SMOKE else "")
print("results go to", ROOT, "and the summaries the paper ingests to", RESULTS)

# ---- dependencies: install, then verify every import so that a failed install stops here rather than later ----
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pyarrow", "pyyaml", "huggingface_hub", "scikit-learn", "pandas", "matplotlib"], check=False)
_missing = [m for m in ("numpy", "pandas", "pyarrow", "yaml", "sklearn", "matplotlib") if importlib.util.find_spec(m) is None]
if _missing:
    raise SystemExit(f"these packages are missing after the install step: {_missing}; pip output above says why")
import numpy as np, pandas as pd, yaml, sklearn, pyarrow

# ---- released code: Drive copy, else Hugging Face, else ask for an upload; content hash recorded in every row ----
EXPECTED_PKG_HASH = "__PKG_HASH__"
NEEDS_CODE = EXPECTED_ACCELERATOR != "ANY"
CODE_ZIP = ROOT / "covbench_code.zip"
PKG_PARENT, CODE_HASH = None, ""
if not CODE_ZIP.exists() and NEEDS_CODE:
    try:
        from huggingface_hub import hf_hub_download
        p = hf_hub_download(repo_id="AnonymousNeurIPS2026/CovBenchCode", repo_type="dataset", filename="covbench_code.zip")
        shutil.copy(p, CODE_ZIP); print("downloaded covbench_code.zip from Hugging Face")
    except Exception as e:
        print("could not download covbench_code.zip:", e)
        try:
            from google.colab import files  # type: ignore
            up = files.upload()
            for name, data in up.items():
                CODE_ZIP.write_bytes(data)
        except Exception:
            raise SystemExit("place covbench_code.zip in " + str(ROOT) + " and rerun")
if CODE_ZIP.exists():
    CODE_DIR = (Path("/content") if IN_COLAB else Path(".")) / "covbench_code_extracted"
    if CODE_DIR.exists():
        shutil.rmtree(CODE_DIR)
    with zipfile.ZipFile(CODE_ZIP) as z:
        z.extractall(CODE_DIR)
    for cand in CODE_DIR.rglob("estimators.py"):
        if cand.parent.name == "covbench" and "__MACOSX" not in str(cand):
            PKG_PARENT = cand.parent.parent; break
    assert PKG_PARENT is not None, "covbench/estimators.py not found in the zip"
    _h = hashlib.sha256()
    for f in sorted(PKG_PARENT.glob("covbench/*.py")) + [PKG_PARENT / "config.yaml"]:
        _h.update(str(f.relative_to(PKG_PARENT)).replace("\\", "/").encode()); _h.update(f.read_bytes())
    CODE_HASH = _h.hexdigest()[:16]
    if CODE_HASH == EXPECTED_PKG_HASH[:16]:
        print("released code verified: package content hash", CODE_HASH)
    elif ALLOW_UNVERIFIED_RELEASE:
        print(f"WARNING: the covbench package content hash is {CODE_HASH}, the paper bundle's is {EXPECTED_PKG_HASH[:16]}; running on an unverified release because ALLOW_UNVERIFIED_RELEASE is ticked. The hash is recorded in every row and block 5 flags the run.")
    else:
        raise SystemExit(f"the covbench package content hash is {CODE_HASH}, the paper bundle's is {EXPECTED_PKG_HASH[:16]}: this is not the audited release. Put the bundled covbench_code.zip in {ROOT}, or tick ALLOW_UNVERIFIED_RELEASE to run anyway.")
    sys.path.insert(0, str(PKG_PARENT))
    RELEASED_CONFIG = PKG_PARENT / "config.yaml"
    from covbench.config import load_config, expand_cells, CellSpec
    from covbench.data import generate_cell, regenerate_X
    from covbench.seeds import derive_data_seed, derive_estimator_seed, make_cell_key, make_cell_id
    from covbench.estimators import build_estimator, estimator_tier, list_estimators
    from covbench.hyperparams import select_hyperparameters
    from covbench.metrics import compute_all_metrics
    from covbench.devices import disable_tf32, configure_cpu_threads
elif NEEDS_CODE:
    raise SystemExit("covbench_code.zip is required for blocks 1 to 4")

# ---- released MI300A rows (optional): checked against the paper bundle's checksum ----
EXPECTED_PARQUET_SHA256 = "__PARQUET_SHA__"
RELEASED_PARQUET = ROOT / "experiments.parquet"
PARQUET_SHA = hashlib.sha256(RELEASED_PARQUET.read_bytes()).hexdigest() if RELEASED_PARQUET.exists() else ""
if PARQUET_SHA and PARQUET_SHA != EXPECTED_PARQUET_SHA256:
    if ALLOW_UNVERIFIED_RELEASE:
        print(f"WARNING: experiments.parquet sha256 {PARQUET_SHA[:16]} differs from the paper bundle's {EXPECTED_PARQUET_SHA256[:16]}; using it because ALLOW_UNVERIFIED_RELEASE is ticked")
    else:
        raise SystemExit(f"experiments.parquet sha256 {PARQUET_SHA[:16]} differs from the paper bundle's {EXPECTED_PARQUET_SHA256[:16]}: not the audited release. Put the bundled file in {ROOT}, or tick ALLOW_UNVERIFIED_RELEASE.")
elif PARQUET_SHA:
    print("released rows verified")
elif not SMOKE and not ALLOW_MISSING_BASELINE:
    raise SystemExit(f"experiments.parquet (the released MI300A rows) is not in {ROOT}. A full run needs it for the cross hardware comparison in block 1 and for the MI300A row of the matrix in block 5; copy it from the bundle into {ROOT}, or tick ALLOW_MISSING_BASELINE for an exploratory run without it (its matrix will then lack the MI300A row).")
else:
    print("experiments.parquet not found in", ROOT, "; the cross hardware comparison and the MI300A row of the matrix will be skipped")

# ---- environment record (one software stack per run; every row carries it) ----
def _sh(cmd):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=20).stdout.strip()
    except Exception:
        return ""
if PKG_PARENT is not None:
    _tf32 = disable_tf32(); configure_cpu_threads(os.cpu_count())
else:
    _tf32 = {}
torch.set_default_dtype(torch.float64)
ENV = {
    "notebook_variant": EXPECTED_ACCELERATOR, "smoke_test": SMOKE,
    "gpu_model": GPU_NAME, "gpu_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1) if HAS_CUDA else 0.0,
    "cuda_version": torch.version.cuda or "", "rocm_version": getattr(torch.version, "hip", "") or "",
    "driver_version": _sh("nvidia-smi --query-gpu=driver_version --format=csv,noheader") if HAS_CUDA else "",
    "cpu_model": _sh("grep -m1 'model name' /proc/cpuinfo | cut -d: -f2").strip() or platform.processor(), "cpu_threads": os.cpu_count(),
    "torch_version": torch.__version__, "numpy_version": np.__version__, "sklearn_version": sklearn.__version__, "pandas_version": pd.__version__, "pyarrow_version": pyarrow.__version__,
    "python_version": platform.python_version(), "hostname": platform.node(), "tf32": _tf32, "code_hash": CODE_HASH, "released_parquet_sha256": PARQUET_SHA,
}
STACK_FIELDS = ("gpu_model", "cpu_model", "cpu_threads", "driver_version", "cuda_version", "torch_version", "numpy_version", "sklearn_version", "pandas_version", "pyarrow_version", "python_version", "code_hash")
ENV["stack_id"] = hashlib.sha256("|".join(str(ENV[k]) for k in STACK_FIELDS).encode()).hexdigest()[:12]
json.dump(ENV, open(ROOT / "environment_last_session.json", "w"), indent=2)
print(json.dumps(ENV, indent=2))
DEVICES = ["cpu"] + (["cuda"] if HAS_CUDA else [])

# ---- every result is keyed by the accelerator it ran on (or the host CPU on the CPU runtime), so runs never collide ----
def _slug(x): return re.sub(r"[^a-z0-9]+", "_", str(x).lower()).strip("_")
HW = _slug(GPU_NAME) if HAS_CUDA else "cpu_" + _slug(ENV["cpu_model"])

def _source(obj):
    """Source text of a function defined in this notebook, or its compiled code if the source is unavailable."""
    try:
        return inspect.getsource(obj)
    except Exception:
        return repr(getattr(obj, "__code__", obj).co_code) + repr(getattr(obj, "__code__", obj).co_consts)

def protocol_fingerprint(params, *funcs):
    """Hash of a block's parameters and of the code it runs, so that a changed protocol never resumes stale rows."""
    h = hashlib.sha256(json.dumps(params, sort_keys=True, default=str).encode())
    for f in funcs:
        h.update(_source(f).encode())
    return h.hexdigest()[:10]

def legacy_results(name=None):
    """Result files written by notebook versions before 4 November 2026, which sat directly under <hardware>/<mode>/ without a
    protocol folder or the current columns. They are never read; the user is told where they are."""
    pat = f"{name}/*/{MODE}/results*.parquet" if name else f"block*/*/{MODE}/results*.parquet"
    return sorted(str(p_.relative_to(ROOT)) for p_ in ROOT.glob(pat))

def block_out(name, params=None, *funcs):
    """Results folder keyed by accelerator, mode and protocol fingerprint; a manifest records what the fingerprint hashes."""
    fp = protocol_fingerprint(params or {}, *funcs)
    out = ROOT / name / HW / MODE / fp; out.mkdir(parents=True, exist_ok=True)
    old = legacy_results(name)
    if old:
        print(f"NOTE: {len(old)} result file(s) from an earlier notebook version found and ignored (move or delete them): {old[:3]}{' ...' if len(old) > 3 else ''}")
    manifest = out / "manifest.json"
    if not manifest.exists():
        json.dump({"block": name, "hardware_key": HW, "mode": MODE, "protocol_id": fp, "params": params or {}, "functions": [f.__name__ for f in funcs], "created": time.strftime("%Y-%m-%d %H:%M:%S"), "stack_id": ENV["stack_id"]}, open(manifest, "w"), indent=2, default=str)
    else:
        m = json.load(open(manifest)); m["last_resumed"] = time.strftime("%Y-%m-%d %H:%M:%S"); json.dump(m, open(manifest, "w"), indent=2, default=str)
    print(f"{name}: protocol {fp} -> {out}")
    return out
print("this runtime is recorded as", HW, "| stack", ENV["stack_id"])
'''

# ---------------------------------------------------------------------------
# 2. Runner
# ---------------------------------------------------------------------------
RUNNER = r'''
# @title 2. Checkpointed runner (same timing definition as the release: wall clock from before the host to device copy to after the result is back on the host, hyperparameter selection included, CUDA synchronised)
from time import perf_counter

def _sync(dev):
    if dev.type == "cuda":
        torch.cuda.synchronize()

ENV_COLS = ("gpu_model", "cuda_version", "rocm_version", "driver_version", "cpu_model", "cpu_threads", "torch_version", "numpy_version", "sklearn_version", "pandas_version", "pyarrow_version", "python_version", "hostname", "stack_id", "code_hash")
MAX_ATTEMPTS = 3   # the release's retry policy for numerical failures and out of memory; an invalid (non finite) result also consumes an attempt

def _warn_summary(wl):
    return {"n_warnings": len(wl), "convergence_warning": int(any("onverg" in str(w.message) or "onverg" in w.category.__name__ for w in wl))}

def timed_fit(name, strategy, params, X_np, Sigma, Omega, device_str, cell, salt, implementation="covbench_torch", fidelity="full", keep_sigma=False):
    """One configuration on one cell. Returns a row in the CovBench schema (subset) plus the implementation and
    fidelity columns, the warnings the fit raised, and the full stack. Never raises. With keep_sigma the fitted
    matrix is returned in row["_sigma_hat"] (popped before saving)."""
    dev = torch.device(device_str)
    row = dict(cell_id=cell.cell_id, cell_key=cell.cell_key, structure_family=cell.structure_id,
               structure_params_json=json.dumps(cell.structure_params, sort_keys=True),
               spectrum_type=cell.spectrum_id, spectrum_params_json=json.dumps(cell.spectrum_params, sort_keys=True),
               distribution=cell.distribution_id, distribution_params_json=json.dumps(cell.distribution_params, sort_keys=True),
               n=int(cell.n), p=int(cell.p), p_over_n=float(cell.p_over_n), replicate_id=int(cell.replicate_id),
               estimator_name=name, estimator_tier=estimator_tier(name) if name in list_estimators() else "",
               device=device_str, implementation=implementation, fidelity=fidelity,
               hyperparam_strategy=strategy, precision="f64", status="success", error_message="", **{k: ENV[k] for k in ENV_COLS})
    data_seed = derive_data_seed(cell.cell_key, salt)
    est_seed = int(derive_estimator_seed(data_seed, name, strategy))
    row.update(data_seed=int(data_seed), estimator_seed=est_seed)
    with warnings.catch_warnings(record=True) as wl:
        warnings.simplefilter("always")
        try:
            _sync(dev); t0 = perf_counter()
            X = torch.from_numpy(X_np).to(device=dev, dtype=torch.float64); _sync(dev)
            t_h2d = perf_counter() - t0
            t1 = perf_counter()
            chosen, _ = select_hyperparameters(name, strategy, params, X, est_seed); _sync(dev)
            t_hp = perf_counter() - t1
            est = build_estimator(name, chosen, seed=est_seed)
            t2 = perf_counter()
            res = est.fit(X); _sync(dev)
            t_fit = perf_counter() - t2
            t3 = perf_counter()
            Sh = res.sigma_hat.detach().to("cpu").numpy().astype(np.float64); _sync(dev)
            t_d2h = perf_counter() - t3
            wall = perf_counter() - t0
            row.update(fit_wall_time_s=wall, compute_time_s=t_fit, h2d_time_s=t_h2d, d2h_time_s=t_d2h, hyperparam_selection_time_s=t_hp, iterations=int(res.iterations),
                       hyperparams_chosen_json=json.dumps({**chosen, **res.hyperparams_used}, sort_keys=True, default=str), estimator_version=getattr(est, "version", ""))
            row.update(compute_all_metrics(Sh, Sigma, Omega))
            if not np.isfinite(row.get("frobenius_loss", np.nan)):
                row["status"] = "invalid_result"; row["error_message"] = "non finite Frobenius loss"
            if keep_sigma:
                row["_sigma_hat"] = Sh
        except torch.cuda.OutOfMemoryError as e:
            row.update(status="oom", error_message=str(e)[:200])
        except Exception as e:
            row.update(status="numerical_fail", error_message=f"{type(e).__name__}: {str(e)[:200]}")
    row.update(_warn_summary(wl))
    return row

class Checkpoint:
    """Rows go to a parquet in Drive every `every` rows, written atomically (temporary file, previous file kept as
    .bak until the new one is verified). On restart, successful rows are skipped; failed and invalid rows are retried
    up to MAX_ATTEMPTS; the run refuses to continue under a different software stack or host CPU unless allowed."""
    def __init__(self, path, keycols, every=40):
        self.path = Path(path); self.bak = self.path.with_suffix(".parquet.bak"); self.keycols = keycols; self.every = every; self.buf = []
        self.ok = set(); self.attempts = Counter(); self.last_status = {}; self.prov = {}; self.inconsistent = set()
        old = self._read_existing()
        if old is not None:
            if "cell_id" in old and "data_sha256" in old:   # the data version each cell's rows were computed on; a cell with rows of two versions is flagged
                for cid, g in old.dropna(subset=["data_sha256"]).groupby("cell_id"):
                    versions = set(zip(g.sigma_sha256.astype(str), g.data_sha256.astype(str)))
                    if len(versions) > 1: self.inconsistent.add(str(cid))
                    self.prov[str(cid)] = (str(g.sigma_sha256.iloc[0]), str(g.data_sha256.iloc[0]), str(g.sigma_source.iloc[0]) if "sigma_source" in g else "")
                if self.inconsistent: print(f"WARNING: {self.path.name} holds rows of more than one data version for {len(self.inconsistent)} cell(s); they will be recomputed")
            keys = list(map(tuple, old[keycols].astype(str).to_numpy()))
            for k, st in zip(keys, old["status"]):
                self.last_status[k] = st
                if st == "success": self.ok.add(k)
                else: self.attempts[k] += 1
            if RETRY_EXHAUSTED:
                for k in list(self.attempts):
                    if k not in self.ok and self.attempts[k] >= MAX_ATTEMPTS: self.attempts[k] = MAX_ATTEMPTS - 1
            print(f"resuming {self.path.name}: {len(self.ok)} rows done, {sum(1 for k in self.attempts if k not in self.ok and self.attempts[k] < MAX_ATTEMPTS)} keys to retry, {sum(1 for k in self.attempts if k not in self.ok and self.attempts[k] >= MAX_ATTEMPTS)} keys exhausted")
            if "stack_id" in old:
                stacks = set(old["stack_id"].dropna().astype(str))
                if stacks and ENV["stack_id"] not in stacks:
                    first = old.iloc[0]; diffs = {k: (str(first.get(k, "")), str(ENV[k])) for k in STACK_FIELDS if k in old and str(first.get(k, "")) != str(ENV[k])}
                    msg = f"this checkpoint was written under a different stack: {diffs}."
                    if not ALLOW_STACK_CHANGE:
                        raise SystemExit(msg + " Pick a runtime that matches, or tick ALLOW_STACK_CHANGE in cell 1 to continue; every row records its stack and block 5 reports the mixture.")
                    print("WARNING:", msg, "continuing; block 5 will report this run as mixed")
    def _read_existing(self):
        for cand in (self.path, self.bak):
            if cand.exists():
                try:
                    df = pd.read_parquet(cand)
                    if cand is self.bak: print(f"WARNING: {self.path.name} was missing or unreadable; recovered {len(df)} rows from the backup"); df.to_parquet(self.path, index=False)
                    return df
                except Exception as e:
                    print(f"WARNING: could not read {cand.name}: {e}")
        return None
    def is_done(self, key):
        key = tuple(map(str, key)); return key in self.ok or self.attempts[key] >= MAX_ATTEMPTS
    def all_done(self, keys):
        return all(self.is_done(k) for k in keys)
    def drop_cell(self, cell_id):
        """Remove every row of one cell, so that it is recomputed: used when the cell's data no longer match the data its rows were computed on."""
        self.flush()
        if not self.path.exists(): return 0
        old = pd.read_parquet(self.path); keep = old[old.cell_id.astype(str) != str(cell_id)]; n = len(old) - len(keep)
        if n:
            tmp = self.path.with_suffix(".parquet.tmp"); keep.to_parquet(tmp, index=False); assert len(pd.read_parquet(tmp)) == len(keep); shutil.copy2(self.path, self.bak); os.replace(tmp, self.path)
            gone = [k for k in set(self.ok) | set(self.attempts) | set(self.last_status) if k[0] == str(cell_id)]
            for k in gone: self.ok.discard(k); self.attempts.pop(k, None); self.last_status.pop(k, None)
        self.prov.pop(str(cell_id), None); self.inconsistent.discard(str(cell_id))
        return n
    def add(self, row):
        row = {k: v for k, v in row.items() if not k.startswith("_")}
        if "cell_id" in row and row.get("data_sha256") and str(row["cell_id"]) not in self.prov:
            self.prov[str(row["cell_id"])] = (str(row.get("sigma_sha256")), str(row["data_sha256"]), str(row.get("sigma_source", "")))
        key = tuple(str(row[k]) for k in self.keycols); self.last_status[key] = row.get("status")
        if row.get("status") == "success": self.ok.add(key); row["attempt_count"] = self.attempts[key] + 1
        else: self.attempts[key] += 1; row["attempt_count"] = self.attempts[key]
        self.buf.append(row)
        if len(self.buf) >= self.every:
            self.flush()
    def flush(self):
        if not self.buf:
            return
        new = pd.DataFrame(self.buf); self.buf = []
        old = pd.read_parquet(self.path) if self.path.exists() else None
        new = pd.concat([old, new], ignore_index=True) if old is not None else new
        tmp = self.path.with_suffix(".parquet.tmp"); new.to_parquet(tmp, index=False)
        check = pd.read_parquet(tmp)   # verify the new file before it replaces the old one
        assert len(check) == len(new), "checkpoint verification failed"
        if self.path.exists(): shutil.copy2(self.path, self.bak)
        os.replace(tmp, self.path)
    def load(self):
        self.flush(); return pd.read_parquet(self.path) if self.path.exists() else pd.DataFrame()
    def report(self, planned):
        """Planned configurations against outcomes: success, invalid after retries, failed after retries, pending."""
        planned = [tuple(map(str, k)) for k in planned]
        n_ok = sum(1 for k in planned if k in self.ok)
        exhausted = [k for k in planned if k not in self.ok and self.attempts[k] >= MAX_ATTEMPTS]
        n_inv = sum(1 for k in exhausted if self.last_status.get(k) == "invalid_result"); n_fail = len(exhausted) - n_inv
        rep = {"n_planned": len(planned), "n_success": n_ok, "n_invalid_after_retries": n_inv, "n_failed_after_retries": n_fail, "n_pending": len(planned) - n_ok - len(exhausted)}
        rep["complete"] = bool(rep["n_success"] == rep["n_planned"])
        return rep

def hardware_seen(df):
    """Every CPU, GPU, library version, stack and code hash present in a results table, with row counts per stack."""
    out = {c: sorted(df[c].dropna().astype(str).unique()) for c in ("cpu_model", "gpu_model", "torch_version", "cuda_version", "driver_version", "numpy_version", "sklearn_version", "pandas_version", "pyarrow_version", "python_version", "code_hash") if c in df}
    if "stack_id" in df:
        out["rows_per_stack"] = {str(k): int(v) for k, v in df["stack_id"].value_counts().items()}; out["mixed_stacks"] = bool(df["stack_id"].nunique() > 1)
    return out

def warmup(names, devices):
    """Discarded first calls so that CUDA context creation and kernel compilation are not timed."""
    rng = np.random.default_rng(0); Xw = rng.standard_normal((120, 40))
    for d in devices:
        for nme in names:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore"); X = torch.from_numpy(Xw).to(torch.device(d)); build_estimator(nme, {}, seed=0).fit(X); _sync(torch.device(d))
            except Exception:
                pass

def eta(t_start, i, n):
    el = perf_counter() - t_start; return f"elapsed {el/60:.1f} min, about {el/max(i,1)*(n-i)/60:.0f} min remaining"

class Progress:
    """Remaining time from the work still to do, not from the count of cells: cells differ in cost (p squared times n), and cells finished in
    an earlier session take no time, so a count based estimate swings by a factor of several within a block."""
    def __init__(self, works):
        self.t0 = perf_counter(); self.todo = dict(works); self.done_work = 0.0
    def skip(self, key): self.todo.pop(key, None)
    def done(self, key): self.done_work += self.todo.pop(key, 0.0)
    def line(self):
        el = perf_counter() - self.t0; rem = sum(self.todo.values())
        return f"elapsed {el/60:.1f} min, about {el / self.done_work * rem / 60:.0f} min remaining" if self.done_work > 0 else f"elapsed {el/60:.1f} min"

def paired_speedup(d):
    """GPU speedup per estimator as the median over cells of the paired ratio T_cpu / T_gpu for the same cell, with the
    10th and 90th percentiles; a ratio of medians is reported alongside for comparison but is not the headline."""
    if "cuda" not in set(d.device): return {}
    c = d[(d.device == "cpu") & (d.status == "success")][["cell_id", "estimator_name", "fit_wall_time_s"]]
    g = d[(d.device == "cuda") & (d.status == "success")][["cell_id", "estimator_name", "fit_wall_time_s"]]
    m = c.merge(g, on=["cell_id", "estimator_name"], suffixes=("_cpu", "_gpu")); m["ratio"] = m.fit_wall_time_s_cpu / m.fit_wall_time_s_gpu
    out = {}
    for name, mm in m.groupby("estimator_name"):
        out[str(name)] = {"n_pairs": int(len(mm)), "median_paired_speedup": float(mm.ratio.median()), "q10": float(mm.ratio.quantile(.1)), "q90": float(mm.ratio.quantile(.9)),
                          "ratio_of_medians": float(mm.fit_wall_time_s_cpu.median() / mm.fit_wall_time_s_gpu.median())}
    return out

def fit_sigma(name, strategy, params, X_np, device_str, cell, salt):
    """Untimed fit returning the estimated covariance as a numpy array (for the CPU versus GPU matrix audit)."""
    dev = torch.device(device_str); est_seed = int(derive_estimator_seed(derive_data_seed(cell.cell_key, salt), name, strategy))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        X = torch.from_numpy(X_np).to(device=dev, dtype=torch.float64)
        chosen, _ = select_hyperparameters(name, strategy, params, X, est_seed)
        return build_estimator(name, chosen, seed=est_seed).fit(X).sigma_hat.detach().to("cpu").numpy().astype(np.float64)

def write_summary(S, out, k, status="complete"):
    """Write a block's summary to its protocol folder and a copy to notebook_results. A partial summary is marked as such
    and is not ingested by block 5 or by the paper's tables."""
    S["hardware_key"] = HW; S["stack_id"] = ENV["stack_id"]; S["status"] = status; S["protocol_id"] = out.name; S["written"] = time.strftime("%Y-%m-%d %H:%M:%S")
    json.dump(S, open(out / "summary.json", "w"), indent=2, default=str)
    shutil.copy(out / "summary.json", RESULTS / f"block{k}_{HW}_summary.json")
    print(f"written ({status}):", out / "summary.json", "and", RESULTS / f"block{k}_{HW}_summary.json")
'''

# ---------------------------------------------------------------------------
# 3. Oracle logic
# ---------------------------------------------------------------------------
ORACLE = r'''
# @title 3. Oracle logic (identical to analysis_v2 in the paper: tiers read from the rows, menus fixed by the released configuration)
EPS = 1e-8
RELEASE_MENU = {"cpu": ["sample_cov", "ledoit_wolf_linear", "nercome", "oas", "hard_thresholding", "poet", "graphical_lasso", "tyler_m"],
                "cuda": ["sample_cov", "ledoit_wolf_linear", "nercome", "hard_thresholding", "poet"]}   # the released portfolio: 8 estimators on CPU, the 5 dual device ones on GPU
def _minmax(x, floor=0.0):
    lo, hi = x.min(), x.max(); return (x - lo) / (max(hi - lo, floor) + EPS)
def scalarised_oracle(E, T, a, b, tau=0.0):
    J = a * _minmax(E) + b * _minmax(T, floor=tau); return int(np.lexsort((T, E, J))[0])
def pareto_mask(T, E, tol=1e-8):
    keep = np.ones(len(T), bool)
    for i in range(len(T)):
        eq = np.abs(E - E[i]) <= tol * max(abs(E[i]), 1e-300)
        dom = (T <= T[i]) & ((E < E[i]) | eq) & ((T < T[i]) | ((E < E[i]) & ~eq)); dom[i] = False
        if dom.any(): keep[i] = False
    return keep
def supported_mask(T, E, par):
    idx = np.where(par)[0]
    if len(idx) <= 2: return par.copy()
    pts = sorted(idx, key=lambda i: (T[i], E[i])); hull = []
    for i in pts:
        while len(hull) >= 2:
            a, b = hull[-2], hull[-1]
            if (T[b]-T[a])*(E[i]-E[a]) - (E[b]-E[a])*(T[i]-T[a]) <= 0: hull.pop()
            else: break
        hull.append(i)
    s = np.zeros_like(par); s[hull] = True; return s
def budget_choice(E, T, B):
    """argmin loss subject to time <= B over the efficient set (same tolerance as pareto_mask); None when nothing is feasible."""
    feas = (T <= B) & pareto_mask(T, E)
    if not feas.any(): return None
    cand = np.where(feas)[0]; return int(cand[np.lexsort((T[cand], E[cand]))[0]])

DESIGN_COLS = ["structure_family", "structure_params_json", "spectrum_type", "spectrum_params_json", "distribution", "distribution_params_json", "n"]
def design_key(df):
    cols = [c for c in DESIGN_COLS if c in df]
    return df[cols].astype(str).agg("|".join, axis=1)

def pooled_menu(menu):
    """The configuration identities of a pooled cell from a per device menu."""
    return sorted(f"{e}/{d}" for d, names in menu.items() for e in names)

def complete_groups(df, group_cols, menu):
    """Keep the groups whose configurations are exactly the planned set, by identity and not by count. For (cell, device)
    groups `menu` maps device -> list of estimator names; for pooled groups it is the list of configuration identities
    (estimator/device, or the `config` column when present). The paper's convention: 2,953 complete groups and 1,423
    complete pooled cells on the release."""
    if "device" in group_cols:
        ident = df["estimator_name"]; target = {d: frozenset(v) for d, v in menu.items()}
    else:
        ident = df["config"] if "config" in df else df["estimator_name"] + "/" + df["device"]; target = frozenset(menu)
    df = df.assign(_ident=ident)
    agg = df.groupby(group_cols)["_ident"].agg(lambda s: (frozenset(s), len(s))).reset_index()
    if "device" in group_cols:
        keep = agg[[v[0] == target.get(d) and v[1] == len(target.get(d, ())) for v, d in zip(agg["_ident"], agg["device"])]]
    else:
        keep = agg[[v[0] == target and v[1] == len(target) for v in agg["_ident"]]]
    return df.merge(keep[group_cols], on=group_cols).drop(columns="_ident"), int(len(agg)), int(len(keep))

def cluster_bootstrap(values, clusters, n_boot=2000, seed=20261102):
    """Mean of `values` with a 95% interval from resampling clusters (design points) with replacement. Clusters are
    taken in order of first appearance and drawn with the same generator and seed as the paper's analysis script
    (a04), so on the released rows this reproduces the paper's intervals exactly."""
    v = np.asarray(values, float); c = np.asarray(clusters)
    uniq, first_idx, inv = np.unique(c, return_index=True, return_inverse=True)
    order = np.argsort(first_idx); rank = np.empty_like(order); rank[order] = np.arange(len(order)); inv = rank[inv]
    sums = np.bincount(inv, weights=v, minlength=len(uniq)); cnt = np.bincount(inv, minlength=len(uniq)).astype(float)
    rng = np.random.default_rng(seed); K = len(uniq); boots = []
    for _ in range(n_boot):
        pick = rng.integers(0, K, K); boots.append(sums[pick].sum() / max(cnt[pick].sum(), 1))
    return {"mean": float(v.mean()) if len(v) else None, "ci95_lo": float(np.percentile(boots, 2.5)), "ci95_hi": float(np.percentile(boots, 97.5)), "n_clusters": int(K), "n_boot": n_boot}

def group_rows(df, group_cols, menu):
    """One row per complete group with the flip indicator and the migration flags; the input for every rate."""
    df = df[df.status == "success"]
    if not len(df): return pd.DataFrame(), 0, 0
    df, n_seen, n_complete = complete_groups(df, group_cols, menu)
    rows = []
    for key, g in df.groupby(group_cols, sort=False):
        if len(g) < 2: continue
        E, T = g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy()
        tiers, devs, names = g.estimator_tier.to_numpy(), g.device.to_numpy(), g.estimator_name.to_numpy()
        ieo, ibal = scalarised_oracle(E, T, 1, 0), scalarised_oracle(E, T, .5, .5)
        par = pareto_mask(T, E); sup = supported_mask(T, E, par)
        rows.append(dict(key=str(key), design=design_key(g.iloc[[0]]).iloc[0], flip=int(ieo != ibal), est_eo=names[ieo], est_bal=names[ibal], dev_eo=devs[ieo], dev_bal=devs[ibal],
                         c_to_b=int(tiers[ieo] == "C" and tiers[ibal] == "B"), b_to_c=int(tiers[ieo] == "B" and tiers[ibal] == "C"),
                         cpu_to_gpu=int(devs[ieo] == "cpu" and devs[ibal] == "cuda"), gpu_to_cpu=int(devs[ieo] == "cuda" and devs[ibal] == "cpu"),
                         n_pareto=int(par.sum()), n_unsupported=int(par.sum() - sup.sum()),
                         time_saved_s=float(T[ieo] - T[ibal]), err_regret_rel=float((E[ibal] - E[ieo]) / E[ieo]),
                         eo_feasible_100ms=int(T[ieo] <= 0.1), gate_1s_flip=int(ieo != scalarised_oracle(E, T, .5, .5, tau=1.0))))
    return pd.DataFrame(rows), n_seen, n_complete

def summarise_groups(df, group_cols, label, menu, boot=True):
    """Flip rate (with a design point bootstrap interval), migration, Pareto and supported counts, budget feasibility, on complete groups."""
    R, n_seen, n_complete = group_rows(df, group_cols, menu)
    if R.empty: return {"label": label, "n_groups": 0, "n_groups_seen": n_seen}
    F = R[R.flip == 1]
    out = {"label": label, "n_groups": int(len(R)), "n_groups_seen": n_seen, "phi": float(R.flip.mean()), "phi_gate_1s": float(R.gate_1s_flip.mean()),
           "c_to_b": float(R.c_to_b.mean()), "b_to_c": float(R.b_to_c.mean()), "cpu_to_gpu": float(R.cpu_to_gpu.mean()), "gpu_to_cpu": float(R.gpu_to_cpu.mean()),
           "mean_pareto": float(R.n_pareto.mean()), "frac_groups_unsupported": float((R.n_unsupported > 0).mean()), "eo_feasible_100ms": float(R.eo_feasible_100ms.mean()),
           "median_time_saved_s_given_flip": float(F.time_saved_s.median()) if len(F) else None, "median_err_regret_given_flip": float(F.err_regret_rel.median()) if len(F) else None,
           "top_transitions": {f"{a}->{b}": int(v) for (a, b), v in F.groupby(["est_eo", "est_bal"]).size().sort_values(ascending=False).head(6).items()}}
    if boot and R.design.nunique() > 1:
        out["phi_ci95"] = cluster_bootstrap(R.flip, R.design); out["cpu_to_gpu_ci95"] = cluster_bootstrap(R.cpu_to_gpu, R.design); out["gpu_to_cpu_ci95"] = cluster_bootstrap(R.gpu_to_cpu, R.design)
    return out
'''

# ---------------------------------------------------------------------------
# 4. Regression implementations (blocks 3 and 4)
# ---------------------------------------------------------------------------
REG_IMPL = r'''
# @title 4. Three implementations of one penalised regression estimator (blocks 3 and 4)
# objective (shared by all three): (1/2n)||y - Xb||^2 + lam * (l1r * ||b||_1 + (1 - l1r)/2 * ||b||^2), scikit-learn's elastic net parameterisation.
# Each configuration selects its own lambda with its own implementation, device and iteration cap, and that selection time is part of its
# wall clock, exactly as the covariance family's cross validation is part of a configuration's wall clock in the release.
from sklearn.linear_model import Ridge, Lasso, ElasticNet

def soft(z, t): return torch.sign(z) * torch.clamp(z.abs() - t, min=0.0)

def prox_grad(X, y, lam, l1r, iters, device):
    """FISTA (accelerated proximal gradient); iteration cap is the fidelity knob."""
    Xd, yd = torch.as_tensor(X, device=device), torch.as_tensor(y, device=device); n, p = Xd.shape
    Lc = (torch.linalg.matrix_norm(Xd, 2) ** 2 / n + lam * (1 - l1r)).item(); step = 1.0 / Lc
    b = torch.zeros(p, device=device, dtype=Xd.dtype); z = b.clone(); t = 1.0
    for k in range(iters):
        g = Xd.T @ (Xd @ z - yd) / n + lam * (1 - l1r) * z
        b_new = soft(z - step * g, step * lam * l1r); t_new = (1 + math.sqrt(1 + 4 * t * t)) / 2
        z = b_new + (t - 1) / t_new * (b_new - b); b, t = b_new, t_new
    return b.cpu().numpy(), iters

def admm(X, y, lam, l1r, iters, device, rho=1.0):
    """ADMM with one Cholesky factorisation; iteration cap is the fidelity knob."""
    Xd, yd = torch.as_tensor(X, device=device), torch.as_tensor(y, device=device); n, p = Xd.shape
    A = Xd.T @ Xd / n + (lam * (1 - l1r) + rho) * torch.eye(p, device=device, dtype=Xd.dtype); Lchol = torch.linalg.cholesky(A)
    q = Xd.T @ yd / n; z = torch.zeros(p, device=device, dtype=Xd.dtype); u = z.clone()
    for k in range(iters):
        b = torch.cholesky_solve((q + rho * (z - u)).unsqueeze(1), Lchol).squeeze(1)
        z = soft(b + u, lam * l1r / rho); u = u + b - z
    return z.cpu().numpy(), iters

def sklearn_cd(X, y, lam, l1r, iters):
    """scikit-learn: closed form ridge, coordinate descent otherwise (the reference implementation)."""
    if l1r == 0.0: m = Ridge(alpha=lam * len(y), fit_intercept=False)
    elif l1r == 1.0: m = Lasso(alpha=lam, fit_intercept=False, max_iter=iters, tol=1e-6)
    else: m = ElasticNet(alpha=lam, l1_ratio=l1r, fit_intercept=False, max_iter=iters, tol=1e-6)
    m.fit(X, y)
    it = getattr(m, "n_iter_", iters)
    return m.coef_, int(it if np.isscalar(it) else iters)

ESTIMATORS = {"ridge": 0.0, "lasso": 1.0, "elastic_net": 0.5}      # name -> l1 ratio
LAMBDA_GRID = [0.001, 0.01, 0.1, 1.0]

def _fit(impl, dev, iters, X, y, lam, l1r):
    if impl.startswith("sklearn"): return sklearn_cd(X, y, lam, l1r, iters)
    if impl == "admm": return admm(X, y, lam, l1r, iters, dev)
    return prox_grad(X, y, lam, l1r, iters, dev)

def tune_and_fit(impl, device_str, iters, X, y, l1r):
    """Timed lambda selection (two fold cross validation over the fixed grid, both directions averaged, with this
    implementation on this device at this cap) followed by the final fit on all rows. Returns coef, lam, iterations,
    selection time, fit time, total wall clock, and the warnings raised."""
    dev = torch.device(device_str); n = len(y); half = n // 2
    folds = ((slice(0, half), slice(half, n)), (slice(half, n), slice(0, half)))
    with warnings.catch_warnings(record=True) as wl:
        warnings.simplefilter("always")
        _sync(dev); t0 = perf_counter(); best, bl = None, np.inf
        for lam in LAMBDA_GRID:
            loss = 0.0
            for tr, va in folds:
                b, _ = _fit(impl, dev, iters, X[tr], y[tr], lam, l1r); loss += float(np.mean((X[va] @ b - y[va]) ** 2)) / 2
            if loss < bl: best, bl = lam, loss
        _sync(dev); t_sel = perf_counter() - t0
        t1 = perf_counter(); b, used = _fit(impl, dev, iters, X, y, best, l1r); _sync(dev); t_fit = perf_counter() - t1
    return b, best, int(used), t_sel, t_fit, t_sel + t_fit, _warn_summary(wl)

def configs_for(l1r, devices, iter_caps):
    ref = ("sklearn_closed_form", "cpu", 1) if l1r == 0.0 else ("sklearn_cd", "cpu", 2000)
    return [ref] + [(impl, d, it) for impl in ("admm", "prox_grad") for d in devices for it in iter_caps]

RULES = {"error_only": None, "balanced": None, "budget_10ms": 0.01, "budget_100ms": 0.1, "budget_1s": 1.0}

def rule_pick(E, T, rule, B=None):
    """Index chosen by a rule, or None when the budget rule has no feasible configuration."""
    if rule == "error_only": return scalarised_oracle(E, T, 1, 0)
    if rule == "balanced": return scalarised_oracle(E, T, .5, .5)
    return budget_choice(E, T, B)

def warmup_regression(devices):
    rng = np.random.default_rng(0); Xw, yw = rng.standard_normal((50, 10)), rng.standard_normal(50)
    for d in devices:
        try: admm(Xw, yw, 0.1, 0.5, 3, torch.device(d)); prox_grad(Xw, yw, 0.1, 0.5, 3, torch.device(d))
        except Exception: pass
'''

# ---------------------------------------------------------------------------
# Block 1
# ---------------------------------------------------------------------------
B1_PARAMS = r'''
# @title Block 1 (paper: Notebook 1). The covariance portfolio on this CPU and accelerator, implementation runtime audit, cross hardware agreement with the MI300A release
B1_REPLICATES = 3    # @param {type:"integer"}   # 3 replicates = 459 cells, about 5 hours per runtime (the graphical lasso cross validation on the host CPU dominates). The paper's interval resamples the 153 design points rather than the replicates, so accelerators are worth more than replicates: run 3 on every GPU type you have rather than 10 on one. 10 = the complete released grid, about 15 to 18 hours on a T4 runtime
'''
B1_BODY = r'''
SALT = "covbench_v1_4"  # the release's salt, so every cell is bit identical to the MI300A run
cfg = load_config(RELEASED_CONFIG)
cfg.replicates = 1 if SMOKE else B1_REPLICATES
cells = expand_cells(cfg)
if SMOKE:   # two cells whose data reproduce exactly and one whose covariance depends on the eigensolver build, so the smoke test exercises the identity check
    cells = cells[:2] + [c for c in cells if (c.structure_id, c.spectrum_id) == ("spiked", "poly_decay")][:1]
est_cfgs = {e.name: e for e in cfg.estimators}
MENU = {"cpu": [e.name for e in cfg.estimators]} | ({"cuda": [e.name for e in cfg.estimators if e.tier == "B"]} if HAS_CUDA else {})   # the planned configuration set, by identity
OUT = block_out("block1_covariance_nvidia", {"replicates": cfg.replicates, "salt": SALT, "menu": MENU, "smoke": SMOKE}, timed_fit, fit_sigma, scalarised_oracle, pareto_mask, supported_mask, complete_groups, summarise_groups, run_block1)
n_design = len(set((c.structure_id, json.dumps(c.structure_params, sort_keys=True), c.spectrum_id, c.distribution_id, c.n) for c in cells))
print(f"{len(cells)} cells ({n_design} design points x {cfg.replicates} replicates); menu {MENU}")
ck = Checkpoint(OUT / "results.parquet", ["cell_id", "estimator_name", "device", "implementation"])
# the CPU versus GPU matrix audit: the fitted matrices themselves, not their losses, compared on this hardware for every dual device estimator
ck_m = Checkpoint(OUT / "matrix_audit.parquet", ["cell_id", "estimator_name"]) if HAS_CUDA else None
warmup(list(est_cfgs), DEVICES)
from sklearn.covariance import LedoitWolf as SKLW, OAS as SKOAS, EmpiricalCovariance as SKEmp
REFERENCE = {"ledoit_wolf_linear": SKLW, "oas": SKOAS, "sample_cov": SKEmp}   # implementation audit targets: LW and sample_cov are hand coded ports, oas wraps scikit-learn
import scipy.linalg

def eigenbasis_dependent(cell):
    """True when the cell's covariance depends on the eigensolver build. The released generator reshapes the spectrum on the eigenbasis of
    the structure matrix; within a degenerate eigenspace that basis is arbitrary, so another LAPACK gives another matrix (the block diagonal
    and spiked structures under the polynomial decay spectrum). Tested by regenerating the cell with a second eigensolver driver."""
    orig = np.linalg.eigh
    try:
        _, S1, _ = generate_cell(cell, SALT)
        np.linalg.eigh = lambda A: scipy.linalg.eigh(A, driver="evr")
        _, S2, _ = generate_cell(cell, SALT)
    finally:
        np.linalg.eigh = orig
    return bool(np.linalg.norm(S1 - S2) / np.linalg.norm(S1) > 1e-8)

REL_SIGMA_DIR = ROOT / "true_covariances"; REL_SIGMA_DIR.mkdir(exist_ok=True)
# statistics of the data that the release records per cell and that are deterministic in X across machines (the two bootstrap features
# depend on a seed the release did not record, and the spectral decay rate on the count of eigenvalues above 1e-16 of a singular matrix)
RELEASE_STATS = ["feat_kurtosis_mean", "feat_kurtosis_max", "feat_kurtosis_p95", "feat_skewness_mean", "feat_outlier_fraction", "feat_sample_cond", "feat_sample_effective_rank", "feat_sample_stable_rank",
                 "feat_spectral_entropy", "feat_top_eig_gap_ratio", "feat_max_eigval_to_trace", "feat_off_diag_mag_p50", "feat_off_diag_mag_p95", "feat_off_diag_mag_tail_decay", "feat_sparsity_score_soft", "feat_band_score", "feat_block_score"]
from covbench.features import compute_features
rel_paths, rel_stats = {}, {}
if RELEASED_PARQUET.exists():
    _r = pd.read_parquet(RELEASED_PARQUET, columns=["cell_id", "sigma_path"] + RELEASE_STATS).drop_duplicates("cell_id")
    rel_paths = {str(k): str(v) for k, v in zip(_r.cell_id, _r.sigma_path) if isinstance(v, str) and v}
    rel_stats = {str(r["cell_id"]): {k: float(r[k]) for k in RELEASE_STATS if pd.notna(r[k])} for _, r in _r.iterrows()}

def sha(arr):
    return hashlib.sha256(np.ascontiguousarray(arr, dtype=np.float64).tobytes()).hexdigest()

MIN_RELEASE_STATS = 16   # 17 statistics, of which the sample condition number is undefined when the sample covariance is singular

def release_statistics_agreement(cell, X_np):
    """The deterministic statistics of X (stored in every row under their release names) and their agreement with the release's recorded
    values for the cell. Agreement requires every statistic the release recorded for the cell to be computed, finite and within 1e-9, and at
    least MIN_RELEASE_STATS of them; a partial comparison is never a match. The release rows carry no hash, so this, with the sample
    covariance loss checked in the summary, is the evidence of identity with the release, reported as statistic agreement."""
    f = compute_features(X_np); stats = {k: float(f[k]) for k in RELEASE_STATS if k in f}
    st = rel_stats.get(cell.cell_id) or {}
    expected = sorted(st); compared = [k for k in expected if k in stats and np.isfinite(stats[k])]; missing = [k for k in expected if k not in compared]
    devs = [abs(stats[k] - st[k]) / max(1.0, abs(st[k])) for k in compared]
    agree = bool(st) and not missing and len(compared) >= MIN_RELEASE_STATS and bool(devs) and max(devs) < 1e-9
    return stats, {"release_stats_expected": len(expected), "release_stats_compared": len(compared), "release_stats_missing": ",".join(missing), "release_stats_max_rel_dev": float(max(devs)) if devs else np.nan, "release_stats_agree": agree}

def release_sigma(cell, Sigma_gen):
    """The release's own true covariance of a cell from its dataset repository, when published there, validated as the same design with the
    release's eigenbasis (same shape, symmetric, same spectrum to 1e-8). None when unavailable; the download is attempted once per cell."""
    path = rel_paths.get(cell.cell_id)
    if not path: return None
    local = REL_SIGMA_DIR / f"{cell.cell_id}.npz"; miss = REL_SIGMA_DIR / f"{cell.cell_id}.missing"   # a file placed in the folder by hand is used; a failed download is not retried until the marker is deleted
    if miss.exists() and not local.exists(): return None
    try:
        if not local.exists():
            from huggingface_hub import hf_hub_download
            got = hf_hub_download(repo_id="AnonymousNeurIPS2026/CovBench", repo_type="dataset", filename=path); shutil.copy(got, local)
        z = np.load(local); w_gen = np.sort(np.linalg.eigvalsh(Sigma_gen)); tol = 1e-8 * max(1.0, float(np.abs(w_gen).max()))
        for k in z.files:
            S = np.asarray(z[k], dtype=np.float64)
            if S.shape == Sigma_gen.shape and np.allclose(S, S.T, atol=1e-10) and np.max(np.abs(np.sort(np.linalg.eigvalsh(S)) - w_gen)) <= tol:
                return S
        miss.write_text("no array with the cell's spectrum"); return None
    except Exception as e:
        miss.write_text(str(e)[:200]); return None

planned = []
for cell in cells:
    planned += [(cell.cell_id, name, d, "covbench_torch") for name, e in est_cfgs.items() for d in (DEVICES if e.tier == "B" else ["cpu"])]
    planned += [(cell.cell_id, name, "cpu", "sklearn_reference") for name in REFERENCE]
planned_m = [(cell.cell_id, name) for cell in cells for name, e in est_cfgs.items() if e.tier == "B"] if HAS_CUDA else []
by_cell = {}
for k in planned: by_cell.setdefault(k[0], []).append(k)
t_start = perf_counter(); n_done = 0; prog = Progress({c.cell_id: float(c.n) * c.p ** 2 for c in cells}); recomputed = []
for ci, cell in enumerate(cells):
    # the data version this cell's rows were computed on, if any: each checkpoint file must hold one version and the two files must agree,
    # otherwise every row of the cell is discarded first, so that a cell with rows of two data versions is never left complete
    pin_a = ck.prov.get(cell.cell_id); pin_m = ck_m.prov.get(cell.cell_id) if ck_m is not None else None
    cross_inconsistent = (cell.cell_id in ck.inconsistent) or (ck_m is not None and cell.cell_id in ck_m.inconsistent) or (pin_a is not None and pin_m is not None and pin_a[:2] != pin_m[:2])
    if cross_inconsistent:
        n_dropped = ck.drop_cell(cell.cell_id) + (ck_m.drop_cell(cell.cell_id) if ck_m is not None else 0); recomputed.append(cell.cell_id); pin_a = pin_m = None
        print(f"NOTE: cell {cell.cell_id}: its rows held more than one data version across the results and matrix audit files; its {n_dropped} rows were discarded and the cell is recomputed")
    if ck.all_done(by_cell[cell.cell_id]) and (ck_m is None or ck_m.all_done([k for k in planned_m if k[0] == cell.cell_id])):
        prog.skip(cell.cell_id); continue
    X_np, Sigma, Omega = generate_cell(cell, SALT); sigma_source = "generated"; eb_dep = eigenbasis_dependent(cell)
    pinned = pin_a or pin_m
    if eb_dep and (pinned is None or pinned[2] == "release"):
        # the generated matrix is one of many this design admits; use the release's own matrix for the cell when it can be had, so the cell is the release's cell.
        # A cell whose completed rows used the generated matrix stays on it: one data version per cell.
        S_rel = release_sigma(cell, Sigma)
        if S_rel is not None:
            Sigma = S_rel; Omega = np.linalg.inv(Sigma); X_np = regenerate_X(cell, SALT, Sigma).astype(np.float64); sigma_source = "release"
        elif pinned is not None and pinned[2] == "release":
            raise SystemExit(f"cell {cell.cell_id}: its completed rows were computed on the release's true covariance, which is no longer available ({REL_SIGMA_DIR / (cell.cell_id + '.npz')} and the download). Restore the file, or delete this block's results folder {OUT} to recompute the block.")
    sig_sha, dat_sha = sha(Sigma), sha(X_np)
    if pinned is not None and (pinned[0], pinned[1]) != (sig_sha, dat_sha):
        # the cell's data are not the data its completed rows were computed on (a different host's eigensolver, say): rows of two data versions
        # never share a cell id, so every row of the cell is discarded and the cell is recomputed
        n_dropped = ck.drop_cell(cell.cell_id) + (ck_m.drop_cell(cell.cell_id) if ck_m is not None else 0); recomputed.append(cell.cell_id)
        print(f"NOTE: cell {cell.cell_id}: the data differ from the data its rows were computed on (sigma {pinned[0][:12]} -> {sig_sha[:12]}); its {n_dropped} rows were discarded and the cell is recomputed")
    stats, agreement = release_statistics_agreement(cell, X_np)
    provenance = {"sigma_source": sigma_source, "eigenbasis_dependent": eb_dep, "sigma_sha256": sig_sha, "data_sha256": dat_sha, **stats, **agreement}
    for name, e in est_cfgs.items():
        sig = {}
        for d in (DEVICES if e.tier == "B" else ["cpu"]):
            if ck.is_done((cell.cell_id, name, d, "covbench_torch")): continue
            row = timed_fit(name, e.strategy, dict(e.params), X_np, Sigma, Omega, d, cell, SALT, keep_sigma=(e.tier == "B" and HAS_CUDA) or (name in REFERENCE and d == "cpu"))
            sig[d] = row.pop("_sigma_hat", None); row.update(provenance); ck.add(row); n_done += 1
        if ck_m is not None and e.tier == "B" and not ck_m.is_done((cell.cell_id, name)):
            mrow = {"cell_id": cell.cell_id, "estimator_name": name, "p": int(cell.p), "n": int(cell.n), "p_over_n": float(cell.p_over_n), "status": "success", "error_message": "", **provenance, **{k: ENV[k] for k in ENV_COLS}}
            try:
                for d in ("cpu", "cuda"):
                    if sig.get(d) is None: sig[d] = fit_sigma(name, e.strategy, dict(e.params), X_np, d, cell, SALT)   # untimed refit when the timed fit happened in an earlier session
                diff = np.linalg.norm(sig["cpu"] - sig["cuda"]) / np.linalg.norm(sig["cpu"])
                mrow.update(matrix_rel_discrepancy=float(diff), matrix_max_abs_entry_diff=float(np.abs(sig["cpu"] - sig["cuda"]).max()))
                if not np.isfinite(diff): mrow["status"] = "invalid_result"
            except Exception as ex:
                mrow.update(status="numerical_fail", error_message=f"{type(ex).__name__}: {str(ex)[:200]}")
            ck_m.add(mrow)
        if name in REFERENCE and not ck.is_done((cell.cell_id, name, "cpu", "sklearn_reference")):
            # reference implementation on the same CPU and the same X, timed the same way (host side, no transfer); the fitted matrices are
            # compared directly (a loss based comparison is not an agreement measure: two near perfect fits can differ several fold in loss)
            with warnings.catch_warnings(record=True) as wl:
                warnings.simplefilter("always"); t0 = perf_counter(); m_ref = REFERENCE[name](assume_centered=False).fit(X_np); Sh = m_ref.covariance_; wall = perf_counter() - t0
            St = sig.get("cpu")
            if St is None:
                St = fit_sigma(name, e.strategy, dict(e.params), X_np, "cpu", cell, SALT)   # the port's matrix, refit untimed when its timed fit happened in an earlier session
            audit_cols = {"matrix_rel_discrepancy_vs_port": float(np.linalg.norm(St - Sh) / np.linalg.norm(Sh)), "ref_shrinkage": float(getattr(m_ref, "shrinkage_", np.nan)),
                          "matrix_rel_discrepancy_vs_port_same_normalisation": float(np.linalg.norm(St * (cell.n - 1) / cell.n - Sh) / np.linalg.norm(Sh)) if name == "sample_cov" else np.nan,
                          "port_is_wrapper": name == "oas", **provenance}
            row = dict(cell_id=cell.cell_id, cell_key=cell.cell_key, structure_family=cell.structure_id, structure_params_json=json.dumps(cell.structure_params, sort_keys=True),
                       spectrum_type=cell.spectrum_id, spectrum_params_json=json.dumps(cell.spectrum_params, sort_keys=True), distribution=cell.distribution_id,
                       distribution_params_json=json.dumps(cell.distribution_params, sort_keys=True), n=int(cell.n), p=int(cell.p), p_over_n=float(cell.p_over_n), replicate_id=int(cell.replicate_id),
                       estimator_name=name, estimator_tier=e.tier, device="cpu", implementation="sklearn_reference", fidelity="full", hyperparam_strategy="default", precision="f64",
                       status="success", error_message="", fit_wall_time_s=wall, compute_time_s=wall, h2d_time_s=0.0, d2h_time_s=0.0, hyperparam_selection_time_s=0.0, **audit_cols, **{k: ENV[k] for k in ENV_COLS})
            row.update(compute_all_metrics(Sh, Sigma, Omega)); row.update(_warn_summary(wl)); ck.add(row); n_done += 1
    prog.done(cell.cell_id)
    if ci % 10 == 0 or SMOKE:
        print(f"cell {ci+1}/{len(cells)}  rows this session {n_done}  {prog.line()}")
df = ck.load()
print(df.status.value_counts()); rep = ck.report(planned); print("planned configurations:", rep)
dfm = ck_m.load() if ck_m is not None else pd.DataFrame()
if ck_m is not None:
    rep_m = ck_m.report(planned_m) | {"applicable": True}
else:
    rep_m = {"applicable": False, "n_planned": 0, "n_success": 0, "n_invalid_after_retries": 0, "n_failed_after_retries": 0, "n_pending": 0, "complete": True, "note": "no accelerator on this runtime, so there are no GPU fitted matrices to compare"}
print("planned matrix audit:", rep_m)

# ---- summaries: flip rate on this hardware (with design point intervals), implementation audit, matrix audit, cross hardware agreement ----
cb = df[df.implementation == "covbench_torch"]
S = {"environment": ENV, "hardware_seen": hardware_seen(df), "planned": {"covariance": rep, "matrix_audit": rep_m}, "menu": MENU, "n_rows": int(len(df)),
     "status_counts": {str(k): int(v) for k, v in df.status.value_counts().items()}, "convergence_warnings": int(df["convergence_warning"].sum()) if "convergence_warning" in df else 0}
# the matrix audit is always written: its planned report is part of the gate, so a GPU run whose audit rows are missing or failed is not complete
ok = dfm[dfm.status == "success"] if len(dfm) else pd.DataFrame()
S["matrix_audit"] = {"planned": rep_m, "note": "relative Frobenius distance between the CPU and the GPU fitted matrices of the same cell, this hardware",
                     "n_rows": int(len(dfm)), "status_counts": {str(k): int(v) for k, v in dfm.status.value_counts().items()} if len(dfm) else {},
                     "by_estimator": {str(k): {"n": int(len(v)), "median": float(v.matrix_rel_discrepancy.median()), "p99": float(v.matrix_rel_discrepancy.quantile(.99)), "max": float(v.matrix_rel_discrepancy.max()),
                                               "frac_gt_1e-8": float((v.matrix_rel_discrepancy > 1e-8).mean()), "max_by_p_over_n": {str(kk): float(vv) for kk, vv in v.groupby("p_over_n").matrix_rel_discrepancy.max().items()}}
                                      for k, v in ok.groupby("estimator_name")} if len(ok) else {}}
if len(ok):
    print("matrix audit (CPU vs GPU fitted matrices):"); print(pd.DataFrame(S["matrix_audit"]["by_estimator"]).T[["n", "median", "max", "frac_gt_1e-8"]].to_string())
S["released_groups"] = summarise_groups(cb, ["cell_id", "device"], "cell x device groups on this hardware", MENU)
S["pooled_cells"] = summarise_groups(cb, ["cell_id"], "pooled cells (all configurations) on this hardware", pooled_menu(MENU))
S["cpu_only_groups"] = summarise_groups(cb[cb.device == "cpu"], ["cell_id", "device"], "CPU groups", MENU)
if HAS_CUDA:
    S["gpu_only_groups"] = summarise_groups(cb[cb.device == "cuda"], ["cell_id", "device"], "GPU groups", MENU)

aud = []   # implementation audit: the released port against the scikit-learn reference on the same CPU and X, runtime and fitted matrix
for name in ("ledoit_wolf_linear", "oas", "sample_cov"):
    a = df[(df.estimator_name == name) & (df.device == "cpu") & (df.implementation == "covbench_torch") & (df.status == "success")].set_index("cell_id")
    b = df[(df.estimator_name == name) & (df.implementation == "sklearn_reference") & (df.status == "success")].set_index("cell_id")
    j = a.join(b, rsuffix="_ref", how="inner")
    if len(j):
        r = j.fit_wall_time_s / j.fit_wall_time_s_ref; mdisc = j["matrix_rel_discrepancy_vs_port_ref"] if "matrix_rel_discrepancy_vs_port_ref" in j else j.get("matrix_rel_discrepancy_vs_port", pd.Series(dtype=float))
        same = j["matrix_rel_discrepancy_vs_port_same_normalisation_ref"] if "matrix_rel_discrepancy_vs_port_same_normalisation_ref" in j else j.get("matrix_rel_discrepancy_vs_port_same_normalisation", pd.Series(dtype=float))
        alpha_port = j.hyperparams_chosen_json.map(lambda t: (json.loads(t) if isinstance(t, str) else {}).get("alpha", (json.loads(t) if isinstance(t, str) else {}).get("shrinkage", np.nan))).astype(float)
        shr = j["ref_shrinkage_ref"] if "ref_shrinkage_ref" in j else j.get("ref_shrinkage", pd.Series(dtype=float))
        aud.append({"estimator": name, "kind": "wrapper of scikit-learn" if name == "oas" else "hand coded port", "n": int(len(j)),
                    "runtime_ratio_port_over_ref_median": float(r.median()), "runtime_ratio_q10": float(r.quantile(.1)), "runtime_ratio_q90": float(r.quantile(.9)),
                    "matrix_rel_discrepancy_median": float(mdisc.median()) if len(mdisc) else None, "matrix_rel_discrepancy_max": float(mdisc.max()) if len(mdisc) else None,
                    "matrix_rel_discrepancy_max_same_normalisation": (float(same.max()) if name == "sample_cov" and len(same) else None),
                    "shrinkage_abs_difference_median": float((alpha_port - shr).abs().median()) if name != "sample_cov" and len(shr) else None,
                    "shrinkage_abs_difference_max": float((alpha_port - shr).abs().max()) if name != "sample_cov" and len(shr) else None,
                    "loss_rel_discrepancy_max": float(((j.frobenius_loss - j.frobenius_loss_ref).abs() / j.frobenius_loss_ref).max())})
S["implementation_audit"] = aud
S["implementation_audit_note"] = ("Agreement is judged on the fitted matrices. The sample covariance port normalises by n - 1 and scikit-learn by n, so its raw discrepancy is 1/n and "
                                  "zero after rescaling; the Ledoit Wolf port estimates the shrinkage intensity in the Schafer Strimmer normalisation, so its intensity differs from "
                                  "scikit-learn's by a few hundredths and the matrices by up to a few percent; oas wraps scikit-learn, so its row measures the wrapper's overhead only. "
                                  "The loss based discrepancy is reported for completeness but is not an agreement measure: two near perfect fits can differ several fold in loss.")
print(pd.DataFrame(aud).to_string(index=False) if aud else "no audit rows")
med = cb[cb.status == "success"].groupby(["estimator_name", "device"]).fit_wall_time_s.median().unstack()
S["median_wall_clock"] = {str(k): {str(i): (None if pd.isna(x) else float(x)) for i, x in v.items()} for k, v in med.round(6).to_dict().items()}
S["gpu_speedup"] = paired_speedup(cb)
print(med); print("paired GPU speedups:", {k: round(v["median_paired_speedup"], 2) for k, v in S["gpu_speedup"].items()})

rel = None   # cross hardware comparison against the released MI300A rows on the same cells
if RELEASED_PARQUET.exists():
    rel = pd.read_parquet(RELEASED_PARQUET); rel = rel[rel.status == "success"]
if rel is not None:
    def oracle_table(d, menu):
        out = {}; d, _, _ = complete_groups(d, ["cell_id", "device"], menu)
        for key, g in d.groupby(["cell_id", "device"]):
            E, T = g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy(); nm = g.estimator_name.to_numpy()
            out[key] = (nm[scalarised_oracle(E, T, 1, 0)], nm[scalarised_oracle(E, T, .5, .5)])
        return out
    # data identity with the release, per cell. Every row of this run carries the sha256 of its X and Sigma; the release rows carry no hash,
    # so identity with the release is judged by agreement, to 1e-9, of the 16 or 17 deterministic statistics of the data the release
    # recorded for the cell and of the sample covariance loss (deterministic in X and Sigma). That is statistic agreement, stated as such:
    # cells whose matrix depends on the eigensolver build (eigenbasis_dependent) fail it unless the release's own matrix was used. Every
    # comparison with the release is restricted to the agreeing cells; comparisons between notebook runs use the hashes (block 5).
    sc = cb[(cb.estimator_name == "sample_cov") & (cb.device == "cpu") & (cb.status == "success")][["cell_id", "frobenius_loss"]].merge(
        rel[(rel.estimator_name == "sample_cov") & (rel.device == "cpu")][["cell_id", "frobenius_loss"]], on="cell_id", suffixes=("", "_rel"))
    sc["loss_agrees"] = (sc.frobenius_loss - sc.frobenius_loss_rel).abs() / sc.frobenius_loss_rel < 1e-9
    prov = cb.drop_duplicates("cell_id").set_index("cell_id")
    sc["stats_agree"] = sc.cell_id.map(prov["release_stats_agree"]).fillna(False).astype(bool) if "release_stats_agree" in prov else False
    sc["identical"] = sc.loss_agrees & sc.stats_agree
    identical = set(sc.cell_id[sc.identical])
    S["data_identity"] = {"method": "agreement, to 1e-9 relative, of the sample covariance loss and of the deterministic data statistics the release recorded per cell (hashes of X and Sigma are recorded in every row of this run; the release rows carry none)",
                          "n_cells": int(cb.cell_id.nunique()), "n_compared_with_release": int(len(sc)), "n_identical_to_release": int(len(identical)),
                          "n_loss_agrees_only": int((sc.loss_agrees & ~sc.stats_agree).sum()), "n_stats_agree_only": int((~sc.loss_agrees & sc.stats_agree).sum()),
                          "n_eigenbasis_dependent": int(prov["eigenbasis_dependent"].sum()) if "eigenbasis_dependent" in prov else None,
                          "n_release_sigma_used": int((prov["sigma_source"] == "release").sum()) if "sigma_source" in prov else None,
                          "n_cells_recomputed_after_data_change": len(recomputed), "cells_recomputed_after_data_change": recomputed,
                          "non_identical_by_structure_spectrum": {f"{k[0]}/{k[1]}": int(v) for k, v in sc[~sc.identical].merge(prov[["structure_family", "spectrum_type"]], left_on="cell_id", right_index=True).groupby(["structure_family", "spectrum_type"]).size().items()}}
    print(f"data identity with the release (statistic agreement): {len(identical)} of {len(sc)} cells agree on the sample covariance loss and the recorded data statistics ({S['data_identity']['n_eigenbasis_dependent']} eigenbasis dependent, {S['data_identity']['n_release_sigma_used']} with the release's matrix, {len(recomputed)} recomputed after a data change); non agreeing by structure/spectrum: {S['data_identity']['non_identical_by_structure_spectrum']}")
    here, there = oracle_table(cb[cb.status == "success"], MENU), oracle_table(rel, RELEASE_MENU)
    common = [k for k in here if k in there and k[0] in identical]
    m = cb[cb.cell_id.isin(identical)].merge(rel[["cell_id", "estimator_name", "device", "frobenius_loss", "fit_wall_time_s"]], on=["cell_id", "estimator_name", "device"], suffixes=("", "_mi300a"))
    m = m[m.status == "success"]
    m["err_rel_disc"] = (m.frobenius_loss - m.frobenius_loss_mi300a).abs() / m.frobenius_loss_mi300a
    m["time_ratio"] = m.fit_wall_time_s / m.fit_wall_time_s_mi300a
    S["cross_hardware"] = {"n_common_complete_groups": int(len(common)), "restricted_to": "cells whose data agree with the release's recorded statistics and sample covariance loss",
                           "error_only_oracle_agreement": float(np.mean([here[k][0] == there[k][0] for k in common])) if common else None,
                           "balanced_oracle_agreement": float(np.mean([here[k][1] == there[k][1] for k in common])) if common else None,
                           "error_discrepancy_max_by_estimator": {str(k): float(v) for k, v in m.groupby("estimator_name").err_rel_disc.max().items()},
                           "error_discrepancy_median_by_estimator": {str(k): float(v) for k, v in m.groupby("estimator_name").err_rel_disc.median().items()},
                           "wall_clock_ratio_this_over_mi300a_median": {f"{k[0]}/{k[1]}": float(v) for k, v in m.groupby(["estimator_name", "device"]).time_ratio.median().items()}}
    print(f"cross hardware on cells agreeing with the release: {len(common)} common complete groups; error only oracle agreement {S['cross_hardware']['error_only_oracle_agreement']}; balanced {S['cross_hardware']['balanced_oracle_agreement']}")
    print("max relative loss discrepancy against the release on identical cells, by estimator (hard thresholding reflects the release's grid defect, NERCOME its GPU path):"); print(m.groupby("estimator_name").err_rel_disc.max())
print(json.dumps({k: v for k, v in S.items() if k in ("released_groups", "pooled_cells", "planned")}, indent=2, default=str))
write_summary(S, OUT, 1)
return S
'''

# ---------------------------------------------------------------------------
# Block 2
# ---------------------------------------------------------------------------
B2_PARAMS = r'''
# @title Block 2 (paper: Notebook 2). Dimension sweep p in {100, 200, 500, 1000}, n in {p/2, p, 2p}
B2_P_VALUES = [100, 200, 500, 1000]   # @param
B2_REPLICATES = 2                      # @param {type:"integer"}   # 360 cells at 2 replicates
B2_TIER_C_MAX_P = 200                  # @param {type:"integer"}   # graphical lasso and Tyler are CPU only, so they do not depend on the GPU; 200 gives a 3 hour run. On one runtime set 500 to extend them (the graphical lasso cross validation at p = 500 takes 6 to 7 minutes per cell, about 10 more hours); p = 1000 would take days, and the release assigns p >= 1000 to GPU only estimators
'''
B2_BODY = r'''
P_VALUES, REPLICATES, TIER_C_MAX_P = list(B2_P_VALUES), B2_REPLICATES, B2_TIER_C_MAX_P
SALT = "covbench_v2_psweep"
if SMOKE:
    P_VALUES, REPLICATES, TIER_C_MAX_P = [40, 80], 1, 80
OUT = block_out("block2_dimension_sweep", {"p_values": P_VALUES, "replicates": REPLICATES, "tier_c_max_p": TIER_C_MAX_P, "salt": SALT, "smoke": SMOKE}, timed_fit, scalarised_oracle, pareto_mask, supported_mask, complete_groups, summarise_groups, run_block2)
base = yaml.safe_load(open(RELEASED_CONFIG))
base["absolute_p_values"] = P_VALUES; base["replicates"] = REPLICATES; base["batch_id"] = base["random_seed_salt"] = SALT
# one parameter setting per structure family and all three distributions (the contaminated one is what Tyler is for). AR(1) and banded
# carry their own spectra (spectrum_native, as in the release); block diagonal, sparse precision and spiked take the flat spectrum
base["structures"] = [{"id": "ar1", "params": {"rho": [0.7]}, "spectrum_native": True}, {"id": "banded", "params": {"bandwidth": [20]}, "spectrum_native": True},
                      {"id": "block_diagonal", "params": {"block_size": [10]}, "spectrum_native": False}, {"id": "sparse_precision", "params": {"sparsity": [0.05]}, "spectrum_native": False},
                      {"id": "spiked", "params": {"k_spikes": [10]}, "spectrum_native": False}]
base["spectra"] = [{"id": "flat", "params": {}}]
base["distributions"] = [{"id": "gaussian", "params": {}}, {"id": "t_dist", "params": {"df": [3]}}, {"id": "eps_contaminated", "params": {"epsilon": [0.10], "scale": 5.0}}]
if SMOKE:
    base["structures"] = base["structures"][:2]; base["distributions"] = base["distributions"][:1]; base["p_over_n_values"] = [1.0]
cfg_path = OUT / "config_psweep.yaml"; yaml.safe_dump(base, open(cfg_path, "w"))
cfg = load_config(cfg_path); cells = expand_cells(cfg); cells.sort(key=lambda c: (c.p, c.n, c.cell_id))
print(f"{len(cells)} cells across p={P_VALUES}")
est_cfgs = {e.name: e for e in cfg.estimators}
def menu_for(p):
    m = {"cpu": [e.name for e in est_cfgs.values() if not (e.tier == "C" and p > TIER_C_MAX_P)]}
    if HAS_CUDA: m["cuda"] = [e.name for e in est_cfgs.values() if e.tier == "B"]
    return m
ck = Checkpoint(OUT / "results.parquet", ["cell_id", "estimator_name", "device", "implementation"])
warmup(list(est_cfgs), DEVICES)
planned = [(c.cell_id, name, d, "covbench_torch") for c in cells for name, e in est_cfgs.items() if not (e.tier == "C" and c.p > TIER_C_MAX_P) for d in (DEVICES if e.tier == "B" else ["cpu"])]
t_start = perf_counter()
for ci, cell in enumerate(cells):
    todo = [(name, d) for name, e in est_cfgs.items() if not (e.tier == "C" and cell.p > TIER_C_MAX_P) for d in (DEVICES if e.tier == "B" else ["cpu"])]
    if ck.all_done([(cell.cell_id, name, d, "covbench_torch") for name, d in todo]):
        continue
    X_np, Sigma, Omega = generate_cell(cell, SALT)
    for name, d in todo:
        if ck.is_done((cell.cell_id, name, d, "covbench_torch")): continue
        e = est_cfgs[name]; ck.add(timed_fit(name, e.strategy, dict(e.params), X_np, Sigma, Omega, d, cell, SALT))
    if ci % 5 == 0 or SMOKE:
        print(f"cell {ci+1}/{len(cells)} (p={cell.p}, n={cell.n})  {eta(t_start, ci + 1, len(cells))}")
df = ck.load(); print(df.status.value_counts()); rep = ck.report(planned); print("planned configurations:", rep)
S = {"environment": ENV, "hardware_seen": hardware_seen(df), "planned": rep, "tier_c_max_p": TIER_C_MAX_P, "spectra": "native for ar1 and banded, flat for the others", "by_p": {}}
for p, d in df.groupby("p"):
    menu = menu_for(int(p))
    S["by_p"][int(p)] = {"menu": menu, "groups": summarise_groups(d, ["cell_id", "device"], f"p={p}", menu), "pooled": summarise_groups(d, ["cell_id"], f"p={p} pooled", pooled_menu(menu))}
    med = d[d.status == "success"].groupby(["estimator_name", "device"]).fit_wall_time_s.median().unstack()
    S["by_p"][int(p)]["median_wall_clock"] = {str(k): {str(i): (None if pd.isna(x) else float(x)) for i, x in v.items()} for k, v in med.round(6).to_dict().items()}
    S["by_p"][int(p)]["gpu_speedup"] = paired_speedup(d)
    print(f"p={p}: Phi(groups)={S['by_p'][int(p)]['groups'].get('phi')}, Phi(pooled)={S['by_p'][int(p)]['pooled'].get('phi')}"); print(med.round(5))
import matplotlib.pyplot as plt
ps = sorted(S["by_p"]); fig, ax = plt.subplots(figsize=(5, 3))
ax.plot(ps, [S["by_p"][p]["groups"].get("phi", np.nan) for p in ps], "o-", label="cell x device groups"); ax.plot(ps, [S["by_p"][p]["pooled"].get("phi", np.nan) for p in ps], "s-", label="pooled cells")
ax.set_xscale("log"); ax.set_xlabel("p"); ax.set_ylabel("balanced flip rate"); ax.legend(); fig.savefig(OUT / "phi_vs_p.png", dpi=150, bbox_inches="tight"); plt.close(fig)
write_summary(S, OUT, 2)
return S
'''

# ---------------------------------------------------------------------------
# Block 3
# ---------------------------------------------------------------------------
B3_PARAMS = r'''
# @title Block 3 (paper: Notebook 3). The regression family: ridge / lasso / elastic net x {CD, ADMM, FISTA} x {CPU, GPU} x iteration caps
B3_REPLICATES = 5            # @param {type:"integer"}   # 120 cells; each configuration tunes its own lambda, so about 3 hours on a T4
B3_P_VALUES = [200, 1000]    # @param
B3_N_OVER_P = [0.5, 2.0]     # @param
'''
B3_BODY = r'''
REPLICATES, P_VALUES, N_OVER_P = B3_REPLICATES, list(B3_P_VALUES), list(B3_N_OVER_P)
ITER_CAPS = [20, 200, 2000]   # the fidelity axis s for the iterative implementations
SALT = "covbench_v2_regression"
if SMOKE:
    REPLICATES, P_VALUES, N_OVER_P, ITER_CAPS = 1, [30], [2.0], [5, 50]
OUT = block_out("block3_regression_family", {"replicates": REPLICATES, "p_values": P_VALUES, "n_over_p": N_OVER_P, "iter_caps": ITER_CAPS, "lambda_grid": LAMBDA_GRID, "salt": SALT, "smoke": SMOKE},
                tune_and_fit, _fit, prox_grad, admm, sklearn_cd, configs_for, scalarised_oracle, pareto_mask, supported_mask, complete_groups, run_block3)
from covbench.data import _STRUCTURE_BUILDERS, _project_spd

def make_reg_cell(structure, sp, p, n, dist, rep):
    """Design built on the release's covariance structures for X, sparse beta, Gaussian or t(3) noise, 2000 test rows."""
    key = make_cell_key(structure_id=structure, spectrum_id="flat", dist_id=dist, n=n, p=p, replicate_id=rep, structure_params=sp, spectrum_params={}, distribution_params={})
    cid = make_cell_id(key); rng = np.random.default_rng(derive_data_seed(key, SALT))
    Sigma = _project_spd(_STRUCTURE_BUILDERS[structure](p, rng, **sp)); Sigma *= p / np.trace(Sigma); L = np.linalg.cholesky(Sigma)
    beta = np.zeros(p); k = max(5, p // 20); beta[rng.choice(p, k, replace=False)] = rng.standard_normal(k) * 2.0
    Xtr = rng.standard_normal((n, p)) @ L.T; Xte = rng.standard_normal((2000, p)) @ L.T
    noise = (lambda m: rng.standard_t(3, m)) if dist == "t_dist" else (lambda m: rng.standard_normal(m))
    ytr = Xtr @ beta + noise(n); yte = Xte @ beta + noise(2000)
    return dict(cell_id=cid, cell_key=key, structure_family=structure, structure_params_json=json.dumps(sp, sort_keys=True), spectrum_type="flat", spectrum_params_json="{}",
                distribution=dist, distribution_params_json="{}", p=p, n=n, p_over_n=p / n, replicate_id=rep, Xtr=Xtr, ytr=ytr, Xte=Xte, yte=yte, beta=beta)

ck = Checkpoint(OUT / "results.parquet", ["cell_id", "estimator_name", "implementation", "device", "fidelity"])
structures = [("ar1", {"rho": 0.7}), ("block_diagonal", {"block_size": 10}), ("spiked", {"k_spikes": 10})]
if SMOKE: structures = structures[:1]
specs = [(s, sp, p, int(p * r), dist, rep) for s, sp in structures for p in P_VALUES for r in N_OVER_P for dist in ("gaussian", "t_dist") for rep in range(REPLICATES)]
print(len(specs), "regression cells")
warmup_regression(DEVICES)
cell_ids = [make_cell_id(make_cell_key(structure_id=s, spectrum_id="flat", dist_id=dist, n=n, p=p, replicate_id=rep, structure_params=sp, spectrum_params={}, distribution_params={})) for s, sp, p, n, dist, rep in specs]
planned = [(cid, est, impl, d, f"iters={it}") for cid in cell_ids for est, l1r in ESTIMATORS.items() for impl, d, it in configs_for(l1r, DEVICES, ITER_CAPS)]
by_cell = {}
for k in planned: by_cell.setdefault(k[0], []).append(k)
t_start = perf_counter()
for ci, spec in enumerate(specs):
    cid = cell_ids[ci]
    if ck.all_done(by_cell[cid]):
        continue
    cell = make_reg_cell(*spec)
    base_row = {k: cell[k] for k in ("cell_id", "cell_key", "structure_family", "structure_params_json", "spectrum_type", "spectrum_params_json", "distribution", "distribution_params_json", "p", "n", "p_over_n", "replicate_id")}
    base_row.update({k: ENV[k] for k in ENV_COLS})
    for est, l1r in ESTIMATORS.items():
        for impl, d, it in configs_for(l1r, DEVICES, ITER_CAPS):
            if ck.is_done((cid, est, impl, d, f"iters={it}")): continue
            row = dict(base_row, estimator_name=est, estimator_tier="C" if impl.startswith("sklearn") else "B", implementation=impl, device=d, fidelity=f"iters={it}", status="success", error_message="")
            try:
                b, lam, used, t_sel, t_fit, wall, wsum = tune_and_fit(impl, d, it, cell["Xtr"], cell["ytr"], l1r)
                row.update(lam=lam, fit_wall_time_s=wall, hyperparam_selection_time_s=t_sel, fit_only_time_s=t_fit, iterations=used,
                           test_mse=float(np.mean((cell["Xte"] @ b - cell["yte"]) ** 2)), coef_l2_error=float(np.linalg.norm(b - cell["beta"])),
                           support_f1=float(2 * np.sum((b != 0) & (cell["beta"] != 0)) / max(np.sum(b != 0) + np.sum(cell["beta"] != 0), 1)), **wsum)
                row["frobenius_loss"] = row["test_mse"]   # the loss the oracle uses for this family: held out prediction MSE
                if not np.isfinite(wall) or not np.isfinite(row["test_mse"]): row["status"] = "invalid_result"
            except Exception as e:
                row.update(status="numerical_fail", error_message=f"{type(e).__name__}: {str(e)[:200]}")
            ck.add(row)
    if ci % 4 == 0 or SMOKE: print(f"cell {ci+1}/{len(specs)}  {eta(t_start, ci + 1, len(specs))}")
df = ck.load(); print(df.status.value_counts()); rep = ck.report(planned); print("planned configurations:", rep)

# ---- does implementation or fidelity choice dominate estimator choice? decomposition of flips by axis, on complete cells ----
d = df[df.status == "success"].copy(); d["config"] = d.estimator_name + "/" + d.implementation + "/" + d.device + "/" + d.fidelity
CONFIG_MENU = sorted(f"{est}/{impl}/{dv}/iters={it}" for est, l1r in ESTIMATORS.items() for impl, dv, it in configs_for(l1r, DEVICES, ITER_CAPS))
d, n_seen, n_complete = complete_groups(d, ["cell_id"], CONFIG_MENU)
rows = []
for cid, g in d.groupby("cell_id"):
    E, T = g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy()
    ieo, ibal = scalarised_oracle(E, T, 1, 0), scalarised_oracle(E, T, .5, .5); a, b = g.iloc[ieo], g.iloc[ibal]
    par = pareto_mask(T, E); sup = supported_mask(T, E, par)
    rows.append(dict(cell_id=cid, design=design_key(g.iloc[[0]]).iloc[0], p=int(g.p.iloc[0]), flip=int(ieo != ibal), est_changed=int(a.estimator_name != b.estimator_name),
                     impl_changed=int(a.implementation != b.implementation), dev_changed=int(a.device != b.device), fid_changed=int(a.fidelity != b.fidelity),
                     n_pareto=int(par.sum()), n_unsupported=int(par.sum() - sup.sum()), time_saved_s=float(T[ieo] - T[ibal]), regret_rel=float((E[ibal] - E[ieo]) / E[ieo]),
                     eo_config=a.config, bal_config=b.config))
R = pd.DataFrame(rows); F = R[R.flip == 1] if len(R) else R
def _m(s): return float(s.mean()) if len(s) else None
# exclusive attribution: a flip is "X only" when X is the one axis that changed; the non exclusive rates are reported alongside
only = {ax: ((F[ax] == 1) & (F[[o for o in ("est_changed", "impl_changed", "dev_changed", "fid_changed") if o != ax]].sum(axis=1) == 0)) for ax in ("est_changed", "impl_changed", "dev_changed", "fid_changed")} if len(F) else {}
S = {"environment": ENV, "hardware_seen": hardware_seen(df), "planned": rep, "n_cells": int(len(R)), "n_cells_seen": n_seen, "configurations_per_cell": len(CONFIG_MENU), "menu": CONFIG_MENU,
     "phi_configuration": _m(R.flip) if len(R) else None, "phi_ci95": cluster_bootstrap(R.flip, R.design) if len(R) and R.design.nunique() > 1 else None,
     "share_of_flips_changing_estimator": _m(F.est_changed) if len(R) else None, "share_of_flips_changing_implementation": _m(F.impl_changed) if len(R) else None,
     "share_of_flips_changing_device": _m(F.dev_changed) if len(R) else None, "share_of_flips_changing_fidelity": _m(F.fid_changed) if len(R) else None,
     "share_of_flips_changing_estimator_only": _m(only["est_changed"]) if len(F) else None, "share_of_flips_changing_implementation_only": _m(only["impl_changed"]) if len(F) else None,
     "share_of_flips_changing_device_only": _m(only["dev_changed"]) if len(F) else None, "share_of_flips_changing_fidelity_only": _m(only["fid_changed"]) if len(F) else None,
     "share_of_flips_changing_several_axes": _m(F[["est_changed", "impl_changed", "dev_changed", "fid_changed"]].sum(axis=1) > 1) if len(F) else None,
     "mean_pareto": _m(R.n_pareto) if len(R) else None, "frac_cells_unsupported": _m(R.n_unsupported > 0) if len(R) else None,
     "median_time_saved_given_flip": float(F.time_saved_s.median()) if len(F) else None, "median_regret_given_flip": float(F.regret_rel.median()) if len(F) else None,
     "by_p": {int(p): float(g.flip.mean()) for p, g in R.groupby("p")} if len(R) else {},
     "top_transitions": {f"{a} -> {b}": int(v) for (a, b), v in F.groupby(["eo_config", "bal_config"]).size().sort_values(ascending=False).head(8).items()} if len(F) else {},
     "median_wall_clock_by_config": {"/".join(map(str, k)): float(v) for k, v in d.groupby(["estimator_name", "implementation", "device", "fidelity"]).fit_wall_time_s.median().items()},
     "median_selection_share_of_wall_clock": float((d.hyperparam_selection_time_s / d.fit_wall_time_s).median()) if len(d) else None}
print(json.dumps({k: v for k, v in S.items() if k not in ("environment", "median_wall_clock_by_config", "hardware_seen")}, indent=2, default=str))
write_summary(S, OUT, 3)
return S
'''

# ---------------------------------------------------------------------------
# Block 4
# ---------------------------------------------------------------------------
B4_PARAMS = r'''
# @title Block 4 (paper: Notebook 4). Downstream validity under a nested design: out of sample portfolio variance (covariance) and held out prediction loss (regression)
B4_TICKERS_N = 200   # @param {type:"integer"}   # 200 names gives p = 200 as in the release, p/n = 0.8 with a 250 day window; about 40 minutes on a T4 for the covariance block
B4_WINDOW = 250      # @param {type:"integer"}   # estimation window (trading days)
B4_HORIZON = 42      # @param {type:"integer"}   # evaluation window (trading days): the realised covariance of this window is the fit's loss target
'''
B4_BODY = r'''
TICKERS_N, WINDOW, HORIZON = B4_TICKERS_N, B4_WINDOW, B4_HORIZON
SALT = "covbench_v2_downstream"
if SMOKE: TICKERS_N, WINDOW, HORIZON = 30, 120, 30
MIN_PAST = 2 if SMOKE else 3
ITER_CAPS = [5, 50] if SMOKE else [20, 200, 2000]

# ---- covariance block: a frozen return panel shared by every accelerator. First run: a user supplied price file in Drive, else a download
# (yfinance, then stooq) of a fixed list of large cap US names; in a full run the synthetic fallback is used only when ALLOW_SYNTHETIC_DATA is
# ticked. The panel is saved to Drive with its sha256 and metadata; later runs on any runtime load the same file and verify it. ----
TICKER_LIST = ("AAPL ABBV ABT ACN ADBE ADI ADM ADP ADSK AEE AEP AFL AIG AKAM ALB ALGN ALL AMAT AMD AME AMGN AMP AMT AMZN AON APA APD APH APTV ARE ATO AVB AVGO AVY AWK AXP AZO "
               "BA BAC BAX BBY BDX BEN BIIB BK BKNG BLK BMY BRK-B BSX BXP C CAG CAH CAT CB CBOE CCI CCL CDNS CF CHD CHRW CHTR CI CINF CL CLX CMCSA CME CMG CMI CMS CNC CNP COF COO COP COST CPB CPT CRM CSCO CSX CTAS CTSH CVS CVX "
               "D DAL DE DG DGX DHI DHR DIS DLR DLTR DOV DRI DTE DUK DVN DXCM EA EBAY ECL ED EFX EIX EL ELV EMR EOG EQIX EQR ES ESS ETN ETR EW EXC EXPD EXPE EXR F FANG FAST FCX FDX FE FFIV FITB FRT "
               "GD GE GILD GIS GLW GM GOOGL GPC GPN GRMN GS GWW HAL HAS HBAN HCA HD HIG HLT HOLX HON HPQ HRL HSY HST HUM IBM ICE IDXX IFF ILMN INTC INTU IP IPG ISRG ITW IVZ JBHT JCI JNJ JPM "
               "KEY KIM KLAC KMB KMI KMX KO KR L LEN LH LLY LMT LNT LOW LRCX LUV LVS MA MAA MAR MAS MCD MCHP MCK MCO MDLZ MDT MET META MGM MKC MLM MMC MMM MNST MO MOH MOS MPC MPWR MRK MS MSCI MSFT MSI MTB MTD MU "
               "NDAQ NEE NEM NFLX NI NKE NOC NOW NRG NSC NTAP NTRS NUE NVDA NVR O ODFL OKE OMC ON ORCL ORLY OXY PAYX PCAR PEG PEP PFE PG PGR PH PHM PKG PLD PM PNC PNW POOL PPG PPL PRU PSA PSX "
               "QCOM RCL REG REGN RF RJF RL RMD ROK ROP ROST RSG RTX SBUX SCHW SHW SJM SLB SNPS SO SPG SPGI SRE STE STT STX STZ SWK SWKS SYK SYY T TAP TDG TEL TER TFC TGT TJX TMO TMUS TROW TRV TSCO TSLA TSN TT TTWO TXN TXT "
               "UAL UDR UHS ULTA UNH UNP UPS URI USB V VLO VMC VRSK VRTX VTR VZ WAT WDC WEC WELL WFC WM WMB WMT WRB WYNN XEL XOM XYL YUM ZION ZTS").split()
PANEL_START, PANEL_END = "2014-01-01", "2024-12-31"
PANEL_DIR = ROOT / "downstream" / MODE; PANEL_DIR.mkdir(parents=True, exist_ok=True)
PANEL, META = PANEL_DIR / "returns_panel.parquet", PANEL_DIR / "panel_meta.json"
USER_PRICES, USER_HOUSING = ROOT / "downstream" / "user_prices.csv", ROOT / "downstream" / "california_housing.csv"   # dropped in by hand, see make_downstream_data.py; used by both modes
MIN_ROWS = WINDOW + HORIZON * (MIN_PAST + 3)
MIN_PERIOD_ROWS = 2650   # trading days 2014 - 2024 are about 2,770; a panel that covers the period has at least this many
PERIOD_SLACK = pd.Timedelta(days=10)

def returns_from_prices(px, label):
    """Log returns of a price frame (dates by tickers) after validating it against the protocol: every column is a name of the fixed
    list (anything else is rejected, not dropped), the dates cover PANEL_START to PANEL_END (full runs), and exactly TICKERS_N names with
    a complete history are taken in list order. A panel that fails any check is rejected; a smaller panel is never silently accepted
    as the TICKERS_N asset experiment."""
    if not isinstance(px.index, pd.DatetimeIndex):
        px.index = pd.to_datetime(px.index, errors="coerce")
    px = px[~px.index.isna()].sort_index()
    unknown = [c for c in px.columns if c not in TICKER_LIST]
    if unknown:
        raise ValueError(f"{label}: {len(unknown)} column(s) are not names of the notebook's fixed list ({unknown[:5]}{' ...' if len(unknown) > 5 else ''}); the panel must consist of names from that list")
    if px.shape[0] == 0:
        raise ValueError(f"{label}: no price data came back (the source may be refusing requests from this runtime)")
    if not SMOKE:
        px = px.loc[PANEL_START:PANEL_END]
        first, last = px.index.min(), px.index.max()
        if first > pd.Timestamp(PANEL_START) + PERIOD_SLACK or last < pd.Timestamp(PANEL_END) - PERIOD_SLACK or px.shape[0] < MIN_PERIOD_ROWS:
            raise ValueError(f"{label}: the dates do not cover {PANEL_START} - {PANEL_END} ({str(first)[:10]} to {str(last)[:10]}, {px.shape[0]} trading days; at least {MIN_PERIOD_ROWS} are needed)")
    complete = px.dropna(axis=1, how="any")
    complete = complete.loc[:, [t for t in TICKER_LIST if t in complete.columns]]   # list order
    if complete.shape[1] < TICKERS_N:
        raise ValueError(f"{label}: only {complete.shape[1]} names have a complete history over the period and the configuration needs {TICKERS_N}; a smaller panel would be a different experiment and is not accepted")
    px = complete.iloc[:, :TICKERS_N]
    frame = np.log(px).diff().dropna()
    if frame.shape[0] < MIN_ROWS:
        raise ValueError(f"{label}: too few days for the walk forward design ({frame.shape[0]}; at least {MIN_ROWS} are needed)")
    return frame

def stooq_prices():
    """Daily closes from stooq's CSV endpoint, in list order, until TICKERS_N names with a complete history are in hand."""
    import io, requests
    cols, d1, d2 = {}, PANEL_START.replace("-", ""), PANEL_END.replace("-", "")
    for t in TICKER_LIST:
        try:
            r = requests.get(f"https://stooq.com/q/d/l/?s={t.lower()}.us&d1={d1}&d2={d2}&i=d", headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
            d_ = pd.read_csv(io.StringIO(r.text))
            if "Close" in d_ and len(d_) >= MIN_PERIOD_ROWS:
                c_ = d_.set_index(pd.to_datetime(d_["Date"]))["Close"].sort_index()
                if c_.index.min() <= pd.Timestamp(PANEL_START) + PERIOD_SLACK and c_.index.max() >= pd.Timestamp(PANEL_END) - PERIOD_SLACK and c_.notna().all(): cols[t] = c_
        except Exception:
            pass
        if len(cols) >= TICKERS_N: break
    return pd.DataFrame(cols)

def download_prices():
    """Adjusted close prices for TICKER_LIST: yfinance (three attempts), then stooq. Returns (log return frame, label)."""
    errors = {}
    for attempt in range(3):
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "yfinance"], check=False)
            import yfinance as yf
            px = yf.download(TICKER_LIST, start=PANEL_START, end=PANEL_END, auto_adjust=True, progress=False, threads=False)["Close"]
            if isinstance(px, pd.Series): px = px.to_frame()
            frame = returns_from_prices(px, "yfinance")
            return frame, f"yfinance, {frame.shape[1]} names from the notebook's fixed list, {frame.shape[0]} days {PANEL_START[:4]} - {PANEL_END[:4]}"
        except Exception as e:
            errors["yfinance"] = f"yfinance (3 attempts): {str(e)[:120]}"; time.sleep(20)
    try:
        frame = returns_from_prices(stooq_prices(), "stooq")
        return frame, f"stooq, {frame.shape[1]} names from the notebook's fixed list, {frame.shape[0]} days {PANEL_START[:4]} - {PANEL_END[:4]}"
    except Exception as e:
        errors["stooq"] = f"stooq: {str(e)[:120]}"
    raise RuntimeError(" | ".join(errors.values()))

def real_panel():
    """The real return panel: a user supplied price file in Drive first, else a download (full runs only). Returns (returns, tickers, label)."""
    if USER_PRICES.exists():
        frame = returns_from_prices(pd.read_csv(USER_PRICES, index_col=0, parse_dates=True), "user_prices.csv")
        return frame.to_numpy(), list(frame.columns), f"user supplied prices (user_prices.csv, sha256 {hashlib.sha256(USER_PRICES.read_bytes()).hexdigest()[:16]}), {frame.shape[1]} names from the notebook's fixed list, {frame.shape[0]} days {str(frame.index[0])[:10]} - {str(frame.index[-1])[:10]}"
    if SMOKE:
        raise RuntimeError("no download in smoke mode")
    frame, label = download_prices()
    return frame.to_numpy(), list(frame.columns), label

def freeze_panel(returns, tickers, data_source):
    pd.DataFrame(returns, columns=[str(t) for t in tickers]).to_parquet(PANEL, index=False)
    meta = {"data_source": data_source, "sha256": hashlib.sha256(PANEL.read_bytes()).hexdigest(), "tickers": [str(t) for t in tickers], "shape": list(returns.shape), "frozen_by": HW, "frozen_at": time.strftime("%Y-%m-%d %H:%M:%S"), "ticker_list": TICKER_LIST, "period": [PANEL_START, PANEL_END]}
    json.dump(meta, open(META, "w"), indent=2); print("panel frozen:", data_source, returns.shape)
    return meta

returns = None
if PANEL.exists():
    meta = json.load(open(META)); sha_now = hashlib.sha256(PANEL.read_bytes()).hexdigest()
    if sha_now != meta["sha256"]:
        raise SystemExit(f"the frozen panel {PANEL} does not match its recorded sha256 ({sha_now[:16]} vs {meta['sha256'][:16]}); it was altered or corrupted. Delete {PANEL_DIR} to rebuild it.")
    returns = pd.read_parquet(PANEL).to_numpy(); data_source = meta["data_source"]
    assert list(returns.shape) == list(meta["shape"]), "frozen panel shape does not match its metadata"
    if returns.shape[1] != TICKERS_N or (not data_source.startswith("synthetic") and any(t not in TICKER_LIST for t in meta.get("tickers", []))):
        raise SystemExit(f"the frozen panel in {PANEL_DIR} has {returns.shape[1]} names and this configuration needs {TICKERS_N} from the fixed list; it was frozen under another configuration. Delete {PANEL_DIR} (or restore B4_TICKERS_N) and run again.")
    print("frozen panel loaded and verified:", data_source, returns.shape, "sha256", meta["sha256"][:16])
    if data_source.startswith("synthetic") and not ALLOW_SYNTHETIC_DATA:
        # a synthetic panel frozen earlier (by a previous notebook version, or under ALLOW_SYNTHETIC_DATA) is replaced as soon as real data can be had
        try:
            returns, tickers, data_source = real_panel()
            archive = PANEL_DIR.with_name(f"{MODE}_synthetic_{time.strftime('%Y%m%d_%H%M%S')}"); shutil.move(str(PANEL_DIR), str(archive)); PANEL_DIR.mkdir(parents=True)
            print(f"the frozen synthetic panel was moved to {archive} and replaced by real data; the block 4 results computed on it are superseded")
            meta = freeze_panel(returns, tickers, data_source)
        except Exception as e:
            if not SMOKE:
                raise SystemExit(f"the frozen panel in {PANEL_DIR} is the synthetic fallback (frozen by {meta.get('frozen_by')} at {meta.get('frozen_at')}) and no real data could be had to replace it ({str(e)[:300]}). Run make_downstream_data.py on your own computer and put user_prices.csv in {USER_PRICES.parent}, then run block 4 again; or tick ALLOW_SYNTHETIC_DATA to keep the synthetic panel.")
            print("smoke test on the frozen synthetic panel")
else:
    try:
        returns, tickers, data_source = real_panel()
    except Exception as e:
        if not SMOKE and not ALLOW_SYNTHETIC_DATA:
            raise SystemExit(f"real return data unavailable ({str(e)[:300]}). Nothing was frozen. Run block 4 again later (Yahoo Finance refuses Colab at times), or run make_downstream_data.py on your own computer and put user_prices.csv in {USER_PRICES.parent}, then run block 4 again; or tick ALLOW_SYNTHETIC_DATA to run block 4 on the labelled synthetic fallback.")
        if not SMOKE: print("real data unavailable, using the synthetic factor model because ALLOW_SYNTHETIC_DATA is ticked:", str(e)[:200])
        rng = np.random.default_rng(derive_data_seed("downstream_fallback", SALT)); p, Tn, k = TICKERS_N, (900 if SMOKE else 2700), 5
        Bf = rng.standard_normal((p, k)) * 0.02; f = rng.standard_normal((Tn, k)) * 0.01; idio = rng.standard_normal((Tn, p)) * 0.015
        vol = np.exp(np.cumsum(rng.standard_normal(Tn) * 0.03)); vol = vol / vol.mean()   # slowly varying volatility: non stationarity
        returns = (f @ Bf.T + idio) * vol[:, None]; tickers = [f"synthetic_{i}" for i in range(p)]; data_source = "synthetic_factor_model"
    meta = freeze_panel(returns, tickers, data_source)
Tn, p = returns.shape
starts = list(range(0, Tn - WINDOW - HORIZON, HORIZON))
if SMOKE: starts = starts[:5]
cfg = load_config(RELEASED_CONFIG); est_cfgs = {e.name: e for e in cfg.estimators}
MENU = {"cpu": [e.name for e in cfg.estimators]} | ({"cuda": [e.name for e in cfg.estimators if e.tier == "B"]} if HAS_CUDA else {})
OUT = block_out("block4_downstream_validity", {"tickers_n": TICKERS_N, "window": WINDOW, "horizon": HORIZON, "min_past": MIN_PAST, "iter_caps": ITER_CAPS, "lambda_grid": LAMBDA_GRID, "panel_sha256": meta["sha256"], "data_source": data_source, "salt": SALT, "menu": MENU, "smoke": SMOKE},
                timed_fit, tune_and_fit, _fit, rule_pick, budget_choice, scalarised_oracle, pareto_mask, complete_groups, run_block4)
ck = Checkpoint(OUT / "results_covariance.parquet", ["window_start", "estimator_name", "device"])
warmup(list(est_cfgs), DEVICES)
def min_var_weights(Sh):
    Shr = Sh + 1e-6 * np.trace(Sh) / Sh.shape[0] * np.eye(Sh.shape[0]); w = np.linalg.solve(Shr, np.ones(Sh.shape[0])); return w / w.sum()
planned = [(s0, name, d) for s0 in starts for name, e in est_cfgs.items() for d in (DEVICES if e.tier == "B" else ["cpu"])]
by_window = {}
for k in planned: by_window.setdefault(k[0], []).append(k)
t_start = perf_counter()
for wi, s0 in enumerate(starts):
    if ck.all_done(by_window[s0]):
        continue
    Xw = returns[s0:s0 + WINDOW]; Xw = Xw - Xw.mean(0); Xf = returns[s0 + WINDOW:s0 + WINDOW + HORIZON]; Sf = np.cov(Xf, rowvar=False)
    cell = CellSpec(cell_id=f"w{s0}", cell_key=f"window{s0}", structure_id="real", structure_params={}, spectrum_id="", spectrum_params={}, distribution_id=data_source[:24], distribution_params={},
                    n=WINDOW, p=p, p_over_n=p / WINDOW, replicate_id=0, split="train")
    for name, e in est_cfgs.items():
        for d in (DEVICES if e.tier == "B" else ["cpu"]):
            if ck.is_done((s0, name, d)): continue
            row = timed_fit(name, e.strategy, dict(e.params), Xw, Sf, np.linalg.pinv(Sf), d, cell, SALT, keep_sigma=True)
            row.update(window_start=s0); Sh = row.pop("_sigma_hat", None)
            if row["status"] == "success" and Sh is not None:
                w = min_var_weights(Sh); row["oos_portfolio_variance"] = float(w @ Sf @ w); row["oos_var_annualised"] = float(w @ Sf @ w * 252)
                row["max_abs_weight"] = float(np.abs(w).max()); row["gross_leverage"] = float(np.abs(w).sum())   # an ill conditioned estimate shows up here
            ck.add(row)
    if wi % 10 == 0 or SMOKE: print(f"window {wi+1}/{len(starts)}  {eta(t_start, wi + 1, len(starts))}")
dfc = ck.load(); print(dfc.status.value_counts()); rep_c = ck.report(planned); print("planned configurations:", rep_c)

# ---- walk forward evaluation. For every window after the first few, each rule is chosen by majority over the windows that precede it
# (their evaluation period ends before this window's evaluation period starts), then judged on this window's out of sample variance.
# Nothing later than the evaluation window informs the choice. The error a rule sees is the downstream loss itself, the realised out of
# sample portfolio variance of each estimator on the past windows: real data has no true covariance, and the Frobenius distance to the next
# horizon's realised covariance (a rank deficient matrix) favours estimates with little mass in the bulk, whose inverses, and so whose
# portfolios, are unusable; that proxy is kept as a secondary comparison under rules_frobenius_proxy. The budget B applies to the runtimes
# the rule saw on the selection windows; whether the deployed fit on the evaluation window also met B is recorded. ----
d = dfc[dfc.status == "success"].copy(); d, _, _ = complete_groups(d, ["window_start", "device"], MENU)
S = {"environment": ENV, "hardware_seen": hardware_seen(dfc), "planned": {"covariance": rep_c}, "data_source": data_source, "panel_sha256": meta["sha256"], "n_assets": int(p), "n_days": int(Tn), "n_windows": len(starts), "min_past_windows": MIN_PAST,
     "selection_error": "oos_var_annualised (realised out of sample portfolio variance on the past windows)", "rules": {}, "rules_frobenius_proxy": {}}
def rules_table(err_col):
    out = {}
    for dev, dd in d.groupby("device"):
        per_window = {s0: g for s0, g in dd.groupby("window_start")}
        for rule, B in RULES.items():
            rows = []; infeasible = 0
            for s0 in sorted(per_window):
                past = [w for w in per_window if w <= s0 - HORIZON]
                if len(past) < MIN_PAST: continue
                picks = []
                for w in past:
                    g = per_window[w]; i = rule_pick(g[err_col].to_numpy(), g.fit_wall_time_s.to_numpy(), rule, B)
                    if i is not None: picks.append(g.estimator_name.to_numpy()[i])
                if not picks: infeasible += 1; continue
                choice = Counter(picks).most_common(1)[0][0]; e = per_window[s0][per_window[s0].estimator_name == choice]
                if not len(e): continue
                t = float(e.fit_wall_time_s.iloc[0])
                rows.append({"window": s0, "estimator": choice, "oos_var": float(e.oos_var_annualised.iloc[0]), "fit_time": t, "within_budget": int(B is None or t <= B),
                             "max_abs_weight": float(e.max_abs_weight.iloc[0]) if "max_abs_weight" in e else np.nan})
            if rows:
                R = pd.DataFrame(rows)
                out[f"{dev}/{rule}"] = {"n_eval_windows": int(len(R)), "n_infeasible_windows": infeasible, "mean_oos_variance_annualised": float(R.oos_var.mean()), "median_oos_variance_annualised": float(R.oos_var.median()),
                                       "mean_fit_wall_time_s": float(R.fit_time.mean()), "deployed_within_budget": float(R.within_budget.mean()) if B is not None else None, "median_max_abs_weight": float(R.max_abs_weight.median()),
                                       "estimator": R.estimator.mode().iloc[0], "estimator_frequency": {str(k): float(v) for k, v in R.estimator.value_counts(normalize=True).round(3).items()}}
            elif infeasible:
                out[f"{dev}/{rule}"] = {"n_eval_windows": 0, "n_infeasible_windows": infeasible}
    return out
S["rules"] = rules_table("oos_var_annualised")
S["rules_frobenius_proxy"] = rules_table("frobenius_loss")
best = d.loc[d.groupby(["window_start", "device"]).oos_var_annualised.idxmin()]   # per window oracle: lowest realised out of sample variance
S["oracle_oos_variance_annualised_by_device"] = {str(k): float(v) for k, v in best.groupby("device").oos_var_annualised.mean().items()}
S["estimator_oos_variance_annualised_by_device"] = {f"{k[0]}/{k[1]}": float(v) for k, v in d.groupby(["estimator_name", "device"]).oos_var_annualised.mean().items()}
S["estimator_median_max_abs_weight"] = {str(k): float(v) for k, v in d.groupby("estimator_name").max_abs_weight.median().items()} if "max_abs_weight" in d else {}
S["oracle_estimator_frequency"] = {str(k): float(v) for k, v in best.estimator_name.value_counts(normalize=True).round(3).items()}
print("rules selecting on the realised out of sample variance of past windows:"); print(pd.DataFrame(S["rules"]).T.to_string())
print("the same rules selecting on the Frobenius distance to the next horizon's realised covariance (proxy, for comparison):"); print(pd.DataFrame(S["rules_frobenius_proxy"]).T[["mean_oos_variance_annualised", "estimator"]].to_string() if S["rules_frobenius_proxy"] else "n/a")
print("mean OOS variance by estimator/device:", {k: round(v, 4) for k, v in S["estimator_oos_variance_annualised_by_device"].items()}); print("median max |weight| by estimator:", {k: round(v, 3) for k, v in S["estimator_median_max_abs_weight"].items()})
print("oracle OOS variance by device:", S["oracle_oos_variance_annualised_by_device"])
write_summary(S, OUT, 4, status="partial")   # the regression block follows; the summary is final only after it

# ---- regression block: nested five fold design on California housing with cubic features (synthetic fallback). Preprocessing is fit on the
# training part of each split only; each configuration tunes its own lambda on its training part; the outer test fold is touched once. ----
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.model_selection import KFold
reg_source = "synthetic"; Xraw = None
def housing_mirror():
    """California housing from the handson-ml2 repository on GitHub (the StatLib file with 207 total_bedrooms values removed by its author):
    the rows with complete bedrooms, converted to scikit-learn's features (MedInc, HouseAge, AveRooms, AveBedrms, Population, AveOccup, Latitude, Longitude; target in 100k USD)."""
    h = pd.read_csv("https://raw.githubusercontent.com/ageron/handson-ml2/master/datasets/housing/housing.csv").dropna()
    X = np.column_stack([h.median_income, h.housing_median_age, h.total_rooms / h.households, h.total_bedrooms / h.households, h.population, h.population / h.households, h.latitude, h.longitude]).astype(np.float64)
    return X, (h.median_house_value / 100000.0).to_numpy(dtype=np.float64), f"california_housing_cubic_features (handson-ml2 mirror on GitHub, {len(h)} rows with complete bedrooms)"
if USER_HOUSING.exists():
    h = pd.read_csv(USER_HOUSING); yraw = h.pop("MedHouseVal").to_numpy(dtype=np.float64); Xraw = h.to_numpy(dtype=np.float64)
    reg_source = f"california_housing_cubic_features (user supplied california_housing.csv, sha256 {hashlib.sha256(USER_HOUSING.read_bytes()).hexdigest()[:16]})"
elif not SMOKE:
    errs = []
    try:
        from sklearn.datasets import fetch_california_housing
        Xraw, yraw = fetch_california_housing(return_X_y=True); reg_source = "california_housing_cubic_features"
    except Exception as e:
        errs.append(f"scikit-learn download: {str(e)[:100]}")
        try:
            Xraw, yraw, reg_source = housing_mirror()
        except Exception as e2:
            errs.append(f"GitHub mirror: {str(e2)[:100]}")
    if Xraw is None:
        if not ALLOW_SYNTHETIC_DATA:
            raise SystemExit(f"California housing unavailable ({' | '.join(errs)}). Run block 4 again later, or run make_downstream_data.py on your own computer and put california_housing.csv in {USER_HOUSING.parent}, then run block 4 again; or tick ALLOW_SYNTHETIC_DATA to run the regression block on the synthetic fallback. The covariance block's rows are kept.")
        print("real data unavailable, synthetic fallback because ALLOW_SYNTHETIC_DATA is ticked:", " | ".join(errs))
if Xraw is None:
    rng = np.random.default_rng(1); m_, p_ = (1500, 8) if SMOKE else (20000, 8)
    Xraw = rng.standard_normal((m_, p_)); Xraw[:, 0] += 2; b = rng.standard_normal(p_); yraw = (Xraw @ b) ** 2 / 10 + Xraw @ b + rng.standard_normal(m_)
Xpoly = PolynomialFeatures(3, include_bias=False).fit_transform(Xraw)   # stateless feature map; scaling is fit per split below
print(reg_source, Xpoly.shape)
def prep(Xa, ya, Xb, yb):
    sc = StandardScaler().fit(Xa); mu, sd = ya.mean(), ya.std()
    return sc.transform(Xa), (ya - mu) / sd, sc.transform(Xb), (yb - mu) / sd
warmup_regression(DEVICES)
ck_r = Checkpoint(OUT / "results_regression.parquet", ["fold", "role", "estimator_name", "implementation", "device", "fidelity"])
outer = KFold(5, shuffle=True, random_state=0)
planned_r = [(fold, role, est, impl, dev, f"iters={it}") for fold in range(2 if SMOKE else 5) for role in ("select", "eval") for est, l1r in ESTIMATORS.items() for impl, dev, it in configs_for(l1r, DEVICES, ITER_CAPS)]
by_fold = {}
for k in planned_r: by_fold.setdefault(k[0], []).append(k)
for fold, (tr, te) in enumerate(outer.split(Xpoly)):
    if SMOKE and fold >= 2: break
    if ck_r.all_done(by_fold[fold]): continue
    Xtr, ytr, Xte, yte = Xpoly[tr], yraw[tr], Xpoly[te], yraw[te]; half = len(tr) // 2
    splits = {"select": prep(Xtr[:half], ytr[:half], Xtr[half:], ytr[half:]), "eval": prep(Xtr, ytr, Xte, yte)}
    for est, l1r in ESTIMATORS.items():
        for impl, dev, it in configs_for(l1r, DEVICES, ITER_CAPS):
            for role, (Xa, ya, Xb, yb) in splits.items():
                key = (fold, role, est, impl, dev, f"iters={it}")
                if ck_r.is_done(key): continue
                row = dict(fold=fold, role=role, estimator_name=est, implementation=impl, device=dev, fidelity=f"iters={it}", status="success", error_message="", **{k: ENV[k] for k in ENV_COLS})
                try:
                    b, lam, used, t_sel, t_fit, wall, wsum = tune_and_fit(impl, dev, it, Xa, ya, l1r)
                    row.update(lam=lam, fit_wall_time_s=wall, hyperparam_selection_time_s=t_sel, fit_only_time_s=t_fit, iterations=used, holdout_mse=float(np.mean((Xb @ b - yb) ** 2)), **wsum)
                    row["frobenius_loss"] = row["holdout_mse"]
                except Exception as e:
                    row.update(status="numerical_fail", error_message=f"{type(e).__name__}: {str(e)[:200]}")
                ck_r.add(row)
    print(f"fold {fold+1} done")
dfr = ck_r.load(); print(dfr.status.value_counts()); rep_r = ck_r.report(planned_r); print("planned configurations:", rep_r)
# nested evaluation on complete folds only: the rule picks a configuration on the selection split (its runtimes are what the budget applies to),
# the evaluation split reports the held out loss and the runtime of that configuration on the full training fold, and whether that runtime met B
d = dfr[dfr.status == "success"].copy(); d["config"] = d.estimator_name + "/" + d.implementation + "/" + d.device + "/" + d.fidelity
CONFIG_MENU = sorted(f"{est}/{impl}/{dv}/iters={it}" for est, l1r in ESTIMATORS.items() for impl, dv, it in configs_for(l1r, DEVICES, ITER_CAPS))
d, _, _ = complete_groups(d, ["fold", "role"], CONFIG_MENU)
res = {}
for rule, B in RULES.items():
    losses, times, picks, within, infeasible = [], [], [], [], 0
    for fold, g in d[d.role == "select"].groupby("fold"):
        i = rule_pick(g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy(), rule, B)
        if i is None: infeasible += 1; continue
        pick = g.config.to_numpy()[i]; e = d[(d.role == "eval") & (d.fold == fold) & (d.config == pick)]
        if len(e): losses.append(float(e.holdout_mse.iloc[0])); times.append(float(e.fit_wall_time_s.iloc[0])); picks.append(pick); within.append(int(B is None or times[-1] <= B))
    res[rule] = {"n_folds": len(losses), "n_infeasible_folds": infeasible, "mean_holdout_mse": float(np.mean(losses)) if losses else None, "mean_fit_wall_time_s": float(np.mean(times)) if times else None,
                 "deployed_within_budget": float(np.mean(within)) if within and B is not None else None, "picks": picks}
best_eval = float(d[d.role == "eval"].groupby("fold").holdout_mse.min().mean()) if len(d) else None
S["planned"]["regression"] = rep_r
S["regression"] = {"regression_source": reg_source, "n_features": int(Xpoly.shape[1]), "n_rows": int(Xpoly.shape[0]), "menu": CONFIG_MENU, "rules": res, "oracle_mean_holdout_mse": best_eval}
print(pd.DataFrame({k: {kk: vv for kk, vv in v.items() if kk != "picks"} for k, v in res.items()}).T.to_string()); print("oracle mean held out MSE:", best_eval)
write_summary(S, OUT, 4, status="complete")
return S
'''

# ---------------------------------------------------------------------------
# Block 5
# ---------------------------------------------------------------------------
B5_PARAMS = r'''
# @title Block 5. The hardware matrix: every runtime this notebook has been run on, side by side with the MI300A release (runs automatically after the selected blocks)
'''
B5_BODY = r'''
OUT = ROOT / "block5_hardware_matrix" / MODE; OUT.mkdir(parents=True, exist_ok=True)

def planned_reports(summ):
    """The planned reports of a summary as a dict name -> report (a block with one report is keyed 'all')."""
    rep = summ.get("planned", {}) or {}
    return {"all": rep} if "n_planned" in rep else {str(k): v for k, v in rep.items() if isinstance(v, dict)}

REQUIRED_REPORTS = {"block1_covariance_nvidia": ("covariance", "matrix_audit"), "block4_downstream_validity": ("covariance", "regression")}

# the results file and key columns behind each planned report of each block, so that a summary can be checked against the rows it describes
REPORT_FILES = {"block1_covariance_nvidia": {"covariance": ("results.parquet", ["cell_id", "estimator_name", "device", "implementation"]), "matrix_audit": ("matrix_audit.parquet", ["cell_id", "estimator_name"])},
                "block2_dimension_sweep": {"all": ("results.parquet", ["cell_id", "estimator_name", "device", "implementation"])},
                "block3_regression_family": {"all": ("results.parquet", ["cell_id", "estimator_name", "implementation", "device", "fidelity"])},
                "block4_downstream_validity": {"covariance": ("results_covariance.parquet", ["window_start", "estimator_name", "device"]), "regression": ("results_regression.parquet", ["fold", "role", "estimator_name", "implementation", "device", "fidelity"])}}

def results_verified(folder, summ, block):
    """True when every planned report's results file exists, reads, and holds as many distinct successful keys as the report claims; a
    summary that describes rows which are not in the folder does not pass."""
    for name, rep in planned_reports(summ).items():
        if rep.get("applicable") is False and rep.get("n_planned", 0) == 0: continue   # a report of a block that does not apply on this runtime (the matrix audit on a CPU run)
        fn, keys = REPORT_FILES.get(block, {}).get(name, ("results.parquet", None))
        f = Path(folder) / fn
        try:
            d = pd.read_parquet(f)
        except Exception:
            return False
        if "status" not in d or any(k not in d for k in (keys or [])): return False
        ok = d[d.status == "success"]; n_ok = len(ok.drop_duplicates(keys)) if keys else len(ok)
        if n_ok < int(rep.get("n_success", 0)): return False
    return True

def hashes_consistent(folder, block):
    """True when every cell's successful rows, across every results file of the folder, carry one (sigma_sha256, data_sha256) pair. Files
    without hash columns (blocks that do not record them) pass; a block 1 folder from before the hashes existed does not."""
    files = [Path(folder) / fn for fn, _ in REPORT_FILES.get(block, {}).values()]
    versions = {}; seen_hash_cols = False
    for f in files:
        if not f.exists(): continue
        try:
            d = pd.read_parquet(f)
        except Exception:
            return False
        if "data_sha256" not in d or "sigma_sha256" not in d or "cell_id" not in d: continue
        seen_hash_cols = True
        ok = d[(d.status == "success")].dropna(subset=["data_sha256"])
        for cid, g in ok.groupby("cell_id"):
            versions.setdefault(str(cid), set()).update(zip(g.sigma_sha256.astype(str), g.data_sha256.astype(str)))
    if block == "block1_covariance_nvidia" and not seen_hash_cols: return False
    return all(len(v) == 1 for v in versions.values())

def run_gate(summ, block, folder=None):
    """The quality gate of one run, from its summary and, when the folder is given, its results files: every planned report present and
    complete (block 1 must carry its matrix audit report, so a summary from before the audit existed is never complete), results files that
    exist and hold the rows the summary claims, one software stack, the audited release code, and a complete summary. The same gate chooses
    the folder per accelerator and decides whether the run enters a table."""
    reps = planned_reports(summ); hs = summ.get("hardware_seen", {}) or {}
    q = {"complete": bool(reps) and all(r.get("complete") for r in reps.values()) and all(k in reps for k in REQUIRED_REPORTS.get(block, ())),
         "mixed_stacks": bool(hs.get("mixed_stacks")), "code_verified": hs.get("code_hash") == [EXPECTED_PKG_HASH[:16]], "summary_status": summ.get("status")}
    if block == "block1_covariance_nvidia":
        ma = reps.get("matrix_audit")
        q["matrix_audit_complete"] = bool(ma.get("complete")) if ma is not None else False   # absent (a run from before the audit existed) counts as incomplete
        q["matrix_audit_applicable"] = bool(ma.get("applicable")) if ma is not None else None
    if folder is not None:
        q["results_verified"] = results_verified(folder, summ, block)
        q["hashes_consistent"] = hashes_consistent(folder, block)
    q["usable"] = (q["complete"] and not q["mixed_stacks"] and q["code_verified"] and q["summary_status"] == "complete" and q.get("matrix_audit_complete", True)
                   and q.get("results_verified", True) and q.get("hashes_consistent", True))
    return q

def gate_reasons(q):
    """Why a run is excluded from the tables, in the same words the ingestion script uses."""
    if q.get("summary_status") is None and not q.get("complete", False):
        return "no summary yet (run in progress or interrupted before its first summary)"
    r = []
    if not q.get("complete", False): r.append("incomplete planned set")
    if q.get("matrix_audit_complete") is False: r.append("matrix audit incomplete or missing")
    if q.get("mixed_stacks"): r.append("mixed software stacks")
    if q.get("code_verified") is False: r.append("unverified code")
    if q.get("results_verified") is False: r.append("results file missing or short of the summary")
    if q.get("hashes_consistent") is False: r.append("inconsistent data hashes across rows or files")
    if q.get("summary_status") not in ("complete", "release", None): r.append(f"summary {q.get('summary_status')}")
    return ", ".join(r) or "excluded"

def latest_protocol(block):
    """One results folder per accelerator for a block: the most recently written protocol folder that passes the quality gate; if none
    passes, the most recent folder, flagged. Other folders are listed as superseded, each with its gate verdict."""
    found = {}
    for man in sorted(ROOT.glob(f"{block}/*/{MODE}/*/manifest.json")):
        hw = man.parent.parent.parent.name; m = json.load(open(man)); stamp = m.get("last_resumed") or m.get("created", "")
        sj = man.parent / "summary.json"; summ = json.load(open(sj)) if sj.exists() else {}
        q = run_gate(summ, block, man.parent)
        found.setdefault(hw, []).append((q["usable"], stamp, man.parent, q))
    chosen, superseded = {}, {}
    for hw, lst in found.items():
        lst.sort(key=lambda t: (t[0], t[1]), reverse=True)   # usable first, then most recent
        chosen[hw] = lst[0][2]; superseded[hw] = [f"{t[2].name} ({'usable' if t[0] else 'excluded: ' + gate_reasons(t[3])})" for t in lst[1:]]
        if not lst[0][0]: print(f"NOTE: no {block} run for {hw} passes the quality gate; using the most recent folder {lst[0][2].name} ({gate_reasons(lst[0][3])}), which the gate excludes")
    return chosen, superseded

def load_summary(folder):
    sj = folder / "summary.json"
    return json.load(open(sj)) if sj.exists() else None

runs, meta, menus, quality = {}, {}, {}, {}
b1_dirs, b1_superseded = latest_protocol("block1_covariance_nvidia")
for hw, folder in b1_dirs.items():
    pq = folder / "results.parquet"; summ = load_summary(folder)
    if not pq.exists() or summ is None or "menu" not in summ: continue
    d = pd.read_parquet(pq); d = d[(d.implementation == "covbench_torch") & (d.status == "success")].copy()
    if not len(d): continue
    runs[hw] = d; meta[hw] = hardware_seen(d); menus[hw] = summ["menu"]
    quality[hw] = run_gate(summ, "block1_covariance_nvidia", folder) | {"planned": summ.get("planned", {}), "protocol_id": folder.name, "superseded_protocols": b1_superseded.get(hw, [])}
    # the rows themselves must agree with the summary on the stack and the code hash
    quality[hw]["code_verified"] = quality[hw]["code_verified"] and meta[hw].get("code_hash") == [EXPECTED_PKG_HASH[:16]]
    quality[hw]["mixed_stacks"] = quality[hw]["mixed_stacks"] or bool(meta[hw].get("mixed_stacks"))
    quality[hw]["usable"] = quality[hw]["usable"] and quality[hw]["code_verified"] and not quality[hw]["mixed_stacks"]
rel = None
if RELEASED_PARQUET.exists():
    rel = pd.read_parquet(RELEASED_PARQUET); rel = rel[rel.status == "success"].copy()
    if "cpu_model" not in rel: rel["cpu_model"] = rel["hardware_id"].astype(str) if "hardware_id" in rel else "mi300a_node"
    runs["amd_mi300a_release"] = rel; meta["amd_mi300a_release"] = hardware_seen(rel) | {"released_parquet_sha256": PARQUET_SHA}; menus["amd_mi300a_release"] = RELEASE_MENU
    quality["amd_mi300a_release"] = {"complete": True, "mixed_stacks": False, "code_verified": PARQUET_SHA == EXPECTED_PARQUET_SHA256, "summary_status": "release", "usable": PARQUET_SHA == EXPECTED_PARQUET_SHA256,
                                     "note": "the release has 107 incomplete cells (CUDA requested but not available); complete groups only enter the rates, as in the paper"}
print("hardware configurations found:", {hw: ("usable" if q["usable"] else "EXCLUDED: " + gate_reasons(q)) for hw, q in quality.items()})
if not runs:
    print("nothing to assemble yet"); return {}

def oracle_tables(d, menu):
    """complete (cell, device) groups -> (error only estimator, balanced estimator, design point); complete pooled cells -> (eo configuration, balanced configuration, design point)."""
    G, P = {}, {}
    dg, _, _ = complete_groups(d, ["cell_id", "device"], menu)
    for key, g in dg.groupby(["cell_id", "device"]):
        E, T = g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy(); nm = g.estimator_name.to_numpy()
        G[key] = (nm[scalarised_oracle(E, T, 1, 0)], nm[scalarised_oracle(E, T, .5, .5)], design_key(g.iloc[[0]]).iloc[0])
    dp, _, _ = complete_groups(d, ["cell_id"], pooled_menu(menu))
    for cid, g in dp.groupby("cell_id"):
        E, T = g.frobenius_loss.to_numpy(), g.fit_wall_time_s.to_numpy(); cf = (g.estimator_name + "/" + g.device).to_numpy()
        P[cid] = (cf[scalarised_oracle(E, T, 1, 0)], cf[scalarised_oracle(E, T, .5, .5)], design_key(g.iloc[[0]]).iloc[0])
    return G, P
tables = {hw: oracle_tables(d, menus[hw]) for hw, d in runs.items()}

S = {"environment_this_session": ENV, "hardware": {}, "pairwise": {}, "across_all": {}, "quality": quality}
for hw, d in runs.items():
    m = menus[hw]
    row = {"meta": meta[hw], "menu": m, "quality": quality[hw], "n_cells": int(d.cell_id.nunique()),
           "groups": summarise_groups(d, ["cell_id", "device"], hw, m), "cpu_groups": summarise_groups(d[d.device == "cpu"], ["cell_id", "device"], hw + " cpu", m),
           "gpu_groups": summarise_groups(d[d.device == "cuda"], ["cell_id", "device"], hw + " gpu", m), "pooled": summarise_groups(d, ["cell_id"], hw + " pooled", pooled_menu(m))}
    med = d.groupby(["estimator_name", "device"]).fit_wall_time_s.median().unstack()
    row["median_wall_clock"] = {str(k): {str(i): (None if pd.isna(x) else float(x)) for i, x in v.items()} for k, v in med.round(6).to_dict().items()}
    row["gpu_speedup"] = paired_speedup(d)
    if hw != "amd_mi300a_release":
        b1 = load_summary(b1_dirs[hw]) if hw in b1_dirs else None
        if b1 and b1.get("matrix_audit"): row["matrix_audit"] = b1["matrix_audit"]
    if meta[hw].get("mixed_stacks"):   # a run resumed under a changed stack: report the flip rate per stack so the mixture is visible
        row["phi_by_stack"] = {str(st): summarise_groups(ds, ["cell_id", "device"], f"{hw} stack {st}", m, boot=False).get("phi") for st, ds in d.groupby("stack_id")}
    S["hardware"][hw] = row
    ci = row["groups"].get("phi_ci95", {})
    print(f"{hw}: {row['n_cells']} cells, Phi={row['groups'].get('phi')} [{ci.get('ci95_lo')}, {ci.get('ci95_hi')}], Phi_gpu={row['gpu_groups'].get('phi')}, cpu->gpu={row['pooled'].get('cpu_to_gpu')}, gpu->cpu={row['pooled'].get('gpu_to_cpu')}, menu {m}")

usable = [h for h in runs if quality[h]["usable"]]
# data identity across runs, certified per cell: the sample covariance on the CPU is deterministic in the data, so two runs whose losses
# agree to 1e-9 on a cell computed on the same data. Cells whose covariance depends on the eigensolver build (block 1 records this) differ
# between hosts with different LAPACK kernels, and every agreement figure is restricted to cells certified identical for the runs compared.
# between notebook runs the test is exact: every row carries the sha256 of its X and Sigma, and a cell is identical when both hashes agree.
# Against the release, whose rows carry no hash, a cell counts when the run's rows record agreement with the release's statistics and the
# sample covariance loss (block 1's statistic agreement, stated as such).
STAT_COLS = ["feat_kurtosis_mean", "feat_kurtosis_max", "feat_kurtosis_p95", "feat_skewness_mean", "feat_outlier_fraction", "feat_sample_cond", "feat_sample_effective_rank", "feat_sample_stable_rank",
             "feat_spectral_entropy", "feat_top_eig_gap_ratio", "feat_max_eigval_to_trace", "feat_off_diag_mag_p50", "feat_off_diag_mag_p95", "feat_off_diag_mag_tail_decay", "feat_sparsity_score_soft", "feat_band_score", "feat_block_score"]
cell_hash, cell_stats, rel_agree = {}, {}, {}
for h, d_ in runs.items():
    x = d_.drop_duplicates("cell_id").set_index("cell_id")
    sc = d_[(d_.estimator_name == "sample_cov") & (d_.device == "cpu") & (d_.status == "success")].drop_duplicates("cell_id").set_index("cell_id").frobenius_loss
    if "data_sha256" in d_ and "sigma_sha256" in d_:
        xx = x.dropna(subset=["data_sha256"]); cell_hash[h] = {str(c): (str(a_), str(b_)) for c, a_, b_ in zip(xx.index, xx.sigma_sha256, xx.data_sha256)}
    cols = [c for c in STAT_COLS if c in x]   # the release rows and the notebook rows both carry the statistics under these names
    if len(cols) >= 16:
        cell_stats[h] = {str(c): [float(x.loc[c, k]) for k in cols] + [float(sc[c]) if c in sc.index else np.nan] for c in x.index}
    if "release_stats_agree" in d_:
        r_ = rel[(rel.estimator_name == "sample_cov") & (rel.device == "cpu")].drop_duplicates("cell_id").set_index("cell_id").frobenius_loss if rel is not None else pd.Series(dtype=float)
        rel_agree[h] = {str(c) for c, ok in zip(x.index, x.release_stats_agree) if bool(ok) and c in sc.index and c in r_.index and abs(sc[c] - r_[c]) <= 1e-9 * abs(r_[c])}
def stats_agree(h1, h2, c):
    a_, b_ = cell_stats.get(h1, {}).get(c), cell_stats.get(h2, {}).get(c)
    if a_ is None or b_ is None or len(a_) != len(b_): return False
    pairs = [(u, v) for u, v in zip(a_, b_) if np.isfinite(u) or np.isfinite(v)]
    return len(pairs) >= 16 and all(np.isfinite(u) and np.isfinite(v) and abs(u - v) <= 1e-9 * max(1.0, abs(v)) for u, v in pairs)
def identical_cells(hs):
    """Cells identical across the runs hs. Between notebook runs: equal sha256 of X and Sigma, or, failing that (the last bits of a matrix
    product can differ between hosts), the 17 recorded data statistics and the sample covariance loss all within 1e-9, counted separately.
    Where the release is one of the runs: the statistic agreement recorded by block 1. Returns (identical, by_hash, common). by_hash holds the
    cells whose hashes are equal among the notebook runs compared; a pair of one notebook run and the release has no hash comparison, so its
    by_hash is empty and every consistent cell counts as matched by statistics."""
    runs_only = [h for h in hs if h != "amd_mi300a_release"]
    common = set.intersection(*[set(tables[h][1]) for h in hs]) if hs else set()
    ident = set(common); by_hash = set(common) if len(runs_only) > 1 else set()
    if len(runs_only) > 1:
        ref = runs_only[0]
        by_hash = {c for c in common if all(h in cell_hash and cell_hash[h].get(c) is not None and cell_hash[h].get(c) == cell_hash[ref].get(c) for h in runs_only)}
        by_stats = {c for c in common - by_hash if all(stats_agree(ref, h, c) for h in runs_only[1:])}
        ident = by_hash | by_stats
    if "amd_mi300a_release" in hs:
        ident = {c for c in ident if all(c in rel_agree.get(h, set()) for h in runs_only)}; by_hash = by_hash & ident
    return ident, by_hash, common
S["data_identity"] = {}
for i, a in enumerate(usable):
    for b in usable[i + 1:]:
        Ga, Pa = tables[a]; Gb, Pb = tables[b]; out = {}
        ident, byh, comm = identical_cells([a, b])
        out["data_identity"] = {"n_common_cells": len(comm), "n_identical_cells": len(ident), "n_excluded_non_identical": len(comm) - len(ident),
                                "n_identical_by_hash": len(byh), "n_identical_by_statistics_only": len(ident) - len(byh),
                                "method": "statistic agreement with the release, whose rows carry no hashes" if "amd_mi300a_release" in (a, b) else "sha256 of X and Sigma equal, else the 17 recorded statistics and the sample covariance loss within 1e-9"}
        for dev in ("cpu", "cuda"):
            if sorted(menus[a].get(dev, [])) != sorted(menus[b].get(dev, [])) or not menus[a].get(dev): continue   # only compare identical menus
            keys = [k for k in Ga if k in Gb and k[1] == dev and k[0] in ident]
            if keys:
                agree = np.array([Ga[k][1] == Gb[k][1] for k in keys], float); des = [Ga[k][2] for k in keys]
                out[f"{dev}_groups"] = {"n": len(keys), "error_only_agreement": float(np.mean([Ga[k][0] == Gb[k][0] for k in keys])), "balanced_agreement": float(agree.mean()), "balanced_agreement_ci95": cluster_bootstrap(agree, des)}
        if pooled_menu(menus[a]) == pooled_menu(menus[b]):
            keys = [k for k in Pa if k in Pb and k in ident]
            if keys:
                agree = np.array([Pa[k][1] == Pb[k][1] for k in keys], float); des = [Pa[k][2] for k in keys]
                out["pooled_cells"] = {"n": len(keys), "error_only_agreement": float(np.mean([Pa[k][0] == Pb[k][0] for k in keys])), "balanced_agreement": float(agree.mean()), "balanced_agreement_ci95": cluster_bootstrap(agree, des),
                                       "balanced_device_agreement": float(np.mean([Pa[k][1].split("/")[1] == Pb[k][1].split("/")[1] for k in keys]))}
        S["pairwise"][f"{a} | {b}"] = out
        how = "statistic agreement with the release" if "amd_mi300a_release" in (a, b) else f"hash equality ({len(byh)}) or statistics within rounding ({len(ident) - len(byh)})"
        print(f"{a} vs {b}: {len(ident)} of {len(comm)} common cells identical by {how}" + (f" ({len(comm) - len(ident)} excluded)" if len(comm) > len(ident) else ""))
        for view, vv in out.items():
            if view != "data_identity": print(f"  {view}: balanced recommendation agrees on {vv['balanced_agreement']:.3f} of {vv['n']} identical cells (error only: {vv['error_only_agreement']:.3f})")

# the paper's RQ5 quantity: among complete cells shared by every usable run with the full released menu and certified identical across
# them, how often does the balanced recommendation differ between at least two accelerators? Error only is the control.
full = [h for h in usable if pooled_menu(menus[h]) == pooled_menu(RELEASE_MENU)]
common = set.intersection(*[set(tables[h][1]) for h in full]) if len(full) > 1 else set()
if common:
    ident, byh, comm = identical_cells(full); common = common & ident
    S["data_identity"]["across_all"] = {"hardware": full, "n_common_cells": len(comm), "n_identical_cells": len(ident), "n_identical_by_hash": len(byh),
                                        "n_identical_by_statistics_only": len(ident) - len(byh),
                                        "method": "consistent: hashes equal among the notebook runs or their statistics within 1e-9, and statistic agreement with the release; by hash: hashes equal among the notebook runs, the release having none"}
if common:
    cells = sorted(common); des = [tables[full[0]][1][c][2] for c in cells]
    bal = np.array([len({tables[h][1][c][1] for h in full}) > 1 for c in cells], float); dev = np.array([len({tables[h][1][c][1].split("/")[1] for h in full}) > 1 for c in cells], float)
    eo = np.array([len({tables[h][1][c][0] for h in full}) > 1 for c in cells], float)
    S["across_all"] = {"hardware": full, "n_common_cells": len(cells), "balanced_recommendation_differs": float(bal.mean()), "balanced_recommendation_differs_ci95": cluster_bootstrap(bal, des),
                       "balanced_device_differs": float(dev.mean()), "error_only_recommendation_differs": float(eo.mean()), "error_only_recommendation_differs_ci95": cluster_bootstrap(eo, des)}
    print(f"across {len(full)} configurations and {len(cells)} common cells certified identical: the balanced recommendation differs on {bal.mean():.3f}, its device on {dev.mean():.3f}, the error only recommendation on {eo.mean():.3f}")

for k, name in ((2, "block2_dimension_sweep"), (3, "block3_regression_family"), (4, "block4_downstream_validity")):
    S[f"block{k}"] = {}; dirs, sup = latest_protocol(name)
    for hw, folder in dirs.items():
        b = load_summary(folder)
        if b is None: continue
        rep = b.get("planned", {})
        q = run_gate(b, name, folder) | {"protocol_id": folder.name, "superseded_protocols": sup.get(hw, [])}
        if not q["usable"]: print(f"block {k} run {hw} EXCLUDED: {gate_reasons(q)}")
        if k == 2: entry = {str(p_): {"phi_groups": v["groups"].get("phi"), "phi_pooled": v["pooled"].get("phi"), "cpu_to_gpu": v["pooled"].get("cpu_to_gpu"), "gpu_to_cpu": v["pooled"].get("gpu_to_cpu"), "n_groups": v["groups"].get("n_groups")} for p_, v in b["by_p"].items()}
        if k == 3: entry = {kk: b.get(kk) for kk in ("n_cells", "phi_configuration", "phi_ci95", "share_of_flips_changing_estimator", "share_of_flips_changing_implementation", "share_of_flips_changing_device", "share_of_flips_changing_fidelity",
                                                       "share_of_flips_changing_estimator_only", "share_of_flips_changing_implementation_only", "share_of_flips_changing_device_only", "share_of_flips_changing_fidelity_only", "share_of_flips_changing_several_axes", "frac_cells_unsupported", "median_selection_share_of_wall_clock")}
        if k == 4:
            q["real_data"] = not b.get("data_source", "synthetic").startswith("synthetic"); q["real_regression_data"] = b.get("regression", {}).get("regression_source", "").startswith("california")
            entry = {"data_source": b.get("data_source"), "panel_sha256": b.get("panel_sha256"), "n_assets": b.get("n_assets"), "n_days": b.get("n_days"), "rules": b.get("rules"),
                     "selection_error": b.get("selection_error"), "rules_frobenius_proxy": b.get("rules_frobenius_proxy"), "oracle_oos_variance_annualised_by_device": b.get("oracle_oos_variance_annualised_by_device"),
                     "estimator_oos_variance_annualised_by_device": b.get("estimator_oos_variance_annualised_by_device"), "estimator_median_max_abs_weight": b.get("estimator_median_max_abs_weight"),
                     "regression": {kk: vv for kk, vv in b.get("regression", {}).items() if kk not in ("rules", "menu")} | {"rules": {r: {x: y for x, y in v.items() if x != "picks"} for r, v in b.get("regression", {}).get("rules", {}).items()}}}
        entry["quality"] = q; entry["planned"] = rep; S[f"block{k}"][hw] = entry
S["audit"] = {}
for hw, folder in b1_dirs.items():
    b = load_summary(folder)
    if b: S["audit"][hw] = {"cpu": (b.get("hardware_seen", {}).get("cpu_model") or [""])[0], "rows": b.get("implementation_audit", []), "usable": quality.get(hw, {}).get("usable", False)}
S["code_hashes"] = {hw: meta[hw].get("code_hash") for hw in runs}
S["legacy_results_ignored"] = legacy_results()
if S["legacy_results_ignored"]: print("NOTE: result files from an earlier notebook version were found and ignored:", S["legacy_results_ignored"])
json.dump(S, open(OUT / "hardware_matrix_summary.json", "w"), indent=2, default=str)
shutil.copy(OUT / "hardware_matrix_summary.json", RESULTS / "hardware_matrix_summary.json")
print("written:", RESULTS / "hardware_matrix_summary.json")
return S
'''

DISPATCH = r'''
# @title 6. Run the selected blocks in the selected order, then assemble the hardware matrix (rerun this cell after a disconnect; every block resumes from its checkpoint)
BLOCK_FUNCS = {k: globals().get(f"run_block{k}") for k in range(1, 6)}
BLOCK_NAMES = {1: "covariance on this CPU and GPU", 2: "dimension sweep", 3: "regression family", 4: "downstream validity", 5: "hardware matrix across runtimes"}
outcome = {}
for k in BLOCK_ORDER + [5]:
    print("\n" + "=" * 100 + f"\nBLOCK {k}: {BLOCK_NAMES[k]}\n" + "=" * 100)
    t0 = perf_counter()
    if BLOCK_FUNCS[k] is None:
        outcome[k] = "not in this notebook"; print(outcome[k]); continue
    try:
        S_ = BLOCK_FUNCS[k]() or {}
        rep = S_.get("planned") if isinstance(S_, dict) else None
        bad = ""
        if isinstance(rep, dict):
            reps = {"all": rep} if "n_planned" in rep else {str(n): r for n, r in rep.items() if isinstance(r, dict)}
            bad = "; ".join(f"{n}: {r.get('n_failed_after_retries', 0)} failed and {r.get('n_invalid_after_retries', 0)} invalid after {MAX_ATTEMPTS} attempts, {r.get('n_pending', 0)} pending, of {r.get('n_planned')} planned" for n, r in reps.items() if not r.get("complete", True))
        outcome[k] = f"done in {(perf_counter() - t0) / 60:.1f} min" + (f" (INCOMPLETE: {bad})" if bad else "")
    except SystemExit as e:
        outcome[k] = f"stopped: {e}"; print("STOPPED:", e); continue   # a block that stops for a stated reason does not prevent the others
    except Exception:
        outcome[k] = "failed: " + traceback.format_exc().strip().splitlines()[-1]; traceback.print_exc()
    print(f"block {k}: {outcome[k]}")
print("\nSUMMARY OF THIS SESSION ON", HW)
for k in BLOCK_ORDER + [5]:
    print(f"  block {k} ({BLOCK_NAMES[k]}): {outcome.get(k, 'not reached')}")
print("\nsummaries the paper ingests:", sorted(p.name for p in RESULTS.glob("*summary.json")))
print("to add another accelerator to the matrix: open the notebook for that accelerator and run all")
if any(str(v).startswith(("failed", "stopped")) or "INCOMPLETE" in str(v) for v in outcome.values()):
    raise RuntimeError("at least one block did not finish cleanly; see the messages above, then rerun this cell (failed and invalid rows are retried up to three times; tick RETRY_EXHAUSTED for one more round)")
'''


def md(s):
    return nbf.v4.new_markdown_cell(s)


def code(s):
    return nbf.v4.new_code_cell(s.strip("\n"))


def block_cell(params, k, body):
    """Form parameters at the top of the cell, the block itself as a function the dispatcher calls."""
    return code(params.strip("\n") + f"\n\ndef run_block{k}():\n" + textwrap.indent(body.strip("\n"), "    ") + "\n")


VARIANTS = [
    # (file suffix, EXPECTED_ACCELERATOR, substring the device name must contain, Colab gpuType hint, label)
    ("T4", "T4", "T4", "T4", "NVIDIA T4 (Turing; double precision at a 32nd of the single precision rate)"),
    ("L4", "L4", "L4", "L4", "NVIDIA L4 (Ada; double precision at a 64th of the single precision rate)"),
    ("A100", "A100", "A100", "A100", "NVIDIA A100 (Ampere; double precision at half the single precision rate)"),
    ("G4", "G4", "RTX PRO 6000", "G4", "NVIDIA G4, the Blackwell RTX PRO 6000 (double precision at a 64th of the single precision rate)"),
    ("CPU", "CPU", "", "", "the CPU only runtime (a second CPU configuration; GPU rows are not produced)"),
]


def make_setup(variant, match, blocks):
    return (SETUP.replace("__VARIANT__", variant).replace("__MATCH__", match).replace("__BLOCKS__", blocks)
            .replace("__PKG_HASH__", EXPECTED_PKG_HASH).replace("__PARQUET_SHA__", EXPECTED_PARQUET_SHA256))


def intro(label, file):
    return (f"# CovBench v2 on {label}\n\n"
            f"This is the `{file}` copy of the notebook: the code is identical in every copy, and cell 1 stops if the session is not on this runtime type, so results cannot land in another accelerator's folder. "
            "The paper's claim is that the recommended estimator depends on the hardware, so run the copy for each accelerator you have "
            "(Runtime -> Change runtime type: T4, L4, A100, G4, or CPU). Every result is keyed by the accelerator it ran on; a run on the same accelerator resumes from its checkpoint, "
            "refuses to continue under a changed software stack or host CPU unless you allow it, and retries failed rows up to three times. "
            "Block 5, which always runs last, assembles the hardware matrix from every runtime found in Drive next to the released MI300A rows: flip rate and migration per accelerator with design point intervals, "
            "pairwise agreement of the recommendations on the same cells, and the share of cells whose recommendation changes across accelerators.\n\n"
            "In cell 1, `BLOCKS` chooses which blocks run and in which order (default `4,1,3,2`: downstream validity, covariance on this CPU and GPU, regression family, dimension sweep). "
            "Tick `SMOKE_TEST` once for a few minute check of every block on tiny problems, then untick it and run all. After a disconnect, run all again.\n\n"
            "At the defaults: block 1 about 5 hours (3 replicates; the graphical lasso cross validation on the host CPU dominates), block 2 about 3 hours, block 3 about 3 to 4 hours (two fold tuning per configuration), block 4 about 1 hour. "
            "Results and checkpoints go to `MyDrive/covbench_v2/`; the summaries the paper ingests go to `MyDrive/covbench_v2/notebook_results/`.")


DONE = ("## Done on this runtime\n\nOpen the copy for the next accelerator and run all. When every runtime has run, copy `MyDrive/covbench_v2/notebook_results/hardware_matrix_summary.json` "
        "into `paper/notebook_results/` and run `python fill_tables.py` in `paper/`; the appendix tables fill themselves. Block 4's summaries record in `data_source` whether the frozen panel is real returns or the synthetic fallback.")

for suffix, variant, match, gpu_type, label in VARIANTS:
    file = f"covbench_v2_{suffix}.ipynb"
    nb = nbf.v4.new_notebook()
    nb.metadata = {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "colab": {"provenance": []}}
    if gpu_type:
        nb.metadata["accelerator"] = "GPU"; nb.metadata["colab"]["gpuType"] = gpu_type
    nb.cells = [md(intro(label, file)), code(make_setup(variant, match, "4,1,3,2")), code(RUNNER), code(ORACLE), code(REG_IMPL),
                block_cell(B1_PARAMS, 1, B1_BODY), block_cell(B2_PARAMS, 2, B2_BODY), block_cell(B3_PARAMS, 3, B3_BODY), block_cell(B4_PARAMS, 4, B4_BODY),
                block_cell(B5_PARAMS, 5, B5_BODY), code(DISPATCH), md(DONE)]
    nbf.validate(nb); nbf.write(nb, HERE / file); print("wrote", file)

# the matrix only notebook: any runtime, no released code needed, assembles block 5 from whatever is in Drive
nb = nbf.v4.new_notebook()
nb.metadata = {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "colab": {"provenance": []}}
nb.cells = [md("# CovBench v2: hardware matrix only\n\nRuns block 5 alone on any runtime (CPU is enough, and the released code zip is not needed): it reads every accelerator's results from `MyDrive/covbench_v2/` and the released "
               "MI300A rows and writes `notebook_results/hardware_matrix_summary.json`, which `fill_tables.py` turns into the paper's appendix tables. The per accelerator notebooks already run "
               "block 5 at the end of each run; this copy is for reassembling the matrix without rerunning anything."),
            code(make_setup("ANY", "", "")), code(RUNNER), code(ORACLE), block_cell(B5_PARAMS, 5, B5_BODY), code(DISPATCH)]
nbf.validate(nb); nbf.write(nb, HERE / "covbench_v2_hardware_matrix.ipynb"); print("wrote covbench_v2_hardware_matrix.ipynb")
_nb_list = re.search(r'TICKER_LIST = \((.*?)\)\.split\(\)', B4_BODY, re.S).group(1).replace('"', '').split()
_ns = {}; exec(open(HERE / "make_downstream_data.py").read().split("PANEL_START, PANEL_END")[0], _ns)
assert _ns["TICKER_LIST"] == _nb_list, "make_downstream_data.py ticker list differs from the notebook's"
print("make_downstream_data.py carries the notebook's ticker list:", len(_nb_list), "names")
