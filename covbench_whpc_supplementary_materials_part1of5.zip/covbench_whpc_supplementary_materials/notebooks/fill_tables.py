"""Ingest the hardware matrix summary written by block 5 into LaTeX table fragments for the paper.

Usage: python fill_tables.py [--include-incomplete]
Run from the paper/ directory; reads notebook_results/hardware_matrix_summary.json and writes
tables/tab_hw_matrix.tex, tab_hw_agreement.tex, tab_nb1_audit.tex, tab_nb2_psweep.tex,
tab_nb3_regression.tex, tab_nb4_downstream.tex. Every table is written as "pending" when the summary
or its section is absent, so the paper always compiles.

Quality gate: a run enters a table only if block 5 marked it usable (every planned configuration
succeeded, one software stack, the audited release code, a complete summary). Excluded runs are listed
under the table with the reason. --include-incomplete overrides the gate and labels the rows.
"""
import json
import sys
from pathlib import Path

RES = Path("notebook_results"); TAB = Path("tables"); TAB.mkdir(exist_ok=True)
NAMES = {"amd_mi300a_release": "AMD MI300A (release)"}
INCLUDE_INCOMPLETE = "--include-incomplete" in sys.argv


def pct(x): return "n/a" if x is None else f"{100*float(x):.1f}\\%"
def f3(x): return "n/a" if x is None else f"{float(x):.3f}"
def f4(x): return "n/a" if x is None else f"{float(x):.4f}"
def esc(s): return str(s).replace("_", r"\_").replace("&", r"\&").replace("%", r"\%")


def pending(name, msg="pending: run the notebook on at least one accelerator"):
    (TAB / name).write_text("\\begin{tabular}{@{}l@{}}\\toprule " + msg + " \\\\ \\bottomrule\\end{tabular}\n")


def label(key, row=None):
    if key in NAMES:
        return NAMES[key]
    meta = (row or {}).get("meta", {})
    g = (meta.get("gpu_model") or [""])[0]
    if g:
        return esc(g.replace("NVIDIA ", "").replace("Tesla ", "")) + (" (mixed stack)" if meta.get("mixed_stacks") else "")
    c = (meta.get("cpu_model") or [""])[0]
    return ("CPU only: " + esc(c[:26])) if c else esc(key)


def why_excluded(q):
    reasons = []
    if q.get("summary_status") is None and not q.get("complete", False): return "no summary yet (run in progress or interrupted)"
    if not q.get("complete", False): reasons.append("incomplete planned set")
    if q.get("matrix_audit_complete") is False: reasons.append("matrix audit incomplete or missing")
    if q.get("mixed_stacks"): reasons.append("mixed software stacks")
    if q.get("code_verified") is False: reasons.append("unverified code")
    if q.get("summary_status") not in ("complete", "release", None): reasons.append(f"summary {q.get('summary_status')}")
    if q.get("real_data") is False: reasons.append("synthetic panel")
    return ", ".join(reasons) or "excluded by block 5"


def usable(q):
    return INCLUDE_INCOMPLETE or bool(q.get("usable", False))


def tagged(key, row, q):
    """Row label, with the gate's reason appended when the run is included only because of --include-incomplete."""
    return label(key, row) + ("" if q.get("usable", False) else f" ({why_excluded(q)})")


def excluded_note(excl, ncols):
    if not excl:
        return []
    return [r"\midrule", f"\\multicolumn{{{ncols}}}{{@{{}}l}}{{\\small Excluded: " + "; ".join(f"{k} ({esc(v)})" for k, v in excl) + r"} \\"]


def load():
    p = RES / "hardware_matrix_summary.json"
    return json.load(open(p)) if p.exists() else None


def hw_matrix(S):
    H = S.get("hardware", {})
    if not H:
        return pending("tab_hw_matrix.tex")
    rows = [r"\begin{tabular}{@{}lrcccccc@{}}", r"\toprule",
            r"Accelerator & cells & $\Phi$ [95\% CI] & $\Phi$ CPU groups & $\Phi$ GPU groups & pooled flip & CPU$\to$GPU & GPU$\to$CPU \\", r"\midrule"]
    excl = []
    for key, r in H.items():
        q = r.get("quality", {})
        if not usable(q):
            excl.append((label(key, r), why_excluded(q))); continue
        ci = r["groups"].get("phi_ci95") or {}
        ci_s = f" [{f3(ci['ci95_lo'])}, {f3(ci['ci95_hi'])}]" if ci else ""
        rows.append(f"{tagged(key, r, q)} & {r['n_cells']} & {f3(r['groups'].get('phi'))}{ci_s} & {f3(r['cpu_groups'].get('phi'))} & {f3(r['gpu_groups'].get('phi'))} & "
                    f"{f3(r['pooled'].get('phi'))} & {pct(r['pooled'].get('cpu_to_gpu'))} & {pct(r['pooled'].get('gpu_to_cpu'))} \\\\")
    A = S.get("across_all", {})
    if A.get("n_common_cells"):
        cb = A.get("balanced_recommendation_differs_ci95") or {}; ce = A.get("error_only_recommendation_differs_ci95") or {}
        rows += [r"\midrule", f"\\multicolumn{{8}}{{@{{}}l}}{{Across all {len(A['hardware'])} full menu configurations, {A['n_common_cells']} common cells: the balanced recommendation differs on "
                 f"{pct(A['balanced_recommendation_differs'])}" + (f" [{pct(cb['ci95_lo'])}, {pct(cb['ci95_hi'])}]" if cb else "") + f", its device on {pct(A['balanced_device_differs'])}, the error only recommendation on {pct(A['error_only_recommendation_differs'])}" + (f" [{pct(ce['ci95_lo'])}, {pct(ce['ci95_hi'])}]" if ce else "") + "} \\\\"]
    rows += excluded_note(excl, 8) + [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_hw_matrix.tex").write_text("\n".join(rows) + "\n")


def hw_agreement(S):
    P = S.get("pairwise", {}); H = S.get("hardware", {})
    if not P:
        return pending("tab_hw_agreement.tex", "pending: run the notebook on at least two accelerators")
    rows = [r"\begin{tabular}{@{}llrcc@{}}", r"\toprule", r"Pair & view & identical cells & error only agreement & balanced agreement [95\% CI] \\", r"\midrule"]
    for pair, v in P.items():
        a, b = pair.split(" | ")
        di = v.get("data_identity") or {}
        for view, vv in v.items():
            if view == "data_identity": continue
            ci = vv.get("balanced_agreement_ci95") or {}
            rows.append(f"{label(a, H.get(a))} / {label(b, H.get(b))} & {esc(view.replace('_', ' '))} & {vv['n']} & {pct(vv['error_only_agreement'])} & {pct(vv['balanced_agreement'])}" + (f" [{pct(ci['ci95_lo'])}, {pct(ci['ci95_hi'])}]" if ci else "") + " \\\\")
        if di.get("n_excluded_non_identical"):
            rows.append(f"\\multicolumn{{5}}{{@{{}}l}}{{\\footnotesize {di['n_identical_cells']} of {di['n_common_cells']} common cells certified identical; {di['n_excluded_non_identical']} excluded (eigensolver dependent covariance, see text)}} \\\\")
    rows += [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_hw_agreement.tex").write_text("\n".join(rows) + "\n")


def audit(S):
    A = S.get("audit", {})
    if not A:
        return pending("tab_nb1_audit.tex")
    rows = [r"\begin{tabular}{@{}lllccc@{}}", r"\toprule",
            r"Host CPU & estimator & kind & cells & wall clock ratio, port over reference (median, q10 - q90) & matrix discrepancy, median / max \\", r"\midrule"]
    for key, v in A.items():
        if not (INCLUDE_INCOMPLETE or v.get("usable", False)): continue
        for a in v.get("rows", []):
            ratio = a.get("runtime_ratio_port_over_ref_median", a.get("runtime_ratio_torch_over_ref_median"))
            if a.get("matrix_rel_discrepancy_max") is not None:
                disc = f"{a['matrix_rel_discrepancy_median']:.1e} / {a['matrix_rel_discrepancy_max']:.1e}"
                if a.get("matrix_rel_discrepancy_max_same_normalisation") is not None: disc += f" ({a['matrix_rel_discrepancy_max_same_normalisation']:.0e} at the same normalisation)"
                if a.get("shrinkage_abs_difference_max") is not None and a["estimator"] != "oas": disc += f"; shrinkage intensity differs by up to {a['shrinkage_abs_difference_max']:.3f}"
            else:
                disc = f"loss based {a.get('frobenius_rel_discrepancy_max', float('nan')):.1e}"
            rows.append(f"{esc((v.get('cpu') or key)[:28])} & {esc(a['estimator'].replace('_', ' '))} & {esc(a.get('kind', 'port'))} & {a['n']} & {f3(ratio)} "
                        f"({f3(a['runtime_ratio_q10'])} - {f3(a['runtime_ratio_q90'])}) & {disc} \\\\")
    rows += [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_nb1_audit.tex").write_text("\n".join(rows) + "\n")


def psweep(S):
    B = S.get("block2", {}); H = S.get("hardware", {})
    if not B:
        return pending("tab_nb2_psweep.tex", "pending: run block 2 of the notebook")
    ps = sorted({p for v in B.values() for p in v if p.isdigit()}, key=int)
    rows = [r"\begin{tabular}{@{}ll" + "c" * len(ps) + "@{}}", r"\toprule", "Accelerator & quantity & " + " & ".join(f"$p={p}$" for p in ps) + r" \\", r"\midrule"]
    excl = []
    for key, v in B.items():
        q = v.get("quality", {})
        if not usable(q):
            excl.append((label(key, H.get(key)), why_excluded(q))); continue
        rows.append(f"{tagged(key, H.get(key), q)} & $\\Phi$ (groups) & " + " & ".join(f3(v.get(p, {}).get('phi_groups')) for p in ps) + r" \\")
        rows.append(" & $\\Phi$ (pooled) & " + " & ".join(f3(v.get(p, {}).get('phi_pooled')) for p in ps) + r" \\")
        rows.append(" & CPU$\\to$GPU (pooled) & " + " & ".join(pct(v.get(p, {}).get('cpu_to_gpu')) for p in ps) + r" \\")
    rows += excluded_note(excl, 2 + len(ps)) + [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_nb2_psweep.tex").write_text("\n".join(rows) + "\n")


def regression(S):
    B = S.get("block3", {}); H = S.get("hardware", {})
    if not B:
        return pending("tab_nb3_regression.tex", "pending: run block 3 of the notebook")
    keys = [k for k, v in B.items() if usable(v.get("quality", {}))]
    excl = [(label(k, H.get(k)), why_excluded(v.get("quality", {}))) for k, v in B.items() if k not in keys]
    if not keys:
        return pending("tab_nb3_regression.tex", "pending: no usable block 3 run (" + "; ".join(f"{k}: {esc(v)}" for k, v in excl) + ")")
    rows = [r"\begin{tabular}{@{}l" + "c" * len(keys) + "@{}}", r"\toprule", "Quantity & " + " & ".join(tagged(k, H.get(k), B[k].get("quality", {})) for k in keys) + r" \\", r"\midrule",
            "Cells & " + " & ".join(str(B[k].get("n_cells", "n/a")) for k in keys) + r" \\",
            "Configuration flip rate & " + " & ".join(f3(B[k].get("phi_configuration")) for k in keys) + r" \\",
            r"\midrule", r"\multicolumn{" + str(len(keys) + 1) + r"}{@{}l}{\small Share of flips in which the axis changes (not exclusive)} \\",
            "Estimator & " + " & ".join(pct(B[k].get("share_of_flips_changing_estimator")) for k in keys) + r" \\",
            "Implementation & " + " & ".join(pct(B[k].get("share_of_flips_changing_implementation")) for k in keys) + r" \\",
            "Device & " + " & ".join(pct(B[k].get("share_of_flips_changing_device")) for k in keys) + r" \\",
            "Fidelity & " + " & ".join(pct(B[k].get("share_of_flips_changing_fidelity")) for k in keys) + r" \\",
            r"\midrule", r"\multicolumn{" + str(len(keys) + 1) + r"}{@{}l}{\small Share of flips in which only that axis changes (exclusive)} \\",
            "Estimator only & " + " & ".join(pct(B[k].get("share_of_flips_changing_estimator_only")) for k in keys) + r" \\",
            "Implementation only & " + " & ".join(pct(B[k].get("share_of_flips_changing_implementation_only")) for k in keys) + r" \\",
            "Device only & " + " & ".join(pct(B[k].get("share_of_flips_changing_device_only")) for k in keys) + r" \\",
            "Fidelity only & " + " & ".join(pct(B[k].get("share_of_flips_changing_fidelity_only")) for k in keys) + r" \\",
            "Several axes & " + " & ".join(pct(B[k].get("share_of_flips_changing_several_axes")) for k in keys) + r" \\",
            r"\midrule",
            "Cells with an unsupported efficient configuration & " + " & ".join(pct(B[k].get("frac_cells_unsupported")) for k in keys) + r" \\",
            "Median share of wall clock spent selecting the penalty & " + " & ".join(pct(B[k].get("median_selection_share_of_wall_clock")) for k in keys) + r" \\"]
    rows += excluded_note(excl, len(keys) + 1) + [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_nb3_regression.tex").write_text("\n".join(rows) + "\n")


def downstream(S):
    B = S.get("block4", {}); H = S.get("hardware", {})
    if not B:
        return pending("tab_nb4_downstream.tex", "pending: run block 4 of the notebook")
    rows = [r"\begin{tabular}{@{}lllccc@{}}", r"\toprule", r"Accelerator & rule & estimator chosen & OOS variance (annualised) & fit time (s) & deployed within budget \\", r"\midrule"]
    excl = []
    for key, v in B.items():
        q = v.get("quality", {})
        if not usable(q):
            excl.append((label(key, H.get(key)), why_excluded(q))); continue
        src = "real returns" if q.get("real_data") else "synthetic panel"
        orc = v.get("oracle_oos_variance_annualised_by_device") or {}
        rows.append(f"\\multicolumn{{6}}{{@{{}}l}}{{{tagged(key, H.get(key), q)}, covariance block ({src}; $p = {v.get('n_assets', '?')}$, walk forward, selection on the realised out of sample variance of past windows; {esc(v.get('data_source', ''))[:50]})}} \\\\")
        for rule, r in (v.get("rules") or {}).items():
            if not r.get("n_eval_windows"):
                rows.append(f" & {esc(rule.replace('_', ' '))} & infeasible on every window & n/a & n/a & n/a \\\\"); continue
            inf = f" ({r['n_infeasible_windows']} infeasible)" if r.get("n_infeasible_windows") else ""
            rows.append(f" & {esc(rule.replace('_', ' '))} & {esc(r['estimator'].replace('_', ' '))} ({r['n_eval_windows']} windows{inf}) & {f4(r['mean_oos_variance_annualised'])} & {f4(r['mean_fit_wall_time_s'])} & {pct(r.get('deployed_within_budget')) if r.get('deployed_within_budget') is not None else 'n/a'} \\\\")
        if orc:
            rows.append(f" & per window oracle & lowest realised variance & " + " / ".join(f"{esc(k)}: {f4(x)}" for k, x in orc.items()) + " & n/a & n/a \\\\")
        prox = v.get("rules_frobenius_proxy") or {}
        if prox:
            eo = {k: r for k, r in prox.items() if k.endswith("/error_only") and r.get("n_eval_windows")}
            if eo:
                rows.append(f" & \\multicolumn{{5}}{{@{{}}l}}{{error only selection on the Frobenius distance to the next horizon's realised covariance instead (proxy): " + "; ".join(f"{esc(k.split('/')[0])} {esc(r['estimator'].replace('_', ' '))}, variance {f4(r['mean_oos_variance_annualised'])}" for k, r in eo.items()) + "}} \\\\")
        reg = v.get("regression", {})
        if reg.get("rules"):
            rsrc = "California housing" if q.get("real_regression_data") else "synthetic"
            rows.append(r"\midrule"); rows.append(f"\\multicolumn{{6}}{{@{{}}l}}{{{label(key, H.get(key))}, regression block ({rsrc}): mean held out MSE and fit time}} \\\\")
            for rule, r in reg["rules"].items():
                if r.get("mean_holdout_mse") is None:
                    rows.append(f" & {esc(rule.replace('_', ' '))} & infeasible on every fold & n/a & n/a & n/a \\\\"); continue
                inf = f" ({r['n_infeasible_folds']} infeasible)" if r.get("n_infeasible_folds") else ""
                rows.append(f" & {esc(rule.replace('_', ' '))} & {r['n_folds']} folds{inf} & {f4(r['mean_holdout_mse'])} & {f4(r['mean_fit_wall_time_s'])} & {pct(r.get('deployed_within_budget')) if r.get('deployed_within_budget') is not None else 'n/a'} \\\\")
        rows.append(r"\midrule")
    if rows[-1] == r"\midrule":
        rows.pop()
    rows += excluded_note(excl, 6) + [r"\bottomrule", r"\end{tabular}"]
    (TAB / "tab_nb4_downstream.tex").write_text("\n".join(rows) + "\n")


if __name__ == "__main__":
    S = load()
    if S is None:
        for t in ("tab_hw_matrix.tex", "tab_hw_agreement.tex", "tab_nb1_audit.tex", "tab_nb2_psweep.tex", "tab_nb3_regression.tex", "tab_nb4_downstream.tex"):
            pending(t)
    else:
        hw_matrix(S); hw_agreement(S); audit(S); psweep(S); regression(S); downstream(S)
    print("tables written to", TAB, "(incomplete runs included)" if INCLUDE_INCOMPLETE else "(usable runs only)")
