"""make_downstream_data.py: builds the two real data files that block 4 of the CovBench v2 notebooks needs, on a computer where
the downloads work (Colab is at times refused by Yahoo Finance). The ticker list is the notebook's fixed list, so the panel is the
one the notebook would have downloaded itself.

    pip install yfinance pandas scikit-learn
    python make_downstream_data.py

writes covbench_v2_downstream/user_prices.csv (adjusted close prices, dates by tickers, 2014 - 2024) and
covbench_v2_downstream/california_housing.csv. Put both files in MyDrive/covbench_v2/downstream/ (that folder itself, not a mode
subfolder; they serve both the smoke test and the full run) and run block 4 again. Block 4 computes the log returns, keeps the
names with a complete history and freezes the panel to Drive with its checksum, as it does for a download of its own.
"""
import hashlib
import sys
from pathlib import Path

import pandas as pd

TICKER_LIST = (
    "AAPL ABBV ABT ACN ADBE ADI ADM ADP ADSK AEE AEP AFL AIG AKAM ALB ALGN ALL AMAT AMD AME AMGN AMP AMT AMZN AON "
    "APA APD APH APTV ARE ATO AVB AVGO AVY AWK AXP AZO BA BAC BAX BBY BDX BEN BIIB BK BKNG BLK BMY BRK-B BSX "
    "BXP C CAG CAH CAT CB CBOE CCI CCL CDNS CF CHD CHRW CHTR CI CINF CL CLX CMCSA CME CMG CMI CMS CNC CNP "
    "COF COO COP COST CPB CPT CRM CSCO CSX CTAS CTSH CVS CVX D DAL DE DG DGX DHI DHR DIS DLR DLTR DOV DRI "
    "DTE DUK DVN DXCM EA EBAY ECL ED EFX EIX EL ELV EMR EOG EQIX EQR ES ESS ETN ETR EW EXC EXPD EXPE EXR "
    "F FANG FAST FCX FDX FE FFIV FITB FRT GD GE GILD GIS GLW GM GOOGL GPC GPN GRMN GS GWW HAL HAS HBAN HCA "
    "HD HIG HLT HOLX HON HPQ HRL HSY HST HUM IBM ICE IDXX IFF ILMN INTC INTU IP IPG ISRG ITW IVZ JBHT JCI JNJ "
    "JPM KEY KIM KLAC KMB KMI KMX KO KR L LEN LH LLY LMT LNT LOW LRCX LUV LVS MA MAA MAR MAS MCD MCHP "
    "MCK MCO MDLZ MDT MET META MGM MKC MLM MMC MMM MNST MO MOH MOS MPC MPWR MRK MS MSCI MSFT MSI MTB MTD MU "
    "NDAQ NEE NEM NFLX NI NKE NOC NOW NRG NSC NTAP NTRS NUE NVDA NVR O ODFL OKE OMC ON ORCL ORLY OXY PAYX PCAR "
    "PEG PEP PFE PG PGR PH PHM PKG PLD PM PNC PNW POOL PPG PPL PRU PSA PSX QCOM RCL REG REGN RF RJF RL "
    "RMD ROK ROP ROST RSG RTX SBUX SCHW SHW SJM SLB SNPS SO SPG SPGI SRE STE STT STX STZ SWK SWKS SYK SYY T "
    "TAP TDG TEL TER TFC TGT TJX TMO TMUS TROW TRV TSCO TSLA TSN TT TTWO TXN TXT UAL UDR UHS ULTA UNH UNP UPS "
    "URI USB V VLO VMC VRSK VRTX VTR VZ WAT WDC WEC WELL WFC WM WMB WMT WRB WYNN XEL XOM XYL YUM ZION ZTS "
).split()
PANEL_START, PANEL_END = "2014-01-01", "2024-12-31"
OUT = Path("covbench_v2_downstream"); OUT.mkdir(exist_ok=True)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def prices():
    import yfinance as yf
    px = yf.download(TICKER_LIST, start=PANEL_START, end=PANEL_END, auto_adjust=True, progress=False, threads=False)["Close"]
    if isinstance(px, pd.Series):
        px = px.to_frame()
    px = px.sort_index()
    complete = px.dropna(axis=1, how="any")
    print(f"downloaded {px.shape[1]} names, {px.shape[0]} days; {complete.shape[1]} with a complete history {PANEL_START} - {PANEL_END}")
    if px.shape[0] == 0:
        raise RuntimeError("no price data came back; Yahoo Finance refused the requests or the network is blocked. Try again later or from another network")
    if px.shape[0] < 2500 or complete.shape[1] < 50:
        raise RuntimeError(f"too little data came back ({px.shape[0]} days, {complete.shape[1]} complete names); nothing written")
    if complete.shape[1] < 200:
        print("WARNING: fewer than 200 names have a complete history; block 4 will use what there is")
    f = OUT / "user_prices.csv"; complete.to_csv(f, index_label="Date"); print("wrote", f, "sha256", sha(f))


def housing():
    from sklearn.datasets import fetch_california_housing
    frame = fetch_california_housing(as_frame=True).frame   # MedInc ... Longitude, MedHouseVal
    f = OUT / "california_housing.csv"; frame.to_csv(f, index=False); print("wrote", f, frame.shape, "sha256", sha(f))


if __name__ == "__main__":
    failed = []
    for step in (prices, housing):
        try:
            step()
        except Exception as e:
            failed.append(step.__name__); print(f"{step.__name__} failed: {e}")
    if failed:
        sys.exit("could not build: " + ", ".join(failed))
    print("now put both files in MyDrive/covbench_v2/downstream/ and run block 4 again")
