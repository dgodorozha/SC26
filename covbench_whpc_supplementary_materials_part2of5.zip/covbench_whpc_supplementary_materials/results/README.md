# Raw results

`covbench_v2/` is the folder the notebooks wrote to Google Drive, downloaded on 7 November 2026 without
modification (Drive's own zip, unpacked). `supplement/hardware_matrix_summary.json` is what block 5 computed from it;
`verification/` reruns that computation and an independent one against these files.

Layout:

    covbench_v2/
      covbench_code.zip                      the released package (sha256 9d7e0010...)
      experiments.parquet                    the released MI300A rows (sha256 d03a920e...)
      environment_last_session.json          host, driver and library versions of the last session
      block1_covariance_nvidia/<runtime>/full/<fingerprint>/
          results.parquet                    every timed fit of block 1 on that runtime (one row per cell, estimator, device)
          matrix_audit.parquet               CPU against GPU fitted matrices per cell (GPU runtimes only)
          summary.json                       the block's report: planned set, flip rates, speedups, audits, gate inputs
          manifest.json                      the parameters and code fingerprint the folder is named after
          *.bak                              the previous checkpoint, kept by the atomic write
      block2_dimension_sweep/<runtime>/full/<fingerprint>/      results.parquet, summary.json
      block3_regression_family/<runtime>/full/<fingerprint>/    results.parquet, summary.json
      block4_downstream_validity/<runtime>/full/<fingerprint>/  results.parquet, summary.json
      block5_hardware_matrix/full/                              the block 5 run folders
      notebook_results/
          hardware_matrix_summary.json       the hardware matrix (identical to supplement/hardware_matrix_summary.json)
          block<k>_<runtime>_summary.json    a copy of each block's report
      true_covariances/                      stored true covariances fetched for the eigensolver dependent cells
                                             (<cell_id>.npz), with <cell_id>.missing where none was available
      downstream/full/                       the frozen return panel used by block 4 on every runtime: returns_panel.parquet
                                             (yfinance, 200 names, 2,766 days, 2014 - 2024; sha256 182735ee..., recorded in every
                                             block 4 summary as panel_sha256) and panel_meta.json; a folder named
                                             full_synthetic_<timestamp> is an earlier synthetic panel set aside and not used.
                                             The housing data are fetched by scikit-learn at run time (fetch_california_housing,
                                             the StatLib cal_housing.tgz, 20,640 rows) and are not stored here; see the top
                                             level README for the provenance and how to freeze a copy.

`<runtime>` is one of `tesla_t4`, `nvidia_l4`, `nvidia_a100_sxm4_40gb`, `nvidia_rtx_pro_6000_blackwell_server_edition`
and `cpu_intel_r_xeon_r_cpu_2_20ghz`. `<fingerprint>` names the block's parameters and the code that produced the
rows, so a changed parameter starts a fresh folder rather than resuming a stale one; block 5 takes, per runtime, the
most recent folder that passes the whole quality gate and lists the others as superseded.

To recompute the summary from the raw files, either open `notebooks/covbench_v2_hardware_matrix.ipynb` in Colab with
the Drive folder mounted and run all (about two minutes), or run it anywhere with `COVBENCH_ROOT` set to a copy of
`covbench_v2` (`verification/run_b5.py` does this); it rewrites `notebook_results/hardware_matrix_summary.json`. Then
`python supplement/gen_tables.py <that file> supplement/tables` regenerates every table of the supplement.
