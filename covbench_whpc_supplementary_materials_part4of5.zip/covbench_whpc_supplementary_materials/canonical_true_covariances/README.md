# Canonical true covariances of the 108 eigensolver dependent cells

`files/<cell_id>.npz` are the release's own stored true covariances (arrays `Sigma` and `Omega`, 200 by 200, float64)
for the 108 block 1 cells (36 design points, three replicates) whose covariance depends on the eigensolver build:
the block diagonal and spiked structures under the polynomial decay spectrum. `SHA256SUMS.txt` lists their checksums.
The files are the ones the release's `sigma_path` column points at; they were not retrievable from the dataset
repository during the Colab runs (every marker in `results/covbench_v2/true_covariances/` records an HTTP 404), so
all five runs generated these cells locally. Placed in `MyDrive/covbench_v2/true_covariances/` (and the `.missing`
markers deleted), the notebooks use them for any cell not yet pinned to a generated matrix.

## Checks

`stored_sigma_stats_check.py` regenerates each cell's data from the stored covariance with the release code and
compares the 17 recorded statistics (relative 1e-9) with the release's rows and with each run's rows
(`stored_sigma_stats_check_log.txt`, `stored_sigma_stats_check.csv`):

- the release's own rows agree on all 108 cells, so the files are the matrices the release was computed on;
- the four GPU runs agree on all 78 of the 108 cells that are complete in the release, and on none of the 30 that
  are incomplete there (cells whose GPU rows the release recorded as "CUDA requested but not available", computed on
  another node, and which enter no comparison);
- the CPU only run agrees on none of the 108, which is why its comparisons exclude them (351 of 429 cells).

`regen_check.py` regenerates the 108 cells on the verification host (a two core Xeon outside Colab) and compares
with the stored files (`regeneration_check_log.txt`, `regeneration_check.csv`): the same spectrum to 2e-13 on every
cell, a different matrix on every cell (relative Frobenius distance 0.1 to 1.1), and a hash equal to none of the five
runs. A third host gives a third eigenbasis, as the supplement says.

`release_match.csv` records, per file, that `Sigma` is symmetric, that `Omega` is its inverse, and that its trace,
Frobenius norm and extreme eigenvalues match the values the release parquet records for the cell.

    python -I stored_sigma_stats_check.py <covbench_code folder> ../results/covbench_v2 files
    python -I regen_check.py <covbench_code folder> ../results/covbench_v2 files

(`<covbench_code folder>` is `notebooks/covbench_code.zip` unpacked; both scripts need numpy, pandas, pyarrow,
scipy and the release package's dependencies.)
