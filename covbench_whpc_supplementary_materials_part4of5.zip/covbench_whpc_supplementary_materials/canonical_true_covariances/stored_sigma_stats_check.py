"""For the 108 eigensolver dependent cells: regenerate X from the release's stored covariance and compare the 17 recorded statistics
with (a) the release's own rows and (b) each run's rows. Usage: python -I stored_sigma_stats_check.py <covbench_code> <covbench_v2> <npz folder>"""
import sys, json, numpy as np, pandas as pd
from pathlib import Path
code, root, tc = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(code))
from covbench.config import load_config, expand_cells
from covbench.data import regenerate_X
from covbench.features import compute_features
STATS = ["feat_kurtosis_mean", "feat_kurtosis_max", "feat_kurtosis_p95", "feat_skewness_mean", "feat_outlier_fraction", "feat_sample_cond", "feat_sample_effective_rank", "feat_sample_stable_rank",
         "feat_spectral_entropy", "feat_top_eig_gap_ratio", "feat_max_eigval_to_trace", "feat_off_diag_mag_p50", "feat_off_diag_mag_p95", "feat_off_diag_mag_tail_decay", "feat_sparsity_score_soft", "feat_band_score", "feat_block_score"]
cfg = load_config(str(code / "config.yaml")); cfg.replicates = 3; cells = {c.cell_id: c for c in expand_cells(cfg)}
ids = sorted(p.stem for p in tc.glob("*.npz"))
S = json.load(open(root / "notebook_results" / "hardware_matrix_summary.json"))
HW = ["tesla_t4", "nvidia_l4", "nvidia_a100_sxm4_40gb", "nvidia_rtx_pro_6000_blackwell_server_edition", "cpu_intel_r_xeon_r_cpu_2_20ghz"]
runs = {h: pd.read_parquet(root / "block1_covariance_nvidia" / h / "full" / S["quality"][h]["protocol_id"] / "results.parquet", columns=["cell_id"] + STATS).drop_duplicates("cell_id").set_index("cell_id") for h in HW}
rel = pd.read_parquet(root / "experiments.parquet", columns=["cell_id", "status", "device"] + STATS)
complete = set(rel[rel.status == "success"].groupby("cell_id").size().pipe(lambda s: s[s == 13]).index)
rel = rel.drop_duplicates("cell_id").set_index("cell_id")
def agree(a, b):
    pairs = [(float(a[k]), float(b[k])) for k in STATS if np.isfinite(float(b[k]))]
    return len(pairs) >= 16 and all(np.isfinite(u) and abs(u - v) <= 1e-9 * max(1.0, abs(v)) for u, v in pairs)
rows = []
for c in ids:
    Sigma = np.load(tc / f"{c}.npz")["Sigma"]
    X = regenerate_X(cells[c], "covbench_v1_4", Sigma); f = compute_features(X)
    rows.append(dict(cell=c, complete=c in complete, release=agree(f, rel.loc[c]), **{h: agree(f, runs[h].loc[c]) for h in HW}))
df = pd.DataFrame(rows)
print("cells:", len(df), "; complete in the release:", int(df.complete.sum()))
print("statistics of X regenerated from the stored covariance agree (17 statistics, relative 1e-9) with:")
print("  the release's own rows:        %d of %d (complete cells %d of %d, incomplete %d of %d)" % (df.release.sum(), len(df), df[df.complete].release.sum(), df.complete.sum(), df[~df.complete].release.sum(), (~df.complete).sum()))
for h in HW:
    print("  %-46s %d of %d (complete cells %d of %d)" % (h + ":", df[h].sum(), len(df), df[df.complete][h].sum(), df.complete.sum()))
df.to_csv(tc.parent / "stored_sigma_stats_check.csv", index=False)
