"""Regenerate the 108 eigensolver dependent cells on this host and compare with the release's stored covariances and with the runs' hashes."""
import sys, json, hashlib, numpy as np, pandas as pd
from pathlib import Path
code, root, tc = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(code))
from covbench.config import load_config, expand_cells
from covbench.data import generate_cell
import scipy.linalg
def sha(a): return hashlib.sha256(np.ascontiguousarray(a, dtype=np.float64).tobytes()).hexdigest()
cfg = load_config(str(code / "config.yaml")); cfg.replicates = 3; cells = {c.cell_id: c for c in expand_cells(cfg)}
ids = sorted(p.stem for p in tc.glob("*.npz"))
S = json.load(open(root / "notebook_results" / "hardware_matrix_summary.json"))
HW = ["tesla_t4", "nvidia_l4", "nvidia_a100_sxm4_40gb", "nvidia_rtx_pro_6000_blackwell_server_edition", "cpu_intel_r_xeon_r_cpu_2_20ghz"]
runs = {h: pd.read_parquet(root / "block1_covariance_nvidia" / h / "full" / S["quality"][h]["protocol_id"] / "results.parquet", columns=["cell_id", "sigma_sha256", "release_stats_agree"]).drop_duplicates("cell_id").set_index("cell_id") for h in HW}
rel = pd.read_parquet(root / "experiments.parquet").drop_duplicates("cell_id").set_index("cell_id")
rows = []
for c in ids:
    cell = cells[c]
    _, S1, _ = generate_cell(cell, "covbench_v1_4")
    orig = np.linalg.eigh
    try:
        np.linalg.eigh = lambda A: scipy.linalg.eigh(A, driver="evr"); _, S2, _ = generate_cell(cell, "covbench_v1_4")
    finally:
        np.linalg.eigh = orig
    Srel = np.load(tc / f"{c}.npz")["Sigma"]
    d_rel = np.linalg.norm(S1 - Srel) / np.linalg.norm(Srel); d_drv = np.linalg.norm(S1 - S2) / np.linalg.norm(S1)
    spec = np.max(np.abs(np.sort(np.linalg.eigvalsh(S1)) - np.sort(np.linalg.eigvalsh(Srel))))
    h1 = sha(S1)
    rows.append(dict(cell=c, structure=cell.structure_id, rel_fro_vs_release=d_rel, rel_fro_second_driver=d_drv, spectrum_gap=spec, same_hash_as=[h for h in HW if runs[h].loc[c, "sigma_sha256"] == h1],
                     release_complete=int(13 == (rel.index == c).sum()) if False else None, gpu_agree=bool(runs["nvidia_a100_sxm4_40gb"].loc[c, "release_stats_agree"])))
df = pd.DataFrame(rows)
print("cells regenerated here:", len(df))
print("relative Frobenius distance of this host's matrix to the release's stored matrix: median %.2e, max %.2e; cells within 1e-9: %d" % (df.rel_fro_vs_release.median(), df.rel_fro_vs_release.max(), int((df.rel_fro_vs_release < 1e-9).sum())))
print("same spectrum as the stored matrix (max eigenvalue gap):", "%.1e" % df.spectrum_gap.max())
print("second eigensolver driver changes the matrix on", int((df.rel_fro_second_driver > 1e-8).sum()), "cells (max relative distance %.2f)" % df.rel_fro_second_driver.max())
from collections import Counter
print("this host's matrix hash equals a run's hash:", Counter(tuple(x) for x in df.same_hash_as))
print("by structure:"); print(df.groupby("structure").agg(n=("cell", "size"), within_1e9=("rel_fro_vs_release", lambda s: int((s < 1e-9).sum())), max_dist=("rel_fro_vs_release", "max")).to_string())
print("cells where the GPU hosts agree with the release statistics and this host's matrix is within 1e-9 of the stored one:", int(((df.gpu_agree) & (df.rel_fro_vs_release < 1e-9)).sum()), "of", int(df.gpu_agree.sum()))
print("cells where the GPU hosts disagree:", int((~df.gpu_agree).sum()), "; of these within 1e-9 of the stored matrix:", int(((~df.gpu_agree) & (df.rel_fro_vs_release < 1e-9)).sum()))
df.to_csv(tc.parent / "regeneration_check.csv", index=False)
